-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2017 年 07 月 12 日 10:18
-- 服务器版本: 5.5.53
-- PHP 版本: 5.4.45

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `yinyue`
--

-- --------------------------------------------------------

--
-- 表的结构 `bj_admin`
--

CREATE TABLE IF NOT EXISTS `bj_admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) DEFAULT NULL,
  `password` char(32) DEFAULT NULL,
  `roleid` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `bj_admin`
--

INSERT INTO `bj_admin` (`id`, `username`, `password`, `roleid`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 1),
(7, 'DJ小帅', '25f9e794323b453885f5181f1b624d0b', 1);

-- --------------------------------------------------------

--
-- 表的结构 `bj_liupai`
--

CREATE TABLE IF NOT EXISTS `bj_liupai` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '流派主键id',
  `title` char(30) CHARACTER SET utf8 DEFAULT NULL COMMENT '流派名称',
  `des` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '流派描述',
  `pic` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片地址',
  `addtime` int(11) DEFAULT NULL COMMENT '添加时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `type` tinyint(1) DEFAULT NULL COMMENT '推荐类型 1 最新私货 2 精选歌曲',
  PRIMARY KEY (`id`),
  UNIQUE KEY `主键` (`id`) USING BTREE,
  KEY `分类` (`status`) USING BTREE,
  KEY `推荐` (`type`) USING BTREE
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=17 ;

--
-- 转存表中的数据 `bj_liupai`
--

INSERT INTO `bj_liupai` (`id`, `title`, `des`, `pic`, `addtime`, `status`, `type`) VALUES
(3, 'Big Room/ELECTRO HOUSE', 'Big Room/ELECTRO HOUSE', '/Public/Uploads/2017-06-26/5950d4e39397f.jpg', NULL, 0, 1),
(2, 'DutchHm /Groove', 'DutchHm /Groove', '/Public/Uploads/2017-06-26/5950d51f67c04.jpg', 1498468177, 0, 0),
(4, 'Hard Trap,/Dubstep', 'Hard Trap,/Dubstep ', '/Public/Uploads/2017-06-27/5951d0d8951bc.jpg', 1498534106, 0, 0),
(5, 'Deep/Minimal/vocal HOUSE', 'Deep/Minimal/vocal HOUSE ', '/Public/Uploads/2017-06-28/59536895b6922.jpg', 1498638490, 0, 0),
(6, 'TECH HOUSE/FUNKY HOUSE', 'TECH HOUSE/FUNKY HOUSE', '', 1499515956, 0, 0),
(7, 'Bass House/Future HOUSE', 'Bass House/Future HOUSE', '', 1499515998, 0, 2),
(8, 'Hard house/Hard style', 'Hard house/Hard style', '', 1499516022, 0, 0),
(9, 'ZIP 压缩包 TOP10', 'ZIP 压缩包 TOP10', '', 1499516062, 0, 0),
(12, 'List /各类榜单', 'List /各类榜单', '', 1499516388, 0, 0),
(13, 'Strit/各类开场', 'Strit/各类开场', '', 1499516470, 0, 0),
(16, 'TOP10', '阿斯达岁的房贷首付', '', 1499745606, 0, 3);

-- --------------------------------------------------------

--
-- 表的结构 `bj_member`
--

CREATE TABLE IF NOT EXISTS `bj_member` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(60) NOT NULL,
  `pwd` varchar(60) DEFAULT NULL,
  `weixin` varchar(60) DEFAULT NULL COMMENT '微信',
  `phone` varchar(60) NOT NULL COMMENT '头像',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别',
  `xingzuo` char(10) DEFAULT NULL COMMENT '星座',
  `addtime` int(11) DEFAULT NULL COMMENT '注册时间',
  `tel` bigint(20) DEFAULT NULL COMMENT '手机号',
  `nicheng` char(20) DEFAULT NULL COMMENT '昵称',
  `dengji` tinyint(1) NOT NULL DEFAULT '0' COMMENT '等级',
  `kaishitime` int(11) NOT NULL,
  `daoqitime` int(11) DEFAULT NULL COMMENT '到期时间',
  `bug` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- 转存表中的数据 `bj_member`
--

INSERT INTO `bj_member` (`id`, `title`, `pwd`, `weixin`, `phone`, `remark`, `status`, `sex`, `xingzuo`, `addtime`, `tel`, `nicheng`, `dengji`, `kaishitime`, `daoqitime`, `bug`) VALUES
(12, '111111', '96e79218965eb72c92a549dd5a330112', '111111', '', NULL, 0, 0, '白羊座', 1499682416, NULL, NULL, 1, 1499682444, 1512642444, 1),
(8, '15184157722', 'ce31964d23f7726ddcba4136436c19fd', '2755621683@qq.com', '/public/uploads/userphoto/15184157722/1499317695921618.jpg', NULL, 0, 0, '白羊座', 1499245212, 15184157722, '于海龙', 0, 1499788800, 1499875200, 0),
(9, '13298186469', 'e10adc3949ba59abbe56e057f20f883e', '111111', '', NULL, 0, 0, '白羊座', 1499310311, 13298186469, '小鱼', 0, 1499702400, 1499702400, 0),
(11, '15104152610', '25d55ad283aa400af464c76d713c07ad', '123456', '', NULL, 0, 0, '白羊座', 1499543700, NULL, NULL, 1, 1499788800, 1499875200, 0),
(15, '1234567', '25d55ad283aa400af464c76d713c07ad', '123', '', NULL, 0, 0, '白羊座', 1499712639, NULL, NULL, 1, 1499702400, 1499788800, 0),
(16, '333333', '1a100d2c0dab19c4430e7d73762b3423', '333333', '', NULL, 0, 0, '白羊座', 1499757366, NULL, NULL, 0, 1499097600, 1499270400, 0),
(17, '123456789', '25d55ad283aa400af464c76d713c07ad', 'ss', '', NULL, 0, 0, '白羊座', 1499765399, NULL, NULL, 1, 1499702400, 1499788800, 0),
(18, '1234567890', '25d55ad283aa400af464c76d713c07ad', '33', '', NULL, 0, 0, '白羊座', 1499770416, NULL, NULL, 1, 1499788800, 1499788800, 0),
(19, '13298186468', 'e10adc3949ba59abbe56e057f20f883e', '13298186469', '', NULL, 0, 0, '白羊座', 1499841102, NULL, NULL, 0, 0, NULL, 0),
(20, '47646654685', 'e10adc3949ba59abbe56e057f20f883e', '65478465', '', NULL, 0, 0, '白羊座', 1499841155, NULL, NULL, 0, 0, NULL, 0),
(21, 'ahjkhkj', '96e79218965eb72c92a549dd5a330112', '123456', '', NULL, 0, 0, '白羊座', 1499841741, NULL, NULL, 0, 0, NULL, 0),
(22, 'adslkljoojl', 'e10adc3949ba59abbe56e057f20f883e', '132465', '', NULL, 0, 0, '白羊座', 1499842089, NULL, NULL, 0, 0, NULL, 0),
(23, '12345678901', 'bfd81ee3ed27ad31c95ca75e21365973', '111', '', NULL, 0, 0, '白羊座', 1499842337, NULL, NULL, 0, 0, NULL, 0),
(24, 'liu842827861', 'c45c09e3bc96177e3f762c6f0a9e5300', 'wb9098', '', NULL, 0, 0, '白羊座', 1499854331, NULL, NULL, 0, 0, NULL, 0),
(25, '1qwertyu', '25d55ad283aa400af464c76d713c07ad', '12345678', '', NULL, 0, 0, '白羊座', 1499854441, NULL, NULL, 0, 0, NULL, 0);

-- --------------------------------------------------------

--
-- 表的结构 `bj_music`
--

CREATE TABLE IF NOT EXISTS `bj_music` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `liupaiid` int(11) DEFAULT NULL COMMENT '流派id',
  `zjid` int(11) DEFAULT NULL COMMENT '专辑id',
  `zipid` int(11) DEFAULT NULL COMMENT 'zipid',
  `tqid` int(11) DEFAULT NULL COMMENT '套曲id',
  `fenleititle` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '分类名称',
  `title` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '名称',
  `zuozhe` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '演唱歌手',
  `des` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '描述',
  `musicpic` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '音乐地址',
  `pic` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '专辑图片地址',
  `bmp` char(10) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'bmp',
  `key` char(10) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'key',
  `xiazaishu` int(11) NOT NULL DEFAULT '0' COMMENT '下载数',
  `dianjishu` int(11) NOT NULL DEFAULT '0' COMMENT '点击数',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `tuijian` tinyint(1) NOT NULL COMMENT '推荐类型',
  PRIMARY KEY (`id`),
  UNIQUE KEY `主键` (`id`) USING BTREE,
  KEY `分类` (`status`) USING BTREE,
  KEY `流派` (`liupaiid`) USING BTREE
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=134 ;

--
-- 转存表中的数据 `bj_music`
--

INSERT INTO `bj_music` (`id`, `liupaiid`, `zjid`, `zipid`, `tqid`, `fenleititle`, `title`, `zuozhe`, `des`, `musicpic`, `pic`, `bmp`, `key`, `xiazaishu`, `dianjishu`, `addtime`, `status`, `tuijian`) VALUES
(34, 7, NULL, NULL, NULL, NULL, 'Benny Benassi &amp;', 'Benny Benassi &amp;', 'Benny Benassi &amp; PubGic Enemy - Bring The Noise (TWISTERZ &amp; I.GOT.U Remix) ', '/Public/Uploads/music/2017-07-09/5961f63eaba95.mp3', '/Public/Uploads/phone/2017-07-09/5961f5fd487ab.jpg', '128', '8B', 432, 538, 1499592254, 0, 2),
(35, 7, NULL, NULL, NULL, NULL, 'Bijou - Gockdown (Or', 'Bijou - Gockdown (Or', 'Bijou - Gockdown (OriginaG Mix)', '/Public/Uploads/music/2017-07-09/5961f6e50f424.mp3', '/Public/Uploads/phone/2017-07-09/5961f6c203d09.jpg', '125', '12B', 662, 699, 1499592421, 0, 2),
(36, 7, NULL, NULL, NULL, NULL, 'Bingo PGayers - No.', 'Bingo PGayers - No.', 'Bingo PGayers - No. 1 Disco (Extended Mix)_DJ G.V MIX', '/Public/Uploads/music/2017-07-09/5961f7c9a7d8c.mp3', '/Public/Uploads/phone/2017-07-09/5961f73f3d090.jpg', '127', '2A', 274, 543, 1499592649, 0, 2),
(37, 7, NULL, NULL, NULL, NULL, 'BROHUG - Hostage (Or', 'BROHUG - Hostage (Or', 'BROHUG - Hostage (OriginaG Mix) ', '/Public/Uploads/music/2017-07-09/5961fcd31ab3f.mp3', '/Public/Uploads/phone/2017-07-09/5961fcb622551.jpg', '124', '11A', 342, 395, 1499593939, 0, 2),
(38, 7, NULL, NULL, NULL, NULL, 'Brohug - Paparazzi (', 'Brohug - Paparazzi (', 'Brohug - Paparazzi (Extended Mix)', '/Public/Uploads/music/2017-07-09/5961fd561312d.mp3', '/Public/Uploads/phone/2017-07-09/5961fd1994c5f.jpg', '125', '6A', 365, 427, 1499594070, 0, 2),
(41, 3, NULL, NULL, NULL, NULL, 'Benassi Bros.-Illusi', 'Benassi Bros.-Illusi', 'Benassi Bros.-Illusion feat. Sandy (Trifo &amp; STVW Bootleg)', '/Public/Uploads/music/2017-07-09/5962004457bcf.mp3', '/Public/Uploads/phone/2017-07-09/5961ffff03d09.jpg', '128', '', 588, 626, 1499594820, 0, 1),
(40, 7, NULL, NULL, NULL, NULL, 'Bueno Clinic vs. Dnf', 'Bueno Clinic vs. Dnf', 'Bueno Clinic vs. Dnf &amp; Vnalogic vs. Twisterz - I Love Shake That (Power Project Smash)DJ G.V MIX', '/Public/Uploads/music/2017-07-09/5961fec053ec6.mp3', '/Public/Uploads/phone/2017-07-09/5961fea66ea05.jpg', '128', '12B', 272, 388, 1499594432, 0, 2),
(33, 7, NULL, NULL, NULL, NULL, 'Basement Jaxx - Wher', 'Basement Jaxx - Wher', 'Basement Jaxx - Wheres Your Head At (P3TE ''VocaG'' Mix)DJ G.V MIX', '/Public/Uploads/music/2017-07-09/5961f54fbebc2.mp3', '/Public/Uploads/phone/2017-07-09/5961f531501bd.jpg', '128', '8B', 270, 362, 1499592015, 0, 2),
(32, 7, NULL, NULL, NULL, NULL, 'AGex Nocera, Andrea', 'AGex Nocera, Andrea', 'AGex Nocera, Andrea Montorsi - Funk (Extended Mix) ', '/Public/Uploads/music/2017-07-09/5961f41c40d99.mp3', '/Public/Uploads/phone/2017-07-09/5961f3e1af79e.jpg', '126', '10A', 344, 444, 1499591708, 0, 2),
(30, 7, NULL, NULL, NULL, NULL, 'Why So Serious - Fam', 'Why So Serious - Fam', 'Why So Serious - FamiGiar (OriginaG Mix)', '/Public/Uploads/music/2017-07-09/5961f2e71ab3f.mp3', '/Public/Uploads/phone/2017-07-09/5961f2a74c4b4.jpg', '128', '7A', 415, 454, 1499591399, 0, 2),
(29, 7, NULL, NULL, NULL, NULL, '版 2 Tiesto, Sevenn -', '版 2 Tiesto, Sevenn -', '版 2 Tiesto, Sevenn - Boom (OriginaG Mix)', '/Public/Uploads/music/2017-07-09/5961f25353ec6.mp3', '/Public/Uploads/phone/2017-07-09/5961f23553ec6.jpg', '123', '7A', 387, 487, 1499591251, 0, 2),
(25, 7, NULL, NULL, NULL, NULL, 'Tiesto &amp; Sevenn', 'Tiesto &amp; Sevenn', 'Tiesto &amp; Sevenn - BoomDJ G.V MIX', '/Public/Uploads/music/2017-07-09/5961f0d790f56.mp3', '/Public/Uploads/phone/2017-07-09/5961e80bd59f8.jpg', '123', '7A', 327, 439, 1499590871, 0, 2),
(31, 7, NULL, NULL, NULL, NULL, 'Travis Scott - Goose', 'Travis Scott - Goose', 'Travis Scott - Goosebumps (SaGGah Pump BootGeg)', '/Public/Uploads/music/2017-07-09/5961f3baf0537.mp3', '/Public/Uploads/phone/2017-07-09/5961f3a81e848.jpg', '128', '9A', 368, 546, 1499591611, 0, 2),
(42, 3, NULL, NULL, NULL, NULL, 'AndreOne &amp; Grant', 'AndreOne &amp; Grant', 'AndreOne &amp; Grant Rebound - Sonic (Original Mix)', '/Public/Uploads/music/2017-07-09/596200a440d99.mp3', '/Public/Uploads/phone/2017-07-09/5962008553ec6.jpg', '128', '', 693, 741, 1499594916, 0, 1),
(43, 3, NULL, NULL, NULL, NULL, 'Daft Punk vs. R3hab-', 'Daft Punk vs. R3hab-', 'Daft Punk vs. R3hab-Stronger Tiger (Starjack EDM Mashup Double Banger)', '/Public/Uploads/music/2017-07-09/596201458d24d.mp3', '/Public/Uploads/phone/2017-07-09/596200d4ec82e.jpg', '128', '', 819, 952, 1499595077, 0, 1),
(44, 3, NULL, NULL, NULL, NULL, 'Max Scampoli-Clap Yo', 'Max Scampoli-Clap Yo', 'Max Scampoli-Clap Your Hands (Original Mix)', '/Public/Uploads/music/2017-07-09/596201aa98968.mp3', '/Public/Uploads/phone/2017-07-09/5962018116e36.jpg', '128', '', 1002, 1087, 1499595178, 0, 1),
(45, 3, NULL, NULL, NULL, NULL, 'Olly James, TWINNS -', 'Olly James, TWINNS -', 'Olly James, TWINNS - Putana (Original Mix)', '/Public/Uploads/music/2017-07-09/5962022fbebc2.mp3', '/Public/Uploads/phone/2017-07-09/596201fc89544.jpg', '128', '', 1085, 1334, 1499595311, 0, 1),
(46, 3, NULL, NULL, NULL, NULL, 'Todaro - Puah (Origi', 'Todaro - Puah (Origi', 'Todaro - Puah (Original Mix)', '/Public/Uploads/music/2017-07-09/596202e13d090.mp3', '/Public/Uploads/phone/2017-07-09/596202c939387.jpg', '128', '', 2033, 2147, 1499595489, 0, 1),
(47, 3, NULL, NULL, NULL, NULL, 'Bombs Away - Sneak O', 'Bombs Away - Sneak O', 'Bombs Away - Sneak Out (Bonka Remix)', '/Public/Uploads/music/2017-07-09/596203c0a7d8c.mp3', '/Public/Uploads/phone/2017-07-09/59620395af79e.jpg', '130', '', 1132, 1278, 1499595712, 0, 1),
(48, 3, NULL, NULL, NULL, NULL, 'Dirtcaps - Lit feat', 'Dirtcaps - Lit feat', 'Dirtcaps - Lit feat Post Collide (Original Mix)', '/Public/Uploads/music/2017-07-09/596204865b8d8.mp3', '/Public/Uploads/phone/2017-07-09/5962047498968.jpg', '130', '', 552, 699, 1499595910, 0, 1),
(49, 3, NULL, NULL, NULL, NULL, 'The Masks - Heroes (', 'The Masks - Heroes (', 'The Masks - Heroes (Original Mix) [Starz Records]', '/Public/Uploads/music/2017-07-09/596206273d090.mp3', '/Public/Uploads/phone/2017-07-09/596206051312d.jpg', '128', '', 777, 865, 1499596327, 0, 1),
(50, 3, NULL, NULL, NULL, NULL, 'Rodrigo Howell, M3B8', 'Rodrigo Howell, M3B8', 'Rodrigo Howell, M3B8 - Bang It Up (Original Mix)', '/Public/Uploads/music/2017-07-09/596207e2a037a.mp3', '/Public/Uploads/phone/2017-07-09/596207cb44aa2.jpg', '128', '', 2609, 2713, 1499596770, 0, 1),
(51, 3, NULL, NULL, NULL, NULL, 'FEZZA_SIZE_S_Shakti_', 'FEZZA_SIZE_S_Shakti_', 'FEZZA_SIZE_S_Shakti_EDMR_TV', '/Public/Uploads/music/2017-07-09/596208a4a4083.mp3', '/Public/Uploads/phone/2017-07-09/5962080fa037a.jpg', '128', '128', 2538, 2569, 1499596842, 0, 1),
(52, 4, NULL, NULL, NULL, NULL, 'Aazar Vs. Dreamer, Far &amp; Few - Pop Dat ZULU (D!G D33P Edit) - 1B - 77', 'Aazar Vs. Dreamer, Far &amp; Few - Pop Dat ZULU (D!G D33P Edit) - 1B - 77', 'Aazar Vs. Dreamer, Far &amp; Few - Pop Dat ZULU (D!G D33P Edit) - 1B - 77', '/Public/Uploads/music/2017-07-10/5963223a66ff3.mp3', '/Public/Uploads/phone/2017-07-10/5963222e53ec6.jpg', '77', '1B', 11, 542, 1499669050, 0, 2),
(53, 4, NULL, NULL, NULL, NULL, 'Ambush, D-Wayne - Badman Sound (Original Mix) - 3B - 128', 'Ambush, D-Wayne - Badman Sound (Original Mix) - 3B - 128', 'Ambush, D-Wayne - Badman Sound (Original Mix) - 3B - 128', '/Public/Uploads/music/2017-07-10/5963231fdd40a.mp3', '/Public/Uploads/phone/2017-07-10/596322de03d09.jpg', '128', '3B', 4, 313, 1499669280, 0, 2),
(54, 4, NULL, NULL, NULL, NULL, 'Antiserum X Mayhem X Huey - Pop Lock &amp; Scoop It (Meaux Green Edit) - 9A - 150', 'Antiserum X Mayhem X Huey - Pop Lock &amp; Scoop It (Meaux Green Edit) - 9A - 150', 'Antiserum X Mayhem X Huey - Pop Lock &amp; Scoop It (Meaux Green Edit) - 9A - 150', '/Public/Uploads/music/2017-07-10/596325c8c65d4.mp3', '/Public/Uploads/phone/2017-07-10/596325ba3567e.jpg', '150', '9A', 3, 1, 1499669960, 0, 2),
(55, 3, NULL, NULL, NULL, NULL, 'ARTWERK_BASSLINE_DutchHM_2017 - 7B - 103', 'ARTWERK_BASSLINE_DutchHM_2017 - 7B - 103', 'ARTWERK_BASSLINE_DutchHM_2017 - 7B - 103', '/Public/Uploads/music/2017-07-10/596326ded59f8.mp3', '/Public/Uploads/phone/2017-07-10/5963269fb34a7.jpg', '103', '7B', 38, 239, 1499670238, 0, 2),
(59, 13, 3, NULL, NULL, 'DJ G.V', '', '', '', '/Public/Uploads/music/2017-07-10/59632ecccdfe6.mp3', '', '', '', 0, 1, 1499672268, 0, 0),
(60, 4, NULL, NULL, NULL, NULL, '13', '312332', '21332', '/Public/Uploads/music/2017-07-10/5963305e501bd.mp3', '/Public/Uploads/phone/2017-07-10/5963303053ec6.jpg', '122', '122', 0, 11, 1499672670, 0, 0),
(58, 13, 3, NULL, NULL, 'DJ G.V', '', '', '', '/', '', '', '', 0, 1, 1499672249, 0, 0),
(61, 3, NULL, 6, NULL, 'D J MIX   对我的不包括 而我是', '', '', '', '/Public/Uploads/music/2017-07-10/596333f989544.mp3', '', '', '', 6, 4, 1499673593, 0, 0),
(62, 9, NULL, NULL, 29, '', '未完成 ', '为单曲二 ', '违反 ', '/Public/Uploads/music/2017-07-10/59635326a4083.mp3', '', '', '', 1, 4, 1499681574, 0, 0),
(63, 3, NULL, NULL, NULL, NULL, '333', '333444', '34233', '/Public/Uploads/music/2017-07-10/596356a9d59f8.mp3', '', '12', '', 5, 4, 1499682473, 0, 1),
(64, 3, NULL, NULL, NULL, NULL, '2323', '232', '232', '/Public/Uploads/music/2017-07-11/5963c38b8d24d.mp3', '/Public/Uploads/phone/2017-07-11/5963c9ca03d09.jpg', '23', '23', 0, 0, 1499710347, 0, 1),
(65, 3, NULL, NULL, NULL, NULL, '2慰问费', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963d8800f424.jpg', '', '', 2, 2, 1499715716, 0, 0),
(66, 3, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963d8a05b8d8.jpg', '', '', 0, 1, 1499715746, 0, 0),
(67, 3, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963d8ad7a120.jpg', '', '', 1, 0, 1499715759, 0, 0),
(68, 3, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963d8b87a120.jpg', '', '', 0, 0, 1499715770, 0, 0),
(69, 3, NULL, NULL, NULL, NULL, '', '', '', '/Public/Uploads/music/2017-07-11/5963d8c43567e.jpg', '', '', '', 0, 0, 1499715780, 0, 0),
(70, 3, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963d8dfc28cb.jpg', '', '', 0, 1, 1499715809, 0, 0),
(71, 7, NULL, NULL, NULL, NULL, '234', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963d93f487ab.jpg', '', '', 3, 4, 1499715904, 0, 0),
(72, 7, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963d96189544.jpg', '', '', 0, 1, 1499715938, 0, 0),
(73, 7, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963d96dd9701.jpg', '', '', 0, 3, 1499715951, 0, 0),
(74, 7, NULL, NULL, NULL, NULL, '', '', '', '/', '', '', '', 0, 0, 1499715964, 0, 0),
(75, 7, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963d99594c5f.jpg', '', '', 6, 3, 1499715990, 0, 0),
(76, 7, NULL, NULL, NULL, NULL, '', '', '', '/Public/Uploads/music/2017-07-11/5963d9a740d99.jpg', '/Public/Uploads/phone/2017-07-11/5963d9a35f5e1.jpg', '', '', 4, 1, 1499716007, 0, 0),
(77, 7, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963d9ae1ab3f.jpg', '', '', 1, 1, 1499716015, 0, 0),
(78, 7, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963d9b6e1113.jpg', '', '', 0, 0, 1499716023, 0, 0),
(79, 7, NULL, NULL, NULL, NULL, '', '', '', '/Public/Uploads/music/2017-07-11/5963da17ca2dd.jpg', '/Public/Uploads/phone/2017-07-11/5963da2344aa2.jpg', '', '', 1, 1, 1499716119, 0, 0),
(80, 3, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963da7781b32.jpg', '', '', 0, 0, 1499716217, 0, 0),
(81, 3, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963da801312d.jpg', '', '', 2, 2, 1499716224, 0, 0),
(82, 3, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963da871e848.jpg', '', '', 3, 5, 1499716231, 0, 0),
(83, 3, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963da8e5f5e1.jpg', '', '', 7, 3, 1499716239, 0, 0),
(84, 3, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963da9722551.jpg', '', '', 5, 3, 1499716247, 0, 0),
(85, 3, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963daa044aa2.jpg', '', '', 2, 3, 1499716257, 0, 0),
(86, 3, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5963daaaa4083.jpg', '', '', 7, 3, 1499716267, 0, 0),
(87, 3, NULL, NULL, NULL, NULL, '121211312', '323212', '1212321', '/', '/Public/Uploads/phone/2017-07-11/5963dad96ea05.jpg', '211', '1213', 8, 4, 1499716314, 0, 0),
(88, 3, NULL, NULL, NULL, NULL, '12121212', '12112111', '212121121', '/', '/Public/Uploads/phone/2017-07-11/5963dae43d090.jpg', '212121', '212121', 28, 10, 1499716325, 0, 0),
(89, 3, NULL, NULL, NULL, NULL, 'asds', 'asda', 'sadad', '/', '/Public/Uploads/phone/2017-07-11/5963daf339387.jpg', '12', '121', 8, 8, 1499716339, 0, 0),
(90, 3, NULL, NULL, NULL, NULL, 'wqwqeqeq', 'wqqw', 'wqeqw', '/', '/Public/Uploads/phone/2017-07-11/5963db133567e.jpg', '', '', 8, 5, 1499716372, 0, 0),
(91, 16, NULL, NULL, NULL, NULL, '', '', '', '/Public/Uploads/music/2017-07-11/596463b8c65d4.jpg', '/Public/Uploads/phone/2017-07-11/596463acc65d4.jpg', '', '', 0, 0, 1499751352, 0, 0),
(92, 16, NULL, NULL, NULL, NULL, 'we', '', '', '/', '/Public/Uploads/phone/2017-07-11/596463da2dc6c.jpg', '', '', 0, 0, 1499751387, 0, 0),
(93, 16, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/596463ee0b71b.jpg', '', '', 0, 0, 1499751407, 0, 0),
(94, 16, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/596463fb07a12.jpg', '', '', 0, 0, 1499751420, 0, 0),
(95, 3, NULL, NULL, NULL, NULL, '111111111111111111111111111111111  ', '1111111111111111111', '', '/', '/Public/Uploads/phone/2017-07-11/5964642ed9701.jpg', '21', '21', 3, 112, 1499751472, 0, 0),
(96, 16, NULL, NULL, NULL, NULL, '222222222', '22222223', '333333', '/', '/Public/Uploads/phone/2017-07-11/596465ce81b32.jpg', '', '', 0, 0, 1499751887, 0, 0),
(97, 16, NULL, NULL, NULL, NULL, '555555', '55555', '5555', '/', '/Public/Uploads/phone/2017-07-11/596465eabebc2.jpg', '', '', 32, 322, 1499751916, 0, 0),
(98, 16, NULL, NULL, NULL, NULL, '121', '121', '', '/', '/Public/Uploads/phone/2017-07-11/59646635487ab.jpg', '', '', 1, 0, 1499751990, 0, 0),
(99, 16, NULL, NULL, NULL, NULL, '', '', 'w3', '/', '/Public/Uploads/phone/2017-07-11/5964665aaf79e.jpg', '', '', 0, 0, 1499752027, 0, 0),
(100, 16, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5964666722551.jpg', '', '', 0, 1, 1499752043, 0, 0),
(101, 16, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/5964667a31975.jpg', '', '', 1, 0, 1499752070, 0, 0),
(102, 16, NULL, NULL, NULL, NULL, 'yt', 'kbjk', '', '/', '/Public/Uploads/phone/2017-07-11/596466c7f0537.jpg', '', '', 1, 0, 1499752140, 0, 0),
(123, 16, NULL, NULL, NULL, NULL, 'y', '', '', '/', '/Public/Uploads/phone/2017-07-12/59651f5a66ff3.jpg', '', '', 0, 0, 1499799387, 0, 0),
(107, 9, NULL, 6, NULL, 'D J MIX   对我的不包括 而我是', '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646c8c53ec6.jpg', '', '', 0, 0, 1499753613, 0, 0),
(108, 9, NULL, 6, NULL, 'D J MIX   对我的不包括 而我是', '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646cc11312d.jpg', '', '', 0, 0, 1499753665, 0, 0),
(109, 9, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646ceaaf79e.jpg', '', '', 0, 0, 1499753708, 0, 0),
(110, 9, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646cf853ec6.jpg', '', '', 0, 0, 1499753721, 0, 0),
(111, 9, NULL, NULL, NULL, NULL, '', '', '', '/Public/Uploads/music/2017-07-11/59646d0594c5f.jpg', '/Public/Uploads/phone/2017-07-11/59646e695f5e1.jpg', '', '', 0, 0, 1499753733, 0, 0),
(112, 9, NULL, 6, NULL, 'D J MIX   对我的不包括 而我是', '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646d246ea05.jpg', '', '', 0, 0, 1499753765, 0, 0),
(113, 9, NULL, 6, NULL, 'D J MIX   对我的不包括 而我是', '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646d425b8d8.jpg', '', '', 0, 0, 1499753795, 0, 0),
(114, 9, NULL, 6, NULL, 'D J MIX   对我的不包括 而我是', '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646d7322551.jpg', '', '', 0, 0, 1499753844, 0, 0),
(115, 9, NULL, 6, NULL, 'D J MIX   对我的不包括 而我是', '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646d8d98968.jpg', '', '', 0, 0, 1499753872, 0, 0),
(116, 9, NULL, 6, NULL, 'D J MIX   对我的不包括 而我是', '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646dc029f63.jpg', '', '', 0, 0, 1499753921, 0, 0),
(117, 9, NULL, 6, NULL, 'D J MIX   对我的不包括 而我是', '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646dd629f63.jpg', '', '', 0, 0, 1499753943, 0, 0),
(118, 9, NULL, 6, NULL, 'D J MIX   对我的不包括 而我是', '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646df2cdfe6.jpg', '', '', 0, 0, 1499753972, 0, 0),
(119, 9, NULL, 6, NULL, 'D J MIX   对我的不包括 而我是', '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646e0844aa2.jpg', '', '', 0, 0, 1499753994, 0, 0),
(120, 9, NULL, 6, NULL, 'D J MIX   对我的不包括 而我是', '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646e3740d99.jpg', '', '', 0, 0, 1499754043, 0, 0),
(121, 9, NULL, 6, NULL, 'D J MIX   对我的不包括 而我是', '', '', '', '/', '/Public/Uploads/phone/2017-07-11/59646ed13d090.jpg', '', '', 0, 1, 1499754194, 0, 0),
(124, 16, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-12/59651f675b8d8.jpg', '', '', 0, 0, 1499799400, 0, 0),
(125, 16, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-12/59651f7381b32.jpg', '', '', 2131, 1233, 1499799412, 0, 0),
(126, 16, NULL, NULL, NULL, NULL, '', '', '', '/Public/Uploads/music/2017-07-12/59651fae8583b.jpg', '/Public/Uploads/phone/2017-07-12/59651fa9e1113.jpg', '', '', 100, 12331, 1499799470, 0, 0),
(127, 16, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-12/59651fec5f5e1.jpg', '', '', 300, 1, 1499799533, 0, 0),
(128, 16, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-12/59651ff794c5f.jpg', '', '', 31212, 23132, 1499799544, 0, 0),
(129, 16, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-12/59652003aba95.jpg', '', '', 200, 1233, 1499799558, 0, 0),
(130, 16, NULL, NULL, NULL, NULL, '', '', '', '/Public/Uploads/music/2017-07-12/5965203c8d24d.jpg', '/Public/Uploads/phone/2017-07-12/596520367a120.jpg', '', '', 2323, 132, 1499799612, 0, 0),
(131, 16, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-12/596520661e848.jpg', '', '', 500, 12342, 1499799658, 0, 0),
(132, 16, NULL, NULL, NULL, NULL, '', '', '', '/', '/Public/Uploads/phone/2017-07-12/596520a7aba95.jpg', '', '', 100, 124, 1499799721, 0, 0),
(133, 2, NULL, NULL, NULL, NULL, 'tttttttttttttttttttttttttt', 'tttttttttttttttttttttttttt', 'tttttttttttttttttttttttttt', '/Public/Uploads/music/2017-07-12/5965f6b00b71b.mp3', '/Public/Uploads/phone/2017-07-12/5965f6832625a.png', '128', '7A', 100, 202, 1499800139, 0, 2);

-- --------------------------------------------------------

--
-- 表的结构 `bj_mv`
--

CREATE TABLE IF NOT EXISTS `bj_mv` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `title` char(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '名称',
  `mvpic` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT 'MV地址',
  `pic` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片地址',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `主键` (`id`) USING BTREE,
  KEY `分类` (`status`) USING BTREE
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=42 ;

--
-- 转存表中的数据 `bj_mv`
--

INSERT INTO `bj_mv` (`id`, `title`, `mvpic`, `pic`, `addtime`, `status`) VALUES
(40, '67', '/Public/Uploads/mv/2017-07-10/596280aa1312d.mp4', '', 1499627690, 0),
(39, '121', '/Public/Uploads/mv/2017-07-10/59627b7389544.mp4', '', 1499595658, 0),
(41, '三', '/Public/Uploads/mv/2017-07-10/5963300d22551.mp4', '', 1499672589, 0);

-- --------------------------------------------------------

--
-- 表的结构 `bj_order`
--

CREATE TABLE IF NOT EXISTS `bj_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '流派主键id',
  `mid` int(11) DEFAULT NULL COMMENT '会员id',
  `tid` int(11) DEFAULT NULL COMMENT '套餐id',
  `addtime` int(11) DEFAULT NULL COMMENT '添加时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '订单状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `主键` (`id`) USING BTREE,
  KEY `分类` (`status`) USING BTREE
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=108 ;

--
-- 转存表中的数据 `bj_order`
--

INSERT INTO `bj_order` (`id`, `mid`, `tid`, `addtime`, `status`) VALUES
(107, 9, 9, 1499824467, 1),
(106, 18, 9, 1499797914, 1),
(105, 17, 9, 1499765605, 0),
(104, 11, 9, 1499764748, 0),
(103, 16, 10, 1499763604, 1);

-- --------------------------------------------------------

--
-- 表的结构 `bj_privilege`
--

CREATE TABLE IF NOT EXISTS `bj_privilege` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pri_name` varchar(20) DEFAULT NULL COMMENT '权限名称',
  `mname` varchar(20) DEFAULT NULL COMMENT '某个模块名称',
  `cname` varchar(20) DEFAULT NULL COMMENT '控制器名称',
  `aname` varchar(20) DEFAULT NULL COMMENT '方法名称',
  `parentid` int(10) NOT NULL DEFAULT '0' COMMENT '上级权限的id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

-- --------------------------------------------------------

--
-- 表的结构 `bj_role`
--

CREATE TABLE IF NOT EXISTS `bj_role` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `rolename` varchar(20) DEFAULT NULL,
  `pri_id_list` varchar(60) DEFAULT NULL COMMENT '权限id的列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `bj_role`
--

INSERT INTO `bj_role` (`id`, `rolename`, `pri_id_list`) VALUES
(1, '超级管理员', '*');

-- --------------------------------------------------------

--
-- 表的结构 `bj_shoucang`
--

CREATE TABLE IF NOT EXISTS `bj_shoucang` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `mid` int(11) DEFAULT NULL COMMENT '会员id',
  `muid` int(11) DEFAULT NULL COMMENT '音乐id',
  `addtime` int(11) DEFAULT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_icelandic_ci AUTO_INCREMENT=143 ;

--
-- 转存表中的数据 `bj_shoucang`
--

INSERT INTO `bj_shoucang` (`id`, `mid`, `muid`, `addtime`) VALUES
(111, 9, 18, 1499421880),
(122, 9, 15, 1499422662),
(100, 2, 12, 1499344031),
(119, 9, 19, 1499422659),
(112, 9, 14, 1499421885),
(123, 9, 13, 1499422662),
(117, 9, 12, 1499422061),
(121, 9, 11, 1499422661),
(109, 9, 17, 1499421877),
(116, 9, 0, 1499422051),
(108, 9, 16, 1499421876),
(98, 2, 0, 1499343743),
(139, 8, 45, 1499837443),
(141, 8, 47, 1499837466),
(142, 8, 48, 1499837469);

-- --------------------------------------------------------

--
-- 表的结构 `bj_taocan`
--

CREATE TABLE IF NOT EXISTS `bj_taocan` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `title` char(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '名称',
  `des1` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '描述',
  `des2` varchar(100) DEFAULT NULL,
  `des3` varchar(100) DEFAULT NULL,
  `des4` varchar(100) DEFAULT NULL,
  `des5` varchar(100) DEFAULT NULL,
  `pic` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片地址',
  `price` int(11) NOT NULL DEFAULT '0' COMMENT '价格',
  `addtime` int(11) DEFAULT NULL COMMENT '添加时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `主键` (`id`) USING BTREE,
  KEY `分类` (`status`) USING BTREE
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `bj_taocan`
--

INSERT INTO `bj_taocan` (`id`, `title`, `des1`, `des2`, `des3`, `des4`, `des5`, `pic`, `price`, `addtime`, `status`) VALUES
(9, '包月', '1个月', 'CPG用户', '加更新', '无限制', '30天', '/Public/Uploads/phone/2017-06-29/595470456adfa.jpg', 98, 1498704586, 0),
(10, '包季', '3个月', 'CPG用户', '加更新', '无限制', '90天', '/Public/Uploads/phone/2017-06-29/5954702eb6ba8.jpg', 198, 1498704703, 0),
(11, '半年', '6个月', 'CPG用户', '加更新', '无限制', '180天', '/Public/Uploads/phone/2017-07-09/59613a9daf79e.jpg', 388, 1498704736, 0),
(12, '包年', '12个月', 'CPG用户', '加更新', '无限制', '365天', '', 688, 1499257285, 0);

-- --------------------------------------------------------

--
-- 表的结构 `bj_taoqu`
--

CREATE TABLE IF NOT EXISTS `bj_taoqu` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `title` char(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '名称',
  `des` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '描述',
  `link` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '网盘连接',
  `pic` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片地址',
  `pwd` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '网盘密码',
  `addtime` int(11) DEFAULT NULL COMMENT '添加时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `daxiao` int(11) NOT NULL COMMENT '大小',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父类id',
  `xiazaishu` int(11) NOT NULL DEFAULT '0' COMMENT '下载数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `主键` (`id`) USING BTREE,
  KEY `分类` (`status`) USING BTREE,
  KEY `父id` (`pid`) USING BTREE
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=33 ;

--
-- 转存表中的数据 `bj_taoqu`
--

INSERT INTO `bj_taoqu` (`id`, `title`, `des`, `link`, `pic`, `pwd`, `addtime`, `status`, `daxiao`, `pid`, `xiazaishu`) VALUES
(6, '派对套曲', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0),
(8, '国外套曲', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0),
(24, '小帅', '小帅', NULL, '/Public/Uploads/phone/2017-07-09/5961d46181b32.jpg', NULL, 1499583586, 0, 0, 8, 2),
(13, '小帅', '小帅', '阿斯蒂芬', '/Public/Uploads/phone/2017-07-09/5961cca4f0537.jpg', '使得嘎嘎', 1498620861, 0, 0, 8, 112),
(14, '小帅', '小帅', NULL, '/Public/Uploads/phone/2017-07-09/5961cd8144aa2.jpg', NULL, 1499580721, 0, 0, 8, 121),
(15, '小帅', '小帅', NULL, '/Public/Uploads/phone/2017-07-09/5961cd3e22551.jpg', NULL, 1499580743, 0, 0, 8, 212),
(16, '小帅', '小帅', NULL, '/Public/Uploads/phone/2017-07-09/5961cd13baeb9.jpg', NULL, 1499580787, 0, 0, 6, 122),
(20, '', '', NULL, '/Public/Uploads/phone/2017-07-09/5961d5df5b8d8.jpg', NULL, 1499581897, 0, 0, 6, 0),
(17, '小帅', '小帅', NULL, '/Public/Uploads/phone/2017-07-09/5961cc85dd40a.jpg', NULL, 1499580872, 0, 0, 6, 0),
(18, '小帅', '小帅', NULL, '/Public/Uploads/phone/2017-07-09/5961d5be81b32.jpg', NULL, 1499580963, 0, 0, 8, 0),
(25, '', '', NULL, '', NULL, 1499680028, 0, 0, 6, 0),
(21, '乳房付费 放付费', '分付费', NULL, '/Public/Uploads/phone/2017-07-09/5961cdd3e8b25.jpg', NULL, 1499581909, 0, 0, 6, 0),
(22, '稳定文件 客服里面', ' 付费付费妇女健康 ', NULL, '/Public/Uploads/phone/2017-07-09/5961cddec65d4.jpg', NULL, 1499581920, 0, 13, 6, 2),
(23, '2017年 套曲 使用tauDJ 代收款', '1222222222222222222222', NULL, '/Public/Uploads/phone/2017-07-09/5961cdfbaf79e.jpg', NULL, 1499581949, 0, 0, 6, 2),
(26, '', '', NULL, '/Public/Uploads/phone/2017-07-10/59634d363567e.jpg', NULL, 1499680055, 0, 0, 6, 0),
(27, '', '', NULL, '/Public/Uploads/phone/2017-07-10/59634d4844aa2.jpg', NULL, 1499680073, 0, 0, 6, 0),
(28, '', '', NULL, '/Public/Uploads/phone/2017-07-10/59634d582625a.jpg', NULL, 1499680089, 0, 0, 6, 0),
(29, '', 'ZIP 压缩包 TOP10', 'WDEWQWQEQEWEQ', '/Public/Uploads/phone/2017-07-10/59634d6666ff3.jpg', 'WEDWQWEWQEQEWQQ', 1499680103, 0, 0, 6, 6),
(31, 'DJ  我爱你  哈哈', '我也爱你 么么哒', 'qqqqqqqqqqq', '', 'wwwwwwww', 1499680706, 0, 0, 6, 3),
(32, '3234E', '3443FFSFDSD', 'SFDFFDS', '/Public/Uploads/phone/2017-07-11/5963c4b353ec6.jpg', 'FSFFSS', 1499710652, 0, 2342, 6, 10);

-- --------------------------------------------------------

--
-- 表的结构 `bj_xiazai`
--

CREATE TABLE IF NOT EXISTS `bj_xiazai` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `mid` int(11) DEFAULT NULL COMMENT '会员id',
  `muid` int(11) DEFAULT NULL COMMENT '音乐id',
  `addtime` int(11) DEFAULT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_icelandic_ci AUTO_INCREMENT=505 ;

--
-- 转存表中的数据 `bj_xiazai`
--

INSERT INTO `bj_xiazai` (`id`, `mid`, `muid`, `addtime`) VALUES
(23, 8, 19, 1499537610),
(24, 8, 23, 1499539140),
(22, 8, 21, 1499537408),
(18, 8, 16, 1499537345),
(20, 8, 21, 1499537382),
(28, 8, 12, 1499540516),
(17, 8, 16, 1499537324),
(19, 8, 21, 1499537375),
(10, 2, 12, 1499339867),
(27, 8, 16, 1499540494),
(21, 8, 18, 1499537388),
(26, 8, 19, 1499539936),
(25, 8, 19, 1499539296),
(16, 8, 12, 1499537311),
(29, 8, 12, 1499540521),
(30, 8, 19, 1499540524),
(31, 8, 19, 1499540915),
(458, 12, 44, 1499846582),
(454, 12, 45, 1499846165),
(451, 12, 45, 1499846042),
(449, 12, 87, 1499845878),
(328, 12, 90, 1499766642),
(445, 12, 51, 1499843924),
(443, 12, 50, 1499843914),
(442, 12, 45, 1499843881),
(440, 12, 45, 1499843880),
(437, 12, 45, 1499843878),
(432, 12, 44, 1499843874),
(392, 12, 88, 1499842379),
(429, 12, 44, 1499843866),
(426, 12, 44, 1499843578),
(423, 12, 49, 1499843486),
(420, 12, 50, 1499842882),
(418, 12, 55, 1499842872),
(415, 12, 82, 1499842849),
(413, 12, 84, 1499842843),
(393, 12, 131, 1499842389),
(409, 12, 45, 1499842811),
(406, 12, 50, 1499842739),
(462, 12, 50, 1499847036),
(396, 12, 65, 1499842549),
(457, 12, 44, 1499846549),
(456, 12, 63, 1499846285),
(399, 12, 37, 1499842617),
(452, 12, 44, 1499846054),
(344, 9, 88, 1499767558),
(448, 12, 44, 1499844103),
(347, 9, 95, 1499767666),
(479, 12, 45, 1499847719),
(496, 11, 75, 1499849079),
(318, 9, 85, 1499764128),
(438, 12, 45, 1499843879),
(435, 12, 45, 1499843877),
(434, 12, 45, 1499843876),
(397, 12, 25, 1499842587),
(330, 9, 101, 1499766847),
(427, 12, 44, 1499843732),
(424, 12, 87, 1499843501),
(421, 12, 44, 1499843339),
(466, 12, 41, 1499847124),
(465, 12, 49, 1499847071),
(356, 15, 46, 1499769071),
(355, 9, 88, 1499768709),
(354, 9, 88, 1499768663),
(464, 12, 49, 1499847058),
(463, 12, 49, 1499847043),
(461, 12, 51, 1499846731),
(460, 12, 88, 1499846723),
(478, 12, 44, 1499847644),
(477, 12, 45, 1499847606),
(476, 12, 45, 1499847601),
(474, 12, 95, 1499847570),
(473, 12, 88, 1499847404),
(472, 12, 88, 1499847400),
(471, 12, 88, 1499847311),
(470, 12, 88, 1499847192),
(468, 12, 61, 1499847157),
(490, 12, 76, 1499848517),
(488, 12, 90, 1499848460),
(487, 12, 45, 1499848447),
(486, 12, 44, 1499848444),
(485, 12, 45, 1499848437),
(484, 12, 45, 1499848351),
(408, 12, 44, 1499842807),
(314, 9, 88, 1499764079),
(483, 12, 44, 1499848311),
(482, 12, 46, 1499848245),
(481, 11, 45, 1499848036),
(504, 12, 51, 1499849407),
(503, 12, 51, 1499849398),
(502, 12, 50, 1499849360),
(501, 12, 50, 1499849354),
(499, 12, 51, 1499849247),
(480, 11, 44, 1499847978),
(377, 9, 87, 1499824658),
(376, 9, 88, 1499822413),
(453, 12, 45, 1499846091),
(375, 8, 133, 1499801591),
(450, 12, 63, 1499846025),
(447, 12, 45, 1499844054),
(374, 8, 67, 1499799518),
(386, 12, 87, 1499842200),
(370, 8, 46, 1499798897),
(369, 8, 45, 1499798831),
(475, 12, 45, 1499847585),
(433, 12, 45, 1499843876),
(368, 8, 90, 1499798826),
(494, 11, 51, 1499848916),
(493, 11, 75, 1499848899),
(492, 12, 46, 1499848785),
(491, 11, 36, 1499848757),
(489, 12, 90, 1499848508),
(416, 12, 95, 1499842852),
(382, 8, 25, 1499835049),
(380, 8, 82, 1499835036),
(378, 8, 45, 1499834496),
(391, 12, 45, 1499842364),
(390, 12, 88, 1499842341),
(389, 12, 47, 1499842317),
(387, 12, 44, 1499842241),
(500, 12, 51, 1499849268),
(498, 11, 51, 1499849135),
(497, 11, 25, 1499849085),
(444, 12, 49, 1499843920),
(372, 8, 51, 1499799508),
(371, 8, 61, 1499799504),
(441, 12, 45, 1499843881),
(398, 12, 33, 1499842602),
(436, 12, 45, 1499843878),
(495, 11, 36, 1499848944),
(430, 12, 44, 1499843867),
(384, 8, 44, 1499836514),
(383, 8, 44, 1499835082),
(469, 12, 61, 1499847167),
(467, 12, 40, 1499847143),
(417, 12, 61, 1499842869),
(414, 12, 85, 1499842847),
(412, 12, 87, 1499842839),
(411, 12, 83, 1499842830),
(365, 8, 89, 1499798814),
(361, 15, 35, 1499769275),
(360, 15, 48, 1499769241),
(351, 15, 51, 1499767973),
(350, 15, 51, 1499767969),
(367, 8, 90, 1499798824),
(366, 8, 84, 1499798818),
(364, 18, 48, 1499798318),
(363, 18, 46, 1499798313),
(381, 8, 79, 1499835043),
(379, 8, 25, 1499834520),
(410, 12, 88, 1499842824),
(407, 12, 88, 1499842763),
(405, 12, 50, 1499842719),
(404, 12, 55, 1499842693),
(403, 12, 55, 1499842676),
(402, 12, 89, 1499842667),
(401, 12, 88, 1499842658),
(400, 12, 52, 1499842639),
(334, 9, 89, 1499767006),
(333, 9, 88, 1499766980),
(332, 9, 89, 1499766865),
(455, 12, 65, 1499846187),
(388, 12, 50, 1499842284),
(329, 12, 89, 1499766708),
(316, 9, 84, 1499764096),
(320, 8, 45, 1499765083),
(446, 12, 55, 1499843934),
(353, 9, 89, 1499768650),
(315, 9, 89, 1499764086),
(322, 8, 40, 1499765099),
(331, 9, 102, 1499766852),
(358, 15, 46, 1499769221),
(357, 16, 88, 1499769205),
(349, 9, 75, 1499767691),
(348, 9, 90, 1499767677),
(459, 12, 88, 1499846722),
(317, 9, 83, 1499764111),
(395, 12, 44, 1499842538),
(394, 12, 45, 1499842459),
(343, 9, 83, 1499767554),
(326, 8, 45, 1499766200),
(439, 12, 45, 1499843879),
(345, 9, 83, 1499767623),
(385, 8, 47, 1499836809),
(431, 12, 75, 1499843868),
(428, 12, 44, 1499843861),
(425, 12, 44, 1499843520),
(422, 12, 49, 1499843482),
(419, 12, 51, 1499842877),
(346, 9, 40, 1499767639),
(342, 9, 83, 1499767547),
(341, 8, 25, 1499767507),
(352, 16, 88, 1499768509),
(359, 15, 46, 1499769227),
(325, 8, 84, 1499766195),
(324, 8, 47, 1499765142),
(323, 8, 83, 1499765131),
(321, 8, 46, 1499765095),
(319, 9, 98, 1499764140),
(373, 8, 49, 1499799514);

-- --------------------------------------------------------

--
-- 表的结构 `bj_zhuanji`
--

CREATE TABLE IF NOT EXISTS `bj_zhuanji` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '专辑主键id',
  `title` char(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '专辑名称',
  `zuozhe` char(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '演唱歌手',
  `des` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '专辑描述',
  `link` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '网盘连接',
  `pic` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '专辑图片地址',
  `pwd` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '网盘密码',
  `addtime` int(11) DEFAULT NULL COMMENT '添加时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `主键` (`id`) USING BTREE,
  KEY `分类` (`status`) USING BTREE
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `bj_zhuanji`
--

INSERT INTO `bj_zhuanji` (`id`, `title`, `zuozhe`, `des`, `link`, `pic`, `pwd`, `addtime`, `status`) VALUES
(4, '阿斯达岁的', '阿斯达岁的', '阿斯大苏打', '阿斯达', '/Public/Uploads/phone/2017-07-09/5961d3ad4c4b4.jpg', '阿斯达', 1498534329, 0),
(5, 'a斯蒂芬', '撒旦法', '散打', '阿斯蒂芬', '/Public/Uploads/phone/2017-07-09/5961d3a43567e.jpg', '阿斯达', 1499074135, 0),
(7, 'ed', 'df', 'df', NULL, '/Public/Uploads/phone/2017-07-10/59632f055b8d8.jpg', NULL, 1499672326, 0),
(6, '3213', '32123', '21321', NULL, '/Public/Uploads/phone/2017-07-09/5961d3b9e1113.jpg', NULL, 1499542717, 0);

-- --------------------------------------------------------

--
-- 表的结构 `bj_zip`
--

CREATE TABLE IF NOT EXISTS `bj_zip` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `title` char(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '名称',
  `des` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '描述',
  `link` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '网盘连接',
  `pic` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片地址',
  `pwd` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '网盘密码',
  `addtime` int(11) DEFAULT NULL COMMENT '添加时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `daxiao` int(11) NOT NULL COMMENT '压缩包daxiao',
  `xiazaishu` int(11) NOT NULL DEFAULT '0' COMMENT '下载数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `主键` (`id`) USING BTREE,
  KEY `分类` (`status`) USING BTREE
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=21 ;

--
-- 转存表中的数据 `bj_zip`
--

INSERT INTO `bj_zip` (`id`, `title`, `des`, `link`, `pic`, `pwd`, `addtime`, `status`, `daxiao`, `xiazaishu`) VALUES
(6, 'D J MIX', '发放撒', '链接：http://pan.baidu.com/s/1hrRWqNi', '/Public/Uploads/phone/2017-07-09/5961d9458d24d.jpg', 'l3dq', 1498651597, 0, 100, 3),
(5, 'ClubKillers', '来自菲律宾 ', ' 链接：http://pan.baidu.com/s/1c2lbtTm ', '/Public/Uploads/phone/2017-07-09/596122f8c65d4.jpg', '密码：8e6t', 1498548359, 0, 1024, 2),
(7, 'erwewere', 'erwre', 'ewwe', '/Public/Uploads/phone/2017-07-09/5961cfecd9701.jpg', 'ewwew', 1499580110, 0, 0, 0),
(11, '32E', 'QWEDQW', 'Qa', '/Public/Uploads/phone/2017-07-11/5963c4ec1312d.jpg', 'QWEQW', 1499710714, 0, 111, 0),
(12, '请问额2', '123123', '121', '/Public/Uploads/phone/2017-07-11/5963c508501bd.jpg', '121123', 1499710728, 0, 12, 0),
(13, '324', '额外的翁', '111', '/Public/Uploads/phone/2017-07-11/5963c520501bd.jpg', '111', 1499710753, 0, 1, 0),
(14, '11', '111111', '1111', '/Public/Uploads/phone/2017-07-11/5963c532d59f8.jpg', '111', 1499710771, 0, 111, 0),
(15, '132', '2132', '123231', '/Public/Uploads/phone/2017-07-11/5963c54b0f424.jpg', '213312', 1499710795, 0, 23, 0),
(16, '123', '1231', '123', '/Public/Uploads/phone/2017-07-11/5963c564a7d8c.jpg', '12321', 1499710821, 0, 123, 1),
(17, '1233', '1232131', '123123131', '/Public/Uploads/phone/2017-07-11/5963d8492625a.jpg', '113131', 1499710839, 0, 1211, 1),
(18, '12313', '123313', '121312311', '/Public/Uploads/phone/2017-07-11/5963c58d40d99.jpg', '13131313', 1499710867, 0, 12312313, 0),
(19, '12312', '1233', '1312', '/Public/Uploads/phone/2017-07-11/5963c5af487ab.jpg', '131', 1499710895, 0, 1211, 0),
(20, '1231232', '12312', '113', '/Public/Uploads/phone/2017-07-11/5963c5c82625a.jpg', '1313', 1499710920, 0, 31232131, 3);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
