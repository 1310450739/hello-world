<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
    
    <title>会员列表-后台管理</title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="icon" type="image/x-icon" href="/Public/themes/ThirdParty/AmazeUI/i/favicon.ico">
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="/Public/themes/ThirdParty/AmazeUI/i/app-icon72x72@2x.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Amaze UI" />
    <link rel="apple-touch-icon-precomposed" href="/Public/themes/ThirdParty/AmazeUI/i/app-icon72x72@2x.png">
    <meta name="msapplication-TileImage" content="i/app-icon72x72@2x.png">
    <meta name="msapplication-TileColor" content="#0e90d2">
    <link rel="stylesheet" href="/Public/themes/ThirdParty/AmazeUI/css/amazeui.min.css">
    <script src="/Public/themes/ThirdParty/AmazeUI/js/jquery.min.js"></script>
    <script src="/Public/themes/ThirdParty/AmazeUI/js/amazeui.min.js"></script>
    <script src="/Public/themes/ThirdParty/AmazeUI/js/app.js"></script>

    <!--本地样式↓-->
    <link rel="stylesheet" href="/Public/themes/WxFile/css/public.css">
    <link rel="stylesheet" href="/Public/themes/WxFile/css/style.css">
    <script src="/Public/themes/WxFile/js/xcConfirm.js"></script>
    <!--日期插件-->
    <script language="javascript" type="text/javascript" src="/Public/admin/time/WdatePicker.js"></script>
    


</head>

<body>
    <!-- 头部导航 -->
    <header class="am-topbar am-topbar-fixed-top" style="border: 0;">
        <div class="am-container nav_box">
            <h1 class="am-topbar-brand" style="border-right: 1px solid #3299de; padding-left: 10px;">
                <a href="/index.php/admin"><img src="/Public/themes/WxFile/img/logo.png"></a>
            </h1>
            <div class="am-icon-list tpl-header-nav-hover-ico am-fl am-margin-right" id="ssicon"></div>
            <a href="/" target="_blank">
                <div class="am-icon-home tpl-header-nav-hover-ico am-fl am-margin-right"></div>
            </a>
            <div class="nav_right">
                <ul class="top_nav">
                    <!--<li><a href="#"><i class="iconfont">&#xe672;</i> 帮助</a></li>-->
                    <!--<li><a href="#"><i class="iconfont">&#xe600;</i> 设置</a></li>-->
                    <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen" class="tpl-header-list-link"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>
                    <li class="am-dropdown" data-am-dropdown>
                        <a class="am-dropdown-toggle" data-am-dropdown-toggle href="javascript:;" style="padding-right: 12px;">
                            <div class="photo_img"><img src="/Public/themes/WxFile/img/timg.jpg"></div>
                            <?php echo session('username'); ?> <i class="iconfont" style="font-size: 12px;">&#xe60b;</i></a>
                        <ul class="am-dropdown-content" style="min-width: 110px;">
                            <li><a href="/index.php/Admin/Admin/edit/id/<?php echo session('id'); ?>"><i class="iconfont">&#xe63a;</i> 修改密码</a></li>
                            <li class="am-divider"></li>
                            <li class="am-divider"></li>
                            <li><a href="/index.php/Admin/Admin/logout"><span class="am-icon-sign-out"> 安全退出</span></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </header>
    <!-- 主体 -->
    <div class="main_box">
        <!-- 左侧 -->
        <div class="menu_left">
            <ul class="menu_nav mar0" id="accordion">
                <li><a class="m_cycaozuo yes_nodes" data-am-collapse="{parent: '#accordion'}" href="#do-not-say-1"><i class="icon iconfont"></i> 内容管理</a>
                    <ul class="childmenu mar0 am-panel-collapse am-collapse am-in" id="do-not-say-1">
                        <li><a href="/index.php/Admin/Liupai/index" id="a1"><i class="iconfont">&#xe6a4;</i> 流派管理</a></li>
                        <li><a href="/index.php/Admin/Zhuanji/index" id="a2"><i class="iconfont">&#xe6a4;</i> 专辑管理</a></li>
                        <li><a href="/index.php/Admin/Zip/index" id="a2"><i class="iconfont">&#xe6a4;</i> ZIP管理</a></li>
                        <li><a href="/index.php/Admin/Taoqu/index" id="a2"><i class="iconfont">&#xe6a4;</i> 套曲管理</a></li>
                        <li><a href="/index.php/Admin/Music/index" id="a2"><i class="iconfont">&#xe6a4;</i> 音乐管理</a></li>
                        <li><a href="/index.php/Admin/Mv/index" id="a2"><i class="iconfont">&#xe6a4;</i> MV管理</a></li>
                        <!--<li><a href="#" id="a4"><i class="iconfont">&#xe648;</i> 广告管理</a></li>
                        <li><a href="#" id="a7"><i class="iconfont">&#xe613;</i> 友情链接</a></li>
                        <li><a href="#" id="a8"><i class="iconfont">&#xe62e;</i> 用户管理</a></li>
                        <!--<li><a href="#"><i class="iconfont">&#xe62e;</i> 商品管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> 动态管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> VIP管理</a></li>-->
                    </ul>
                </li>
                <li><a class="m_cycaozuo yes_nodes" data-am-collapse="{parent: '#accordion'}" href="#do-not-say-3"><i class="icon iconfont"></i> 业务管理</a>
                    <ul class="childmenu mar0 am-panel-collapse am-collapse am-in" id="do-not-say-3">
                        <li><a href="/index.php/Admin/Taocan/index" id="a1"><i class="iconfont">&#xe601;</i> 套餐管理</a></li>
                        <li><a href="/index.php/Admin/Order/index" id="a2"><i class="iconfont">&#xe6a4;</i> 订单管理</a></li>
                        <!--<li><a href="#" id="a2"><i class="iconfont">&#xe6a4;</i> 音乐管理</a></li>-->
                        <!--<li><a href="#" id="a4"><i class="iconfont">&#xe648;</i> 广告管理</a></li>
                        <li><a href="#" id="a7"><i class="iconfont">&#xe613;</i> 友情链接</a></li>
                        <li><a href="#" id="a8"><i class="iconfont">&#xe62e;</i> 用户管理</a></li>-->
                        <!--<li><a href="#"><i class="iconfont">&#xe62e;</i> 商品管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> 动态管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> VIP管理</a></li>-->
                    </ul>
                </li>
                <li>
                    <a class="m_xitonggl yes_nodes" data-am-collapse="{parent: '#accordion'}" href="#do-not-say-2"><i class="icon iconfont"></i> 用户管理</a>
                    <ul class="childmenu mar0 am-panel-collapse am-collapse am-in" id="do-not-say-2">
                        <!--<li><a href="#" id="a9"><i class="iconfont">&#xe64e;</i> 系统设置</a></li>-->
                        <li><a href="/index.php/Admin/Admin/lst" id="a10"><i class="iconfont">&#xe6c3;</i> 管理员管理</a></li>
                        <!--<li><a href="/index.php/Admin/Privilege/lst" id="a8"><i class="iconfont">&#xe623;</i> 权限管理</a></li>-->
                        <!--<li><a href="/index.php/Admin/Role/lst" id="a11"><i class="iconfont">&#xe602;</i> 角色管理</a></li>-->
                        <li><a href="/index.php/Admin/Member/index" id="a11"><i class="iconfont">&#xe602;</i>会员管理</a></li>
                    </ul>
                </li>
            </ul>
        </div>
        <script type="text/javascript">
            $("#ssicon").click(function() {
                $(".menu_left").toggleClass("active");
            });
        </script>
        <script type="text/javascript">
            var myNav = document.getElementById("accordion").getElementsByTagName("a");
            for (var i = 0; i < myNav.length; i++) {
                var links = myNav[i].getAttribute("href");
                var myURL = document.location.href;
                if (myURL.indexOf(links) != -1) {
                    myNav[i].className = "cur";
                }
            }
        </script>
        <!-- 右侧 -->
        <div class="menu_right">
            
    <div class="seat">
        <ul>
            <li><i class="iconfont">&#xe603;</i> <a href="/index.php/Admin/index/index"> 首页</a></li>
            <li>会员列表</li>
        </ul>
    </div>

            
    <div class="search-wrap">
        <form action="">
            <div class="input-group">
                <span class="input-group-addon" style="border-top-right-radius: 0; border-bottom-right-radius: 0;">关键字</span>
                <input type="text" name="where" value="<?php echo I('get.where'); ?>" placeholder="用户名" class="form-control">
            </div>
            <span class="input-group-btn">
                    <input class="am-btn sea_btn am-btn-primary" name="sub" value="查询" type="submit">
                </span>
        </form>
    </div>
    <div class="tablelist">
        <table class="am-table am-table-bordered am-table-striped am-table-hover">
            <thead>
                <tr>
                    <!--<th><input name="" id="check" type="checkbox"> 全选</th>-->
                    <!--<th>排序</th>-->
                    <th>ID</th>
                    <th>用户名</th>
                    <th>昵称</th>
                    <th>微信</th>
                    <th>电话</th>
                    <th>注册时间</th>
                    <th>会员等级</th>
                    <th>开通时间</th>
                    <th>到期时间</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if(is_array($memberlist)): $i = 0; $__LIST__ = $memberlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$member): $mod = ($i % 2 );++$i;?><tr>
                        <td><?php echo ($member["id"]); ?></td>
                        <td><?php echo ($member["title"]); ?></td>
                        <td><?php echo ($member['nicheng']?($member['nicheng']):'无'); ?></td>
                        <td><?php echo ($member["weixin"]); ?></td>
                        <td><?php echo ($member['tel']?($member['tel']):'无'); ?></td>
                        <td><?php echo (date("Y-m-d",$member["addtime"])); ?></td>
                        <td><?php echo ($member['dengji']==0?'普通':'VIP'); ?></td>
                        <td><?php echo ($member['dengji']==1?date('Y-m-d',$member['kaishitime']):'无'); ?></td>
                        <td><?php echo ($member['dengji']==1?date('Y-m-d',$member['daoqitime']):'无'); ?></td>
                        <td><?php echo ($member['status']==0?'正常':'冻结'); ?></td>
                        <td>
                            <div class="btn_two ">
                                <?php if($member['dengji'] == 0): ?><a class="am-btn sea_btn2 am-btn-secondary " href="<?php echo U( 'shengji');?>?id=<?php echo ($member["id"]); ?>&title=<?php echo ($member["title"]); ?>" style="padding: 6px 10px; ">升级</a><?php endif; ?>
                                <a class="am-btn sea_btn2 am-btn-danger " onclick="dongjie(<?php echo ($member["id"]); ?>,<?php echo ($member["status"]); ?>)" href="javascript:void(0);" style="padding: 6px 10px; "><?php echo ($member['status']==0?'冻结':'解冻'); ?></a>
                                <a class="am-btn sea_btn2 am-btn-danger " href="<?php echo U( 'edit');?>?id=<?php echo ($member["id"]); ?>" style="padding: 6px 10px; ">编辑</a>
                                <a class="am-btn sea_btn2 am-btn-danger " onclick="return confirm( '确定删除？') " href="<?php echo U( 'del');?>?id=<?php echo ($member["id"]); ?> " style="padding: 6px 10px; ">删除</a>
                            </div>
                        </td>
                    </tr><?php endforeach; endif; else: echo "" ;endif; ?>
            </tbody>
        </table>
    </div>
    </form>
    <div class="page" style="float:right; margin-right:30px;">
        <?php echo ($page); ?>
    </div>
    </div>
    <script>
        function dongjie(id, status) {

            //获取当前域名
            var http = window.location.host;
            var row = {
                'id': id,
                'status': status
            };
            $.ajax({
                url: "http://" + http + "/index.php/Admin/member/dongjie",
                type: "post",
                data: row,
                dataType: "json",
                success: function(data) {
                    // alert(data)
                    if (data.code == 1) {
                        window.location.reload();
                        // window.location.href = "http://" + http + "/index.php/Home/member/index";
                    } else {
                        alert(data.msg)
                    }
                },
                error: function(data) {
                    alert('系统繁忙!');
                    // window.location.reload();
                }
            });
        }
    </script>


            <!--palr15-->
        </div>
        <script type="text/javascript">
            $("#ssicon").click(function() {
                $(".menu_right").toggleClass("active");
            });
        </script>
    </div>
    <!-- 底部 -->
    <div class="footer">
        技术支持: <a href="http://www.bojuwang.net/"> www.bojuwang.net</a>
    </div>
</body>

</html>



<!--百度编辑器-->