<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
    
    <title>音乐添加-后台管理</title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="icon" type="image/x-icon" href="/Public/themes/ThirdParty/AmazeUI/i/favicon.ico">
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="/Public/themes/ThirdParty/AmazeUI/i/app-icon72x72@2x.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Amaze UI" />
    <link rel="apple-touch-icon-precomposed" href="/Public/themes/ThirdParty/AmazeUI/i/app-icon72x72@2x.png">
    <meta name="msapplication-TileImage" content="i/app-icon72x72@2x.png">
    <meta name="msapplication-TileColor" content="#0e90d2">
    <link rel="stylesheet" href="/Public/themes/ThirdParty/AmazeUI/css/amazeui.min.css">
    <script src="/Public/themes/ThirdParty/AmazeUI/js/jquery.min.js"></script>
    <script src="/Public/themes/ThirdParty/AmazeUI/js/amazeui.min.js"></script>
    <script src="/Public/themes/ThirdParty/AmazeUI/js/app.js"></script>

    <!--本地样式↓-->
    <link rel="stylesheet" href="/Public/themes/WxFile/css/public.css">
    <link rel="stylesheet" href="/Public/themes/WxFile/css/style.css">
    <script src="/Public/themes/WxFile/js/xcConfirm.js"></script>
    <!--日期插件-->
    <script language="javascript" type="text/javascript" src="/Public/admin/time/WdatePicker.js"></script>
    
    <script type="text/javascript" charset="utf-8" src="/Public/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="/Public/ueditor/ueditor.all.min.js">
    </script>
    <script type="text/javascript" charset="utf-8" src="/Public/ueditor/lang/zh-cn/zh-cn.js"></script>
    <script src="/Public/themes/ThirdParty/AmazeUI/js/plupload.full.min.js"></script>



</head>

<body>
    <!-- 头部导航 -->
    <header class="am-topbar am-topbar-fixed-top" style="border: 0;">
        <div class="am-container nav_box">
            <h1 class="am-topbar-brand" style="border-right: 1px solid #3299de; padding-left: 10px;">
                <a href="/index.php/admin"><img src="/Public/themes/WxFile/img/logo.png"></a>
            </h1>
            <div class="am-icon-list tpl-header-nav-hover-ico am-fl am-margin-right" id="ssicon"></div>
            <a href="/" target="_blank">
                <div class="am-icon-home tpl-header-nav-hover-ico am-fl am-margin-right"></div>
            </a>
            <div class="nav_right">
                <ul class="top_nav">
                    <!--<li><a href="#"><i class="iconfont">&#xe672;</i> 帮助</a></li>-->
                    <!--<li><a href="#"><i class="iconfont">&#xe600;</i> 设置</a></li>-->
                    <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen" class="tpl-header-list-link"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>
                    <li class="am-dropdown" data-am-dropdown>
                        <a class="am-dropdown-toggle" data-am-dropdown-toggle href="javascript:;" style="padding-right: 12px;">
                            <div class="photo_img"><img src="/Public/themes/WxFile/img/timg.jpg"></div>
                            <?php echo session('username'); ?> <i class="iconfont" style="font-size: 12px;">&#xe60b;</i></a>
                        <ul class="am-dropdown-content" style="min-width: 110px;">
                            <li><a href="/index.php/Admin/Admin/edit/id/<?php echo session('id'); ?>"><i class="iconfont">&#xe63a;</i> 修改密码</a></li>
                            <li class="am-divider"></li>
                            <li class="am-divider"></li>
                            <li><a href="/index.php/Admin/Admin/logout"><span class="am-icon-sign-out"> 安全退出</span></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </header>
    <!-- 主体 -->
    <div class="main_box">
        <!-- 左侧 -->
        <div class="menu_left">
            <ul class="menu_nav mar0" id="accordion">
                <li><a class="m_cycaozuo yes_nodes" data-am-collapse="{parent: '#accordion'}" href="#do-not-say-1"><i class="icon iconfont"></i> 内容管理</a>
                    <ul class="childmenu mar0 am-panel-collapse am-collapse am-in" id="do-not-say-1">
                        <li><a href="/index.php/Admin/Liupai/index" id="a1"><i class="iconfont">&#xe6a4;</i> 流派管理</a></li>
                        <li><a href="/index.php/Admin/Zhuanji/index" id="a2"><i class="iconfont">&#xe6a4;</i> 专辑管理</a></li>
                        <li><a href="/index.php/Admin/Zip/index" id="a2"><i class="iconfont">&#xe6a4;</i> ZIP管理</a></li>
                        <li><a href="/index.php/Admin/Taoqu/index" id="a2"><i class="iconfont">&#xe6a4;</i> 套曲管理</a></li>
                        <li><a href="/index.php/Admin/Music/index" id="a2"><i class="iconfont">&#xe6a4;</i> 音乐管理</a></li>
                        <li><a href="/index.php/Admin/Mv/index" id="a2"><i class="iconfont">&#xe6a4;</i> MV管理</a></li>
                        <!--<li><a href="#" id="a4"><i class="iconfont">&#xe648;</i> 广告管理</a></li>
                        <li><a href="#" id="a7"><i class="iconfont">&#xe613;</i> 友情链接</a></li>
                        <li><a href="#" id="a8"><i class="iconfont">&#xe62e;</i> 用户管理</a></li>
                        <!--<li><a href="#"><i class="iconfont">&#xe62e;</i> 商品管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> 动态管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> VIP管理</a></li>-->
                    </ul>
                </li>
                <li><a class="m_cycaozuo yes_nodes" data-am-collapse="{parent: '#accordion'}" href="#do-not-say-3"><i class="icon iconfont"></i> 业务管理</a>
                    <ul class="childmenu mar0 am-panel-collapse am-collapse am-in" id="do-not-say-3">
                        <li><a href="/index.php/Admin/Taocan/index" id="a1"><i class="iconfont">&#xe601;</i> 套餐管理</a></li>
                        <li><a href="/index.php/Admin/Order/index" id="a2"><i class="iconfont">&#xe6a4;</i> 订单管理</a></li>
                        <!--<li><a href="#" id="a2"><i class="iconfont">&#xe6a4;</i> 音乐管理</a></li>-->
                        <!--<li><a href="#" id="a4"><i class="iconfont">&#xe648;</i> 广告管理</a></li>
                        <li><a href="#" id="a7"><i class="iconfont">&#xe613;</i> 友情链接</a></li>
                        <li><a href="#" id="a8"><i class="iconfont">&#xe62e;</i> 用户管理</a></li>-->
                        <!--<li><a href="#"><i class="iconfont">&#xe62e;</i> 商品管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> 动态管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> VIP管理</a></li>-->
                    </ul>
                </li>
                <li>
                    <a class="m_xitonggl yes_nodes" data-am-collapse="{parent: '#accordion'}" href="#do-not-say-2"><i class="icon iconfont"></i> 用户管理</a>
                    <ul class="childmenu mar0 am-panel-collapse am-collapse am-in" id="do-not-say-2">
                        <!--<li><a href="#" id="a9"><i class="iconfont">&#xe64e;</i> 系统设置</a></li>-->
                        <li><a href="/index.php/Admin/Admin/lst" id="a10"><i class="iconfont">&#xe6c3;</i> 管理员管理</a></li>
                        <!--<li><a href="/index.php/Admin/Privilege/lst" id="a8"><i class="iconfont">&#xe623;</i> 权限管理</a></li>-->
                        <!--<li><a href="/index.php/Admin/Role/lst" id="a11"><i class="iconfont">&#xe602;</i> 角色管理</a></li>-->
                        <li><a href="/index.php/Admin/Member/index" id="a11"><i class="iconfont">&#xe602;</i>会员管理</a></li>
                    </ul>
                </li>
            </ul>
        </div>
        <script type="text/javascript">
            $("#ssicon").click(function() {
                $(".menu_left").toggleClass("active");
            });
        </script>
        <script type="text/javascript">
            var myNav = document.getElementById("accordion").getElementsByTagName("a");
            for (var i = 0; i < myNav.length; i++) {
                var links = myNav[i].getAttribute("href");
                var myURL = document.location.href;
                if (myURL.indexOf(links) != -1) {
                    myNav[i].className = "cur";
                }
            }
        </script>
        <!-- 右侧 -->
        <div class="menu_right">
            
    <div class="seat">
        <ul>
            <li><i class="iconfont">&#xe603;</i> <a href="/index.php/Admin/index/index"> 首页</a></li>
            <li><a href="/index.php/Admin/Music/index">音乐管理</a></li>
            <li>音乐添加</li>
        </ul>
    </div>

            
    <div class="palr15">
        <!-- 发布 -->
        <div class="publish">
            <form action="" method="post" id="myform" name="myform" enctype="multipart/form-data">
                <table class="am-table am-table-bordered">
                    <tbody>
                        <tr>
                            <td class="am-text-middle text_ri" style="width: 120px;"><span class="red">*</span> 选择流派：</td>
                            <td>
                                <div class="input-group" style="position: relative;">
                                    <div class="sanjiao"></div>
                                    <select name="liupaiid" class="select-group sel_inp">
                                <?php if(is_array($liupailist)): $i = 0; $__LIST__ = $liupailist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$liupai): $mod = ($i % 2 );++$i;?><option value="<?php echo ($liupai["id"]); ?>"><?php echo ($liupai["title"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                                </select>
                                </div>
                            </td>
                        </tr>
                        <?php if($fenleititle): ?><tr>
                                <td class="am-text-middle text_ri" style="width: 120px;">所属分类：</td>
                                <td><?php echo ($fenleititle); ?></td>
                            </tr><?php endif; ?>
                        <tr>
                            <td class="am-text-middle text_ri" style="width: 120px;"><span class="red">*</span> 歌曲名称：</td>
                            <td><input type="text" name="title" value="" class="input_texk"></td>
                        </tr>
                        <tr>
                            <td class="am-text-middle text_ri" style="width: 120px;"> 演唱歌手：</td>
                            <td><input type="text" name="zuozhe" value="" class="input_texk"></td>
                        </tr>
                        <!--<tr>
                            <td class="am-text-middle text_ri" style="width: 120px;"> 关键词：</td>
                            <td><input type="text" name="keywords" value="" class="input_texk"></td>
                        </tr>-->
                        <tr>
                            <td class="am-text-middle text_ri" style="width: 120px;"> 歌曲描述：</td>
                            <td><textarea name="des" class="textqy" id="" cols="55" rows="5"></textarea></td>
                        </tr>
                        <tr>
                            <td class="am-text-middle text_ri" style="width: 120px;"> BMP：</td>
                            <td><input type="text" name="bmp" value="" class="input_texk"></td>
                        </tr>
                        <tr>
                            <td class="am-text-middle text_ri" style="width: 120px;"> KEY：</td>
                            <td><input type="text" name="key" value="" class="input_texk"></td>
                        </tr>
                        <tr>
                            <td class="am-text-middle text_ri" style="width: 120px;"> 上传音乐：</td>
                            <td><input type="file" name="musicpic" value="" class="input_texk"></td>
                        </tr>
                        <tr>
                            <td class="am-text-middle text_ri" style="width: 120px;"> 封面图片：</td>
                            <td>
                                <div class="container">
                                    <div class="up_add f_btn">
                                        <a class="btn" id="btn"></a>
                                    </div>
                                    <ul id="ul_pics" class="ul_pics clearfix"></ul>
                                </div>
                            </td>
                        </tr>
                        <!--<tr>
                            <td class="am-text-middle text_ri"><span class="red">*</span> 内容：</td>
                            <td><textarea name="content" id="content" class="textqy" style="border: 0; width: 98%;"></textarea></td>
                        </tr>-->
                        <!--<tr>
                            <td class="am-text-middle text_ri" style="width: 120px;"> 推荐类型：</td>
                            <td>最新私货 &nbsp; <input name="type" type="radio" value="1" /> &nbsp; &nbsp;|&nbsp; &nbsp; 精选歌曲 &nbsp; <input name="type" type="radio" value="2" /></td>
                        </tr>-->
                        <tr>
                            <td class="am-text-middle text_ri" style="width: 120px;"> 推荐类型</td>
                            <td>&nbsp;&nbsp;无&nbsp;&nbsp;&nbsp; <input name="tuijian" type="radio" value="0" checked /> &nbsp; &nbsp;| &nbsp; BOOTLEG &nbsp; <input name="tuijian" type="radio" value="1" /> &nbsp; &nbsp;| &nbsp; CPGDJ&nbsp; <input name="tuijian"
                                    type="radio" value="2" /></td>
                        </tr>
                        <tr>
                            <td class="am-text-middle text_ri" style="width: 120px;"> 显示状态：</td>
                            <td>开启&nbsp; <input name="status" type="radio" value="0" checked /> &nbsp; &nbsp;|&nbsp; &nbsp; 关闭&nbsp; <input name="status" type="radio" value="1" /></td>
                        </tr>

                        <tr>
                            <td>&nbsp;</td>
                            <td>
                                <input class="am-btn sea_btn am-btn-secondary font14" value="提交" type="submit">
                                <input class="am-btn am-btn-default sea_btn gray font14" onclick="history.go(-1)" value="返回" type="button">
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </div>
    </div>

            <!--palr15-->
        </div>
        <script type="text/javascript">
            $("#ssicon").click(function() {
                $(".menu_right").toggleClass("active");
            });
        </script>
    </div>
    <!-- 底部 -->
    <div class="footer">
        技术支持: <a href="http://www.bojuwang.net/"> www.bojuwang.net</a>
    </div>
</body>

</html>


    <script type="text/javascript">
        //创建实例的构造方法
        var uploader = new plupload.Uploader({
            runtimes: 'html5,flash,silverlight,html4',
            browse_button: 'btn',
            url: "<?php echo U('Common/upLoads');?>",
            flash_swf_url: 'plupload/Moxie.swf',
            silverlight_xap_url: 'plupload/Moxie.xap',
            filters: {
                max_file_size: '10mb', //最大上传文件大小（格式100b, 10kb, 10mb, 1gb）
                mime_types: [ //允许文件上传类型
                    {
                        title: "files",
                        extensions: "jpg,png,gif"
                    }
                ]
            },
            multi_selection: true, //true:ctrl多文件上传, false 单文件上传
            init: {
                FilesAdded: function(up, files) { //文件上传前
                    if ($("#ul_pics").children("li").length > 30) {
                        alert("您上传的图片太多了！");
                        uploader.destroy();
                    } else {
                        var li = '';
                        plupload.each(files, function(file) { //遍历文件
                            li += "<li id='" + file['id'] + "'><div class='progress'><span class='bar'></span><span class='percent'>0%</span></div></li>";
                        });
                        $("#ul_pics").append(li);
                        uploader.start();
                    }
                },
                UploadProgress: function(up, file) { //上传中，显示进度条
                    $("#" + file.id).find('.bar').css({
                        "width": file.percent + "%"
                    }).find(".percent").text(file.percent + "%");
                },
                FileUploaded: function(up, file, info) { //文件上传成功的时候触发
                    var data = JSON.parse(info.response);
                    $("#" + file.id).html("<div class='upimg_box'><img src='" + data.pic + "'/><div class='sctxt'><a href='javascript:void(0);' onclick='test(this)'>删除</a></div><input type='hidden' name='pic[]' value=" + data.path + "></div>");

                },
                Error: function(up, err) { //上传出错的时候触发
                    alert(err.message);
                }
            }
        });
        uploader.init();

        function test(obj) {

            $(obj).parent().parent().css('display', 'none')
            $(obj).parent().parent().children().eq(1).attr('name', 'remove');
        }
    </script>


    <script type="text/javascript">
        //实例化编辑器
        //建议使用工厂方法getEditor创建和引用编辑器实例，如果在某个闭包下引用该编辑器，直接调用UE.getEditor('editor')就能拿到相关的实例
        UE.getEditor('content', {
            initialFrameWidth: 1000,
            initialFrameHeight: 300,
        });
    </script>

<!--百度编辑器-->