<?php 
namespace Home\Controller;
use Think\Controller;
class IndexController extends CommonController
{
    public  function index()
    {
        $musicobj = M('music');
        //首页mv 
        $mvlist = M('mv')->field('mvpic')->where('status = 0')->order('id desc')->select();

        $this->assign('mvlist',$mvlist);
       
        //随机
        $musicshu = $musicobj
            ->field('id,pic')
            ->where('status = 0')
            ->select();
        $count = count($musicshu);

        $suiji1 = mt_rand(0,intval($count/2));
        $suiji2 = $suiji1+1;
        $suiji3 = mt_rand(intval($count/2)+1,$count-1);
        $suiji4 = $suiji3+1;

        foreach($musicshu as $k=>$v){
            if($k == $suiji1){
                $suijiarr1[0] = $v;
            }elseif($k == $suiji2){
                $suijiarr1[1] = $v;
            }elseif($k == $suiji3){
                $suijiarr2[0] = $v;
            }elseif($k == $suiji4){
                $suijiarr2[1] = $v;
            }
        }

        $suijiarr1 = $this->jcsc($suijiarr1);
        $suijiarr2 = $this->jcsc($suijiarr2);
        $this->assign('suiji1',$suijiarr1);
        $this->assign('suiji2',$suijiarr2);


       

        //最新私货
        $sihuo = $musicobj
            ->field('m.title,m.id,m.liupaiid as lpid,m.pic,m.bmp,m.key,m.tuijian,m.xiazaishu,lp.title as lptitle')
            ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
            ->where('lp.type = 1 and m.status = 0')
            ->order('id desc')
            ->limit('30')
            ->select();
       
        $sihuo = $this->jcsc($sihuo);
        
        $this->assign('sihuo',$sihuo);

        //zip
        $ziplist = M('zip')
            ->field('id,title,pic,des')
            ->order('id desc')
            ->limit('15')
            ->select();
        $this->assign('ziplist',$ziplist);
        

        // top10 
        $toplist =  $musicobj
                ->field('m.id,m.title,m.zuozhe,m.pic,lp.id lpid')
                 ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
                ->where('m.status = 0 and lp.type = 3')
                ->limit('10')
                ->order('id desc')
                ->select();
        $toplist = $this->jcsc($toplist);
        $this->assign('toplist',$toplist);


        // 百大套取
        $taoquobj = M('taoqu');
        $futao = $taoquobj
                ->field('id,title')
                ->where('pid = 0')
                ->select();
        $baidatao = $taoquobj
                ->where('pid ='.$futao[0]['id'])
                ->order('id desc')
                ->limit(5)
                ->select();
        $baidatao[0]['cattitle'] = $futao[0]['title'];
        $this->assign('baidatao',$baidatao);

        //商业套曲
        $shangyetao = $taoquobj
                ->where('pid ='.$futao[1]['id'])
                ->order('id desc')
                ->limit(5)
                ->select();
        $shangyetao[0]['cattitle'] = $futao[1]['title'];
        $this->assign('shangyetao',$shangyetao);



        //精选歌曲
         $jingxuan = $musicobj
            ->field('m.title,m.id,m.liupaiid as lpid,m.pic,m.bmp,m.key,m.xiazaishu,m.tuijian,lp.title as lptitle')
            ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
            ->where('m.status = 0 and lp.type = 2')
            ->order('id desc')
            ->limit('30')
            ->select();
        $jingxuan = $this->jcsc($jingxuan);
        $this->assign('jingxuan',$jingxuan);
        $this->display();
    }

    public function diange(){
        if(IS_POST){
            $musicobj  = M('music');
            $diangeone = $musicobj
                        ->field('m.title,m.id,m.zuozhe,m.pic,m.liupaiid as lpid,m.musicpic,m.dianjishu,m.xiazaishu,m.bmp,m.key,m.addtime,lp.title as lptitle')
                        ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
                        ->where('m.id = '.I('post.id'))
                        ->find();
            $up['dianjishu'] =   $diangeone['dianjishu'] + 1; 
            $musicobj->where('id = '.I('post.id'))->save($up);
            if($_SESSION['member']){
                $wdsc = M('shoucang')->where('mid ='.$_SESSION['member']['id'])->select();
                foreach($wdsc as $sck=>$scv){
                        if($diangeone['id'] == $scv['muid']){
                            $diangeone['color'] = red;
                        }
                    }
            }
            if($diangeone){
                $diangeone['code'] = 1;
                $data = $diangeone;
                $data['addtime'] = date('Y-m-d',$data['addtime']);
                exit(json_encode($data));
            }else{
                exit(json_encode($data['code'] = 0));
            }
        }
    }
    
    public function guanlian(){
         if(IS_POST){
            $musicobj  = M('music');
            $guanlian = $musicobj
                        ->field('m.title,m.id,m.zuozhe,m.pic,m.musicpic,m.dianjishu,m.xiazaishu,m.bmp,m.key,m.addtime,lp.title as lptitle')
                        ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
                        ->where('m.status = 0 and lp.id = '.I('post.lpid'))
                        ->order('id desc')
                        // ->limit('4')
                        ->select();
            if($_SESSION['member']){
                $mid = $_SESSION['member']['id'];
                $wdsc = M('shoucang')->where('mid ='.$mid)->select();
                foreach($guanlian as $k=>$v){
                    foreach($wdsc as $sck=>$scv){
                        if($v['id'] == $scv['muid']){
                            $guanlian[$k]['color'] = 'red';
                        }
                    }
                }
           
            }
        
            if($guanlian){
                $guanlian[0]['code'] = 1;
                $data = $guanlian;
                foreach($data as $k=>$v){
                    $data[$k]['addtime'] = date('Y-m-d',$v['addtime']);
                }
                exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            }else{
                exit(json_encode($data[0]['code'] = 0,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            }
        }
    }

    public function xiazai(){
        if(IS_POST){
            if($_SESSION['member']){
                $member = M('member')->field('dengji,kaishitime,daoqitime')->find($_SESSION['member']['id']);
                if($member['dengji'] == 0){
                    $data['code'] = 0;
                    $data['msg'] = '您的会员权限不够,请升级您的权限!';
                    exit(json_encode($data));
                }else{
                    
                    $id = I('post.id');
                    $musicobj  = M('music');

                    $diangeone = $musicobj
                                ->field('id,musicpic,xiazaishu,title')
                                ->where('id = '.$id)
                                ->find();
                    if($diangeone){

                        $up['xiazaishu'] =  $diangeone['xiazaishu'] + 1; 
                        $musicobj->where('id = '. $id)->save($up);       

                        $row['mid'] = $_SESSION['member']['id'];
                        $row['muid'] = $diangeone['id'];
                        $row['addtime'] = time();
                        M('xiazai')->add($row);
                        
                        $data['code'] = 1;
                        $data['msg'] = '成功!';
                        $data['title'] = $diangeone['title'];
                        $data['url'] = $diangeone['musicpic'];
                        exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
                    }else{
                        $data['code'] = 0;
                        $data['msg'] = '下载失败!';
                        exit(json_encode($data));
                    }
                }

            }else{
                $data['code'] = 0;
                $data['msg'] = '登录后才能下载!';
                exit(json_encode($data));
            }   
        }
    }



    public function shoucang(){
        if(IS_POST){
            if(!$_SESSION['member']){
                $data['code'] = 3;
                $data['msg'] = '登录之后才能收藏!';
                exit(json_encode($data));                    
            }
            $mid = $_SESSION['member']['id'];
            $muid = I('post.id');
            $scobj =  M('shoucang');
            $row['mid'] = $mid;
            $row['muid'] = $muid;
            $scone = $scobj->field('id,mid,muid')->where($row)->find();
            if($scone){
                if($scobj->where('id ='.$scone['id'])->delete()){
                    $data['code'] = 2;
                    $data['msg'] = '取消收藏成功!';
                    exit(json_encode($data));                    
                }
            }else{
                $row['addtime'] = time();
                if($scobj->add($row)){
                    $data['code'] = 1;
                    $data['msg'] = '收藏成功!';
                    exit(json_encode($data));
                }
            }
        }else{
            $this->redirect('/');
        }
    }


    public function wangpan(){
        if(IS_POST){
            $member = M('member')->field('dengji,kaishitime,daoqitime')->find($_SESSION['member']['id']);
            if(!$_SESSION['member']){
                $data['code'] = 0;
                $data['msg'] = '登录之后才能下载!';
                exit(json_encode($data));                    
            }elseif($member['dengji'] == 0){
                $data['code'] = 0;
                $data['msg'] = '您的会员权限不够,请升级您的会员等级!';
                exit(json_encode($data));      
            }
            if(I('post.wangpan') == 'zip'){
                $obj = M('zip');
            }else if(I('post.wangpan') == 'taoqu'){
                $obj = M('taoqu');
            }
            $id = I('post.id');
            $panone = $obj->field('link,pwd,xiazaishu')->find($id);
            if($panone){
                $up['xiazaishu'] =  $panone['xiazaishu'] + 1; 
                $obj->where('id = '. $id)->save($up);       

                $data['code'] = 1;
                $data['msg'] = '成功!';
                $data['link'] = $panone['link'];
                $data['pwd'] = $panone['pwd'];
                exit(json_encode($data));      
            }else{
                $data['code'] = 0;
                $data['msg'] = '失败!';
                exit(json_encode($data));      
            }
        }else{
             $this->redirect('/');
        }
    }


    public function search(){
        if(IS_POST){
            $search = I('post.search');
            $searchlist = M('music')
                        ->field('m.title,m.id,m.zuozhe,m.pic,m.musicpic,m.dianjishu,m.xiazaishu,m.bmp,m.key,m.addtime,lp.title as lptitle')
                        ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
                        ->where("m.status = 0 and m.title  like '%$search%'")
                        ->order('id desc')
                        ->select();

            $arr = $this->jcsc($searchlist);
            $this->assign('searchlist',$searchlist);
            $this->assign('biaoti',$search);
            $this->display();
        }else{
            $this->redirect('/');
        }
    }

}
