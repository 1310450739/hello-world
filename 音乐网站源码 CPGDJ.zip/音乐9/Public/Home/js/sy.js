$(function() {
    $(".bt .bt1").click(function() {
        var a = $(this).index();
        $(this).addClass("bac").siblings().removeClass("bac")
        $(".kinw .k").eq(a).addClass("acb").siblings().removeClass("acb")
    })

    $(".kl div").click(function() {
        var b = $(this).index();
        $(this).addClass("bac").siblings().removeClass("bac")
        $(".kinr .k3").eq(b).addClass("acb").siblings().removeClass("acb")
    })


    $(".boxkom .zbox1 div").click(function() {
        var c = $(this).index()
        $(this).addClass("bac").siblings().removeClass("bac")
        $(this).parent(".zbox1").siblings(".zbox").children(".boxw100").eq(c).addClass("acb").siblings().removeClass("acb")

    })

    var no = 3
    $(".kin1 .zuo").click(function() {
        --no
        $(this).parent(".kin1").parent(".boxti").siblings(".zbox").children(".boxw100").eq(no).addClass("acb").siblings().removeClass("acb");
        $(this).parent(".kin1").parent(".boxti").siblings(".zbox1").children("div").eq(no).addClass("bac").siblings().removeClass("bac");

        if (no == -1) {
            no = 2
        }
    })
    var right = 0
    $(".kin1 .you").click(function() {
        right++
        if (right == 3) {
            right = 0
        }
        $(this).parent(".kin1").parent(".boxti").siblings(".zbox").children(".boxw100").eq(right).addClass("acb").siblings().removeClass("acb");
        $(this).parent(".kin1").parent(".boxti").siblings(".zbox1").children("div").eq(right).addClass("bac").siblings().removeClass("bac");
    })

    $(".mk .zbox1 div").click(function() {
        var ni = $(this).index()
        $(this).addClass("bac").siblings().removeClass("bac")
        $(this).parent(".zbox1").siblings(".liderour").children(".lider1").eq(ni).addClass("acb").siblings().removeClass("acb")
    })

    //音乐插件
    var ur = "media/sko.mp3"

    var s_bfq = WaveSurfer.create({
        container: "#s_bfq",
        waveColor: "white",
        progressColor: "red",
        height: 60,
        interact: true,
        normalize: true,
        cursorColor: "gray",
        pixelRatio: 1,
        hideScrollbar: true,
    })

    s_bfq.on('ready', function() {

        s_bfq.play()

        var zfz = Math.floor(Math.floor(s_bfq.getDuration()) / 60);
        if (zfz < 10) {
            zfz = '0' + zfz;
        }
        var zm = Math.floor(s_bfq.getDuration()) % 60;
        if (zm < 10) {
            zm = '0' + zm;
        }
        var zsc = zfz + ':' + zm;
        $('.sj1').text(zsc);

        $(".boxbofang").click(function() {
            if (s_bfq.isPlaying()) {
                $(this).css({
                    backgroundImage: "url" + "(public/home/img/pause.png)",
                })
                s_bfq.playPause()
            } else {
                $(this).css({
                    backgroundImage: "url" + "(public/home/img/play.png)"
                })
                s_bfq.playPause()
            }
        })
    })

    $("body").on('click', '.shangxia', function() {
        $('.sj1').text('00:00');
        $(".lom1").removeClass("acb");
        $(".lom").removeClass("acb");
        $(".sk1").empty();
        var sx = $(this).attr('sx');
        if (sx == 's') {
            var tishi = '没有上一曲了!';
        } else if (sx == 'x') {
            var tishi = '没有下一曲了!';
        }
        var mid = $(this).attr('mid');
        //获取当前域名
        var http = window.location.host;
        $.ajax({
            url: "http://" + http + "/index.php/Home/index/diange",
            type: "post",
            data: {
                'id': mid
            },
            dataType: "json",
            success: function(data) {
                if (data.code == 1) {
                    $('.minone img').attr('src', data.pic);
                    $('.mintwo div').eq(0).html(data.title);
                    $('.mintwo div').eq(1).html(data.zuozhe);

                    $('#dianxin').attr('mid', data.id);
                    $('#dibuxiazai').attr('mid', data.id);
                    $('#dianxin').css('color', data.color);

                    $('#shangyige').attr('mid', data.id + 1);
                    $('#xiayige').attr('mid', data.id - 1);


                    $('.imgpath').attr('src', data.pic);
                    $('.boxlist').attr('lpid', data.lpid);
                    $('.olx div').eq(0).html('歌曲 : ' + data.title);
                    $('.olx div').eq(1).html('流派 : ' + data.lptitle);
                    $('.olx div').eq(2).html('速度 : ' + data.bmp);
                    $('.olx div').eq(3).html('音调 : ' + data.key);
                    $('.olx div').eq(4).html('时间 : ' + data.addtime);
                    $('.olx div').eq(5).html('试听 : ' + data.dianjishu + ' 次');
                    $('.olx div').eq(6).html('下载 : ' + data.xiazaishu + ' 次');



                    s_bfq.load(data.musicpic)
                    $(".min").animate({ bottom: 0 })
                    s_bfq.playPause()
                } else {
                    alert(tishi);
                }
            },
            // error: function(data) {
            //     alert('上传失败!');
            //     // window.location.reload();
            // }
        });

    })

    $("body").on('click', '.bfq', function() {
        $('.sj1').text('00:00');
        $(".lom1").removeClass("acb");
        $(".lom").removeClass("acb");
        $(".sk1").empty();
        var mid = $(this).attr('mid');
        //获取当前域名
        var http = window.location.host;
        $.ajax({
            url: "http://" + http + "/index.php/Home/index/diange",
            type: "post",
            data: {
                'id': mid
            },
            dataType: "json",
            success: function(data) {
                if (data.code == 1) {
                    $('.minone img').attr('src', data.pic);
                    $('.mintwo div').eq(0).html(data.title);
                    $('.mintwo div').eq(1).html(data.zuozhe);

                    $('#dianxin').attr('mid', data.id);
                    $('#dibuxiazai').attr('mid', data.id);
                    $('#dianxin').css('color', data.color);

                    $('#shangyige').attr('mid', data.id + 1);
                    $('#xiayige').attr('mid', data.id - 1);


                    $('.imgpath').attr('src', data.pic);
                    $('.boxlist').attr('lpid', data.lpid);
                    $('.olx div').eq(0).html('歌曲 : ' + data.title);
                    $('.olx div').eq(1).html('流派 : ' + data.lptitle);
                    $('.olx div').eq(2).html('速度 : ' + data.bmp);
                    $('.olx div').eq(3).html('音调 : ' + data.key);
                    $('.olx div').eq(4).html('时间 : ' + data.addtime);
                    $('.olx div').eq(5).html('试听 : ' + data.dianjishu + ' 次');
                    $('.olx div').eq(6).html('下载 : ' + data.xiazaishu + ' 次');

                    s_bfq.load(data.musicpic)

                    $(".min").animate({ bottom: 0 })

                    arr.push(data.musicpic)

                    console.log(arr)

                    s_bfq.play()

                } else {
                    return false;
                }
            },
            // error: function(data) {
            //     alert('上传失败!');
            //     // window.location.reload();
            // }
        });

    })

    var arr = [];

    setInterval(function() {
        var zsj = s_bfq.getCurrentTime()
        var z = Math.floor(zsj)
        var fz = Math.floor(z / 60)
        if (fz < 10) {
            fz = '0' + fz;
        }
        var miao = z % 60
        if (miao < 10) {
            miao = '0' + miao;
        }
        var zong = fz + ':' + miao
        $(".sj").text(zong)
    }, 1000)



    var name = ur.substring(6)
    $("body").on('click', '.ahre', function() {
        var http = window.location.host;
        var id = $(this).attr('mid');
        $.ajax({
            url: "http://" + http + "/index.php/Home/index/xiazai",
            type: "post",
            data: {
                'id': id
            },
            dataType: "json",
            success: function(data) {
                // alert(data);
                if (data.code == 1) {
                    // // alert(data[0].title);
                    // alert(data.url)
                    // window.open("http://" + http + data.url);
                    // download_file.iframe.src = "http://" + http + data.url;
                    // self.location.href = "http://" + http + data.url;

                    var a = document.getElementById("xiazaiba");
                    if ((data.url != '/') && data.title) {
                        // $('#xiazaiba').attr('href', data.url);
                        // $('#xiazaiba').attr('download', data.title + '.mp3');
                        // $('#xiazaiba').click();
                        a.href = data.url;
                        a.download = data.title + '.mp3';
                        a.click();
                    } else(
                        alert('系统繁忙请稍后重试!')
                    )

                } else {
                    alert(data.msg);
                }
            },
            error: function(data) {
                alert('系统繁忙!');
                // window.location.reload();
            }
        });
        // $(".ahre").attr("href", ur)
        // $(".ahre").attr("download", name);
    })

    $(".tiaozhang").click(function(e) {
        var p = $(this).offset().left
        var x = e.pageX
        var li = parseInt((x - p))
        $(".ziji").css({
            width: li + "%"
        })
        s_bfq.setVolume(li / 100)
    })

    var imgpa = $(".minone img").attr("src")
    $(".imgpath").attr("src", imgpa)


    $(".boxxinxi").click(function() {
        if ($(".lom").hasClass("acb")) {
            $(".lom").removeClass("acb")
            $(".lom1").removeClass("acb")
        } else {
            $(".lom").addClass("acb")
            $(".lom1").removeClass("acb")
        }
    })

    $(".boxlist").click(function() {
        if ($(".lom1").hasClass("acb")) {
            $(".lom1").removeClass("acb")
            $(".lom").removeClass("acb")
            $(".sk1").empty();
        } else {
            var lpid = $(this).attr('lpid');

            var http = window.location.host;
            $.ajax({
                url: "http://" + http + "/index.php/Home/index/guanlian",
                type: "post",
                data: {
                    'lpid': lpid
                },
                dataType: "json",
                success: function(data) {
                    // alert(data);
                    if (data[0].code == 1) {
                        // alert(data[0].title);
                        $.each(data, function(i, val) {
                            var str = '<div class="bli"> <div class="b1"><img src="' + val.pic + '"</div> <div class = "b2" ><div>' + val.title + '</div><div>' + val.lptitle + '</div></div><div class="b3"><div>BPM</div><div>' + val.bmp + '</div></div><div class="b3"><div>TIME</div><div>' + val.addtime + '</div></div><div class="box2 qi"><div class="bfq" mid="' + val.id + '"></div><div class="xiazai"><a href="javascript:void(0);"  class="ahre" mid="' + val.id + '" ></a><i class="icon Hui-iconfont ani">&#xe674;</i></div><div class="box99 box100 xin"  mid="' + val.id + '" style="color:' + val.color + '"><i class="icon Hui-iconfont ">&#xe648;</i></div></div></div>'

                            //  <div class="box3 xin" mid="{$jingxuan3.id}" style="color{$jingxuan3['sc']==1?':red':''}"><i class="icon Hui-iconfont ">&#xe648;</i></div>


                            $(".sk1").append(str);
                        });

                        $(".lom1").addClass("acb")
                        $(".lom").removeClass("acb")
                    }
                },
                // error: function(data) {
                //     alert('上传失败!');
                //     // window.location.reload();
                // }
            });
        }
    })

    // $(".kinlo").click(function() {
    //         var path = $(this).siblings(".b1").children("img").attr("src")
    //         $(".imgpath").attr("src", path)
    //     })
    //音乐插件



    $(".akm .m1").click(function() {
        var bi1 = $(this).index()
        $(".akm1 .lider1").eq(bi1).addClass("acb").siblings().removeClass("acb")
    })

    $(".akn .m1").click(function() {
        var bi = $(this).index()

        $(".akn1 .lider1").eq(bi).addClass("acb").siblings().removeClass("acb")

    })


    $(".s_lmi div").click(function() {
        var lm = $(this).index()
        $(this).addClass("acb1").siblings().removeClass("acb1")
        $(".s_nib .s_ni1").eq(lm).addClass("acb").siblings().removeClass("acb")
    })


    $("body").on('click', '.xin', function() {
        var http = window.location.host;
        var id = $(this).attr('mid');
        // var clickid = "#click_" + id;
        var newid = 'dainxinid' + id;
        $(this).attr('id', newid);
        $.ajax({
            url: "http://" + http + "/index.php/Home/index/shoucang",
            type: "post",
            data: {
                'id': id
            },
            dataType: "json",
            success: function(data) {
                // alert(data);
                if (data.code == 1) {
                    $("#" + newid).css("color", "red");
                } else if (data.code == 2) {
                    $("#" + newid).css("color", "white");
                } else if (data.code == 3) {
                    alert(data.msg);
                }
            },
            // error: function(data) {
            //     alert('系统繁忙!');
            //     // window.location.reload();
            // }
        });

    });





})