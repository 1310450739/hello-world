<?php
return array(
	//'配置项'=>'配置值'
	'LAYOUT_ON'=>true,
	'LAYOUT_NAME'=>'layout',
	 // 'DEFAULT_CONTROLLER'    =>  'Login', // 默认控制器名称

);