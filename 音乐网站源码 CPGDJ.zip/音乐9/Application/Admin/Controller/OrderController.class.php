<?php
namespace Admin\Controller;
use Think\Controller;
class OrderController extends CommonController {
    public function index(){
        $orderobj = M('order');
        $count      = $orderobj
                    ->join('as o join bj_member as m on o.mid = m.id')
                    ->join('bj_taocan as t on o.tid = t.id')
                    ->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        $this->assign('page',$show);// 赋值分页输出
        $orderlist = $orderobj
                    ->field('o.*,m.id as m_id,m.title as m_title,t.title as t_title,t.price,o.status')
                    ->join('as o join bj_member as m on o.mid = m.id')
                    ->join('bj_taocan as t on o.tid = t.id')
                    ->order('o.status , id desc')
                    ->limit($Page->firstRow.','.$Page->listRows)
                    ->select();
        $this->assign('orderlist',$orderlist);
        $this->display();
    }



    public function del(){
        if(I('get.id')){
            if(M('order')->delete(I('get.id'))){
                $this->success('删除成功!',U('Admin/Order/index'),1);

                exit; 
            }else{
                $this->error('删除失败','',1);
                exit;
            }
        }else{
           $this->error('无效参数',U('Admin/Index/index'),1);
            exit;  
        }
    }

    public function edit(){
        $orderobj = M('order');
        $id = I('post.id');
        $row['status'] = 1;
        if ($orderobj->where('id= '.$id)->save($row)) {
            $data['code'] = 1;
            $data['msg'] = '成功!';
            exit(json_encode($data));
        }else{
            $data['code'] = 0;
            $data['msg'] = '失败!';
            exit(json_encode($data));
        }
    }
}