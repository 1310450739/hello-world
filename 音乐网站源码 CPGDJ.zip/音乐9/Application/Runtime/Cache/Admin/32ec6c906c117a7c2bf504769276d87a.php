<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
    <title>登录页面</title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">

    <!-- No Baidu Siteapp-->
    <meta http-equiv="Cache-Control" content="no-siteapp"/>

    <link rel="icon" type="image/x-icon" href="/Public/themes/ThirdParty/AmazeUI/i/favicon.ico">

    <!-- Add to homescreen for Chrome on Android -->
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="/Public/themes/ThirdParty/AmazeUI/i/app-icon72x72@2x.png">

    <!-- Add to homescreen for Safari on iOS -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Amaze UI"/>
    <link rel="apple-touch-icon-precomposed" href="/Public/themes/ThirdParty/AmazeUI/i/app-icon72x72@2x.png">

    <!-- Tile icon for Win8 (144x144 + tile color) -->
    <meta name="msapplication-TileImage" content="i/app-icon72x72@2x.png">
    <meta name="msapplication-TileColor" content="#0e90d2">

    <link rel="stylesheet" href="/Public/themes/ThirdParty/AmazeUI/css/amazeui.min.css">
    <script src="/Public/themes/ThirdParty/AmazeUI/js/jquery.min.js"></script>
    <!--<![endif]-->
    <!--[if lte IE 8 ]>
    <script src="http://libs.baidu.com/jquery/1.11.3/jquery.min.js"></script>
    <script src="http://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
    <script src="assets/js/amazeui.ie8polyfill.min.js"></script>
    <![endif]-->
    <script src="/Public/themes/ThirdParty/AmazeUI/js/amazeui.min.js"></script>
    <script src="/Public/themes/ThirdParty/AmazeUI/js/app.js"></script>

    <!--本地样式↓-->
    <link rel="stylesheet" href="/Public/themes/WxFile/css/public.css">
    <link rel="stylesheet" href="/Public/themes/WxFile/css/login.css">
</head>
<body class="body_bg">
<div class="reg-wrap">
    <div class="reg-form">
        <div class="img-title"></div>
        <div class="am-g">
            <div class="am-u-sm-centered form_in">
                <form class="am-form" action="" method="post">
                    <fieldset class="am-form-set">
                        <div class="input_zu">
                            <i class="iconfont" style="font-size: 20px; color: #c7c7c7;">&#xe61e;</i>
                            <input type="text" name="username" value="" placeholder="用户名" class="h60l">
                        </div>
                        <div class="input_zu">
                            <i class="iconfont" style="font-size: 20px; color: #c7c7c7;">&#xe7c6;</i>
                            <input type="password" name="password" value="" placeholder="密码" class="h60l">
                        </div>
                        <div class="input_zu">
                            <i class="iconfont" style="font-size: 20px; color: #c7c7c7; top: 14px;">&#xe634;</i>
                            <input type="text" name="verify" value="" placeholder="验证码" class="h60l yz_ri">
                            <span class="yz_ma"><img src="/index.php/Admin/Login/verify"
                                                     onclick="this.src='/index.php/Admin/Login/verify/'+Math.random();"
                                                     width="120" style="cursor: pointer;"></span>
                        </div>
                    </fieldset>
                    <input type="submit" tabindex="3" value="登录" class="am-btn am-btn-block sign_btn"/>
                    <!-- <button type="submit" class="am-btn am-btn-block sign_btn" onclick="window.open('index.html')">登录</button> -->
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>