<?php
namespace Admin\Model;
use Think\Model;
class ArticleModel extends Model{
    protected $_validate = array(
     	array('username','require','用户姓名不能为空！',1), //默认情况下用正则进行验证
     	array('phone','require','联系电话不能为空！',1), //默认情况下用正则进行验证	
   );    
}