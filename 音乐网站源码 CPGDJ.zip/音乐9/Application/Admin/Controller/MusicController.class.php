<?php
namespace Admin\Controller;
use Think\Controller;
class MusicController extends CommonController {
    public function index(){
       
        if(I('get.where')){
            $where = I('get.where');
            cookie('musictitle',$where);
            $where = cookie('musictitle');
        }else{
             $where = '';
        }
       
        $where = "m.title like '%$where%'"; 

        $musicobj = M('music');
        $count      = $musicobj->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        $this->assign('page',$show);// 赋值分页输出
        $musiclist = $musicobj
                    ->field('m.id,m.title,m.zuozhe,m.des,m.pic,m.bmp,m.key,m.xiazaishu,m.dianjishu,m.addtime,m.tuijian,m.status,m.fenleititle,lp.title as lp_title')
                    ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
                    ->where($where)
                    ->order('id desc')
                    ->limit($Page->firstRow.','.$Page->listRows)
                    ->select();
        $this->assign('musiclist',$musiclist);
        $this->display();
    }

    public function add(){
        $row = array();
        if($_GET['zjid']){
            $zjid = $_GET['zjid'];
            $row['zjid'] = $zjid;
        }elseif($_GET['zipid']){
            $zipid = $_GET['zipid'];
            $row['zipid'] = $zipid;
        }elseif($_GET['tqid']){
            $tqid = $_GET['tqid'];
            $row['tqid'] = $tqid;
            
        }
        $fenleititle = $_GET['title'];
        $row[fenleititle] = $fenleititle;
        if($fenleititle ){
                $this->assign('fenleititle',$fenleititle);
        }
        if (IS_POST) {
            //上传音乐
            // print_r($_FILES);die;
            $upload = new \Think\Upload();//实例化上传类
            // $upload->exts = array('mp3');
            $upload->savePath  =      'Public/Uploads/music/'; // 设置附件上传（子）目录
            $upload->rootPath  =      './';
            $info = $upload->upload();

            $row['musicpic'] = '/'.$info['musicpic']['savepath'].$info['musicpic']['savename'];

            $row['title'] = I('post.title');
            $row['liupaiid'] = I('post.liupaiid');
            $row['des'] = I('post.des');
            $row['zuozhe'] = I('post.zuozhe');
            $row['bmp'] = I('post.bmp');
            $row['key'] = I('post.key');
            $row['tuijian'] = I('post.tuijian');
            $row['pic'] = I('post.pic')[0];
            $row['status'] = I('post.status');
            $row['addtime'] = time();
            if (M('music')->add($row)) {
                $this->success('添加成功!',U('Admin/Music/index'),1);
                exit;
            }else{
                $this->error('添加失败','',1);
                exit;
            }
        }
        $liupailist = M('liupai')->field('id,title')->select();
        $this->assign('liupailist',$liupailist);
        $this->display();
    }


    public function del(){
        if(I('get.id')){
            $musicobj = M('music');
            $musicone = $musicobj->field('musicpic,pic')->find(I('get.id'));
            if($musicobj->delete(I('get.id'))){
                $this->success('删除成功!',U('Admin/Music/index'),1);
                $file1 = $musicone['musicpic'];
                $file2 = $musicone['pic'];
                $file1 = substr($file1,1);
                $file2 = substr($file2,1);
                unlink($file1);unlink($file2);
                exit; 
            }else{
                $this->error('删除失败','',1);
                exit;
            }
        }else{
           $this->error('无效参数',U('Admin/Index/index'),1);
            exit;  
        }
    }

    public function edit(){
        $musicobj = M('music');
        $id = I('get.id');
        $musicone = $musicobj
                    ->field('m.id,m.title,m.liupaiid,m.zuozhe,m.des,m.pic,m.bmp,m.key,m.xiazaishu,m.dianjishu,m.addtime,m.status,m.tuijian,m.fenleititle,lp.title as lp_title')
                    ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
                    ->where('m.id = '.$id)
                    ->find();
        if (IS_POST) {
            $row = array();
            $row['title'] = I('post.title');
            $row['liupaiid'] = I('post.liupaiid');
            $row['des'] = I('post.des');
            $row['zuozhe'] = I('post.zuozhe');
            $row['bmp'] = I('post.bmp');
            $row['key'] = I('post.key');
            $row['tuijian'] = I('post.tuijian');
            $row['status'] = I('post.status');
           if($_FILES['musicpic']['tmp_name']){  
                $upload = new \Think\Upload();//实例化上传类
                // $upload->exts = array('mp3');
                $upload->savePath  =      'Public/Uploads/music/'; // 设置附件上传（子）目录
                $upload->rootPath  =      './';
                $info = $upload->upload();
                $row['musicpic'] = '/'.$info['musicpic']['savepath'].$info['musicpic']['savename'];
                $file1 = $musicone['musicpic'];
                $file1 = substr($file1,1);
                unlink($file1);
            }

            if(I('post.pic')[0]){
                $row['pic'] = I('post.pic')[0];
                $file1 = $musicone['pic'];
                $file1 = substr($file1,1);
                unlink($file1);
            }
            if (M('music')->where('id= '.$id)->save($row)) {
                $this->success('修改成功!',U('Admin/music/index'),1);
                exit;
            }else{
                $this->error('修改失败','',1);
                exit;
            }
        }
       
        $liupailist = M('liupai')->field('id,title')->select();
        $this->assign('liupailist',$liupailist);
        $this->assign('musicone',$musicone);
        $this->display();
    }


     public function shuxingedit(){
        if(IS_POST){
            if($_POST['shuxing'] ==  'bofang'){
                $row['dianjishu'] = I('post.val');
            }elseif($_POST['shuxing'] ==  'xiazai'){
                $row['xiazaishu'] = I('post.val');
            }
            if(M('music')->where('id ='.I('post.mid'))->save($row)){
                $data['code'] = 1;
                $data['msg'] = '修改成功!';
                exit(json_encode($data)); 
            }else{
                $data['code'] = 0;
                $data['msg'] = '修改失败!';
                exit(json_encode($data)); 
                
            }
        }else{
           $this->error('无效参数',U('Admin/Index/index'),1);
            exit;  
        }
    }
}