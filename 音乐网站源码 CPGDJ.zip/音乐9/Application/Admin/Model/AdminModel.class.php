<?php
namespace Admin\Model;

use Think\Model;

class AdminModel extends Model
{
    protected $_validate = array(
        array('username', 'require', '管理员名称不能为空！', 1), //默认情况下用正则进行验证
        array('username', '', '管理员名称不能重复！', 1, unique, 2), // 在新增的时候验证name字段是否唯一
        array('password', 'require', '管理员密码不能为空！', 1), //默认情况下用正则进行验证
        array('verify', 'verify', '验证码错误！', 1, 'callback', 4), //验证
    );

    //获取当前管理员所拥有的权限
    public function getpri($roleid)
    {
        $role = D('role');
        $pri = D('privilege');
        $role->field('rolename,pri_id_list')->find($roleid);
        session('rolename', $role->rolename);
        if ($role->pri_id_list == '*') {  //超级管理员
            session('privilege', '*');
            $menu = $pri->where("parentid=0")->select();  //顶级权限
            foreach ($menu as $k => $v) {
                $menu[$k]['sub'] = $pri->where("parentid=" . $v['id'])->select();  //当前顶级权限下的二级权限
            }
            session('menu', $menu);
        } else {  //非超级管理员
            //Admin/Admin/add, Admin/Article/add  当前登录的管理员所拥有的权限
            $pris = $pri->field('id,parentid,pri_name,mname,aname,cname,CONCAT(mname,"/",cname,"/",aname) url')->where("id IN({$role->pri_id_list})")->select();
            $_pris = array();
            $menu = array();
            foreach ($pris as $k => $v) {
                $_pris[] = $v['url'];
                if ($v['parentid'] == 0) {
                    $menu[] = $v;  //取出顶级权限
                }

            }
            session('privilege', $_pris);
            foreach ($menu as $k => $v) {
                foreach ($pris as $k1 => $v1) {
                    if ($v1['parentid'] == $v['id']) {
                        $menu[$k]['sub'][] = $v1;
                    }
                }
                session('menu', $menu);
            }
        }
    }

    //登录
    public function login()
    {
        $password = $this->password;
        $where = array('username' => $this->username);
        $info = $this->where($where)->find();
        if ($info) {
            $id = $info['id'];
            $rolename = $roles['rolename'];
            if ($info['password'] == md5($password)) {
                //数据存储到session中
                session('id', $info['id']);
                session('username', $info['username']);
                $this->getpri($info['roleid']);
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    //验证码
    public function verify($code)
    {
        $verify = new \Think\Verify();
        return $verify->check($code, '');

    }
}