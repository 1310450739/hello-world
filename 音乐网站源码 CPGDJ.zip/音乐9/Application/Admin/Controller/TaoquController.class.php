<?php
namespace Admin\Controller;
use Think\Controller;
class TaoquController extends CommonController {
    public function index(){
        $taoquobj = M('taoqu');
        $count      = $taoquobj->where('pid != 0')->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        $this->assign('page',$show);// 赋值分页输出
        $taoqulist = $taoquobj
                    ->field('id,title,des,pic,pid,link,pwd,status,daxiao,xiazaishu')
                    ->where('pid != 0')
                    ->limit($Page->firstRow.','.$Page->listRows)
                    ->order('id desc')
                    ->select();
                    // print_r($taoqulist);die;
        $taoqulistnew = $taoquobj->field('id,title')->where('pid = 0')->select();
        $data = [];
        foreach($taoqulist as $k=>$v){
            if($v['pid'] != 0){
                foreach($taoqulistnew as $key => $val){
                    if($v['pid'] == $val['id']){
                        $v['ptitle'] = $val['title'];
                        $data[] = $v;
                    }
                    // if($val['pid'] == $v['id']){
                    //     $val['ptitle'] = $v['title'];
                    // }
                }
            }
        }
        // echo'<pre>';
        // print_r($data);die;
        $this->assign('taoqulist',$data);
        $this->display();
    }


    public function add(){
        $taoquobj = M('taoqu');
        if (IS_POST) {
            $row = array();
            $row['title'] = I('post.title');
            $row['des'] = I('post.des');
            $row['link'] = I('post.link');
            $row['pwd'] = I('post.pwd');
            $row['pid'] = I('post.pid');
            $row['daxiao'] = I('post.daxiao');
            $row['pic'] = I('post.pic')[0];
            $row['status'] = I('post.status');
            $row['addtime'] = time();
            if ($taoquobj->add($row)) {
                $this->success('添加成功!',U('Admin/Taoqu/index'),1);
                exit;
            }else{
                $this->error('添加失败','',1);
                exit;
            }
        }
        $catlist = $taoquobj->field('id,title')->where('pid = 0')->select();
        $this->assign('catlist',$catlist);
        $this->display();
    }

     public function del(){
        if(I('get.id')){
            if(M('taoqu')->delete(I('get.id'))){
                $this->success('删除成功!',U('Admin/Taoqu/index'),1);

                exit; 
            }else{
                $this->error('删除失败','',1);
                exit;
            }
        }else{
           $this->error('无效参数',U('Admin/Taoqu/index'),1);
            exit;  
        }
    }

    public function edit(){
        $taoquobj = M('taoqu');
        $id = I('get.id');
        if (IS_POST) {
            $row = array();
            $row['title'] = I('post.title');
            $row['des'] = I('post.des');
            $row['daxiao'] = I('post.daxiao');
            $row['link'] = I('post.link');
            $row['pwd'] = I('post.pwd');
            $row['pid'] = I('post.pid');
            $row['status'] = I('post.status');
            if(I('post.pic')[0]){
                $row['pic'] = I('post.pic')[0];
            }
            if (M('taoqu')->where('id= '.$id)->save($row)) {
                $this->success('修改成功!',U('Admin/Taoqu/index'),1);
                exit;
            }else{
                $this->error('修改失败','',1);
                exit;
            }
        }
        $taoquone = $taoquobj->find($id);
        $this->assign('taoquone',$taoquone);
        $catlist = $taoquobj->field('id,title')->where('pid = 0')->select();
        $this->assign('catlist',$catlist);
        $this->display();
    }

    public function catlist(){   
        $taoqulist = M('taoqu')
                    ->field('id,title')
                    ->where('pid = 0')
                    ->select();
        $this->assign('taoqulist',$taoqulist);
        $this->display();
    }

    public function catadd(){
        if(IS_POST){
            $row['title'] = $_POST['title'];
            $row['addtime'] = tiem();
            if(M('taoqu')->add($row)){
                $data['code'] = 1;
                $data['msg'] = '添加成功!';
                exit(json_encode($data));
            }else{
                $data['code'] = 0;
                $data['msg'] = '添加失败!';
                exit(json_encode($data));                
            }
        }    
    }
    
    public function catdel(){
        if(I('get.id')){
            if(M('taoqu')->delete(I('get.id'))){
                $this->success('删除成功!',U('Admin/Taoqu/catlist'),1);

                exit; 
            }else{
                $this->error('删除失败','',1);
                exit;
            }
        }else{
           $this->error('无效参数',U('Admin/Taoqu/catlist'),1);
            exit;  
        }
    }

    public function catedit(){
        if (IS_POST) {
            $id = I('post.id');
            $row = array();
            $row['title'] = I('post.title');
            if (M('taoqu')->where('id= '.$id)->save($row)) {
                $data['code'] = 1;
                $data['msg'] = '修改成功!';
                exit(json_encode($data));
            }else{
                $data['code'] = 0;
                $data['msg'] = '修改失败!';
                exit(json_encode($data));   
            }
        }

    }

    public function shuxingedit(){
        if(IS_POST){
            $row['xiazaishu'] = I('post.val');
            if(M('taoqu')->where('id ='.I('post.mid'))->save($row)){
                $data['code'] = 1;
                $data['msg'] = '修改成功!';
                exit(json_encode($data)); 
            }else{
                $data['code'] = 0;
                $data['msg'] = '修改失败!';
                exit(json_encode($data)); 
                
            }
        }else{
           $this->error('无效参数',U('Admin/Index/index'),1);
            exit;  
        }
    }


}
