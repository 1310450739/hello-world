<?php
return array (
  // 'DEFAULT_MODULE' => 'Loler', // 默认模块
  'DB_TYPE' => 'mysql',
  'DB_HOST' => '127.0.0.1',
  'DB_NAME' => 'yinyue',
  'DB_USER' => 'yinyue',
  'DB_PWD' => 'b58aUCrnQJdSujsc',
  'DB_PORT' => 3306,
  'DB_CHARSET' => 'utf8',
  'DB_PREFIX' => 'bj_',
  'CONTACT' => '伯驹网',
  'TMPL_PARSE_STRING' => 
  array (
    '__ADMIN_PUC__' => __ROOT__.'/Public/themes',
  ),
); ?>