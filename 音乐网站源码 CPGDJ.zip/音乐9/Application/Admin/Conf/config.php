<?php
return array (
  'DOMAIN' => '',
  'TITLE' => '',
  'KEYWORDS' => '',
  'DESCRIPTION' => '',
  'EMAIL' => '',
  'FAX' => '',
  'QQ' => '',
  'PHONE' => '',
  'ICP' => '',
  'COPY' => '',
  'ADDRESS' => '',
  'JIEKUAN' => '',
  'CHUJIE' => '',
  'YOUBIAN' => '',
  'CONTACT' => '',
); ?>