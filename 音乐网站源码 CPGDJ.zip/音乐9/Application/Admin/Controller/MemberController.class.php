<?php
namespace Admin\Controller;
use Think\Controller;
class MemberController extends CommonController{
    public function index(){
        if(I('get.where')){
            $where = I('get.where');
            cookie('musictitle',$where);
            $where = cookie('musictitle');
        }else{
             $where = '';
        }

        $where = "bug = 0 and title like '%$where%'";

        $memberlist = M('member')
                ->field('id,title,weixin,tel,nicheng,addtime,status,dengji,daoqitime,kaishitime')
                ->where($where)
                ->order('id desc')
                ->select();
        $this->assign('memberlist',$memberlist);
        $this->display();
    }


    public function dongjie(){
        if(IS_POST){
            if(I('post.status') == 1){
                $row['status'] = 0;
            }else{
                $row['status'] = 1;
            }
            if(M('member')->where('id ='.I('post.id'))->save($row)){
                $data['code'] = 1;
                $data['msg'] = '修改成功!';
                exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            }else{
                $data['code'] = 0;
                $data['msg'] = '修改失败!';
                exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            }
        }
    }

    public function shengji(){
        $id = I('get.id');
        $title = I('get.title');
        if(IS_POST){
            $row['kaishitime'] = time();
            $row['daoqitime'] = time()+(I('post.daoqitime')*2592000);
            $row['dengji'] = 1;
            if(M('member')->where('id = '.$id)->save($row)){
                $this->success('升级成功!',U('Admin/Member/index'),1);
                die;
            }else{
                $this->error('升级失败!','',1);
                die;
            }
        }
        $this->assign('title',$title);
        $this->display();
    }

    public function del(){
        if(I('get.id')){
            $musicobj = M('member');
            if($musicobj->delete(I('get.id'))){
                $this->success('删除成功!',U('Admin/member/index'),1);
                exit; 
            }else{
                $this->error('删除失败','',1);
                exit;
            }
        }else{
           $this->error('无效参数',U('Admin/Index/index'),1);
            exit;  
        }
    }

     public function edit(){
        $id = I('get.id');
        $memeberobj = M('member');
        if(IS_POST){
            $row['kaishitime'] = strtotime(I('post.kaishitime'));
            $row['daoqitime'] = strtotime(I('post.daoqitime'));
            $row['dengji'] = I('post.dengji');
            if($memeberobj->where('id = '.$id)->save($row)){
                $this->success('修改成功!',U('Admin/Member/index'),1);
                die;
            }else{
                $this->error('修改失败!','',1);
                die;
            }
        }
        $memberone =  $memeberobj
                        ->field('id,title,daoqitime,kaishitime,dengji')
                        ->find($id);
        if($memberone['dengji'] == 1){
             $memberone['kaishitime'] = date('Y-m-d',$memberone['kaishitime']);
             $memberone['daoqitime'] = date('Y-m-d',$memberone['daoqitime']);
        }else{
             $memberone['kaishitime'] = '';
             $memberone['daoqitime'] = '';
        }
        $this->assign('member',$memberone);
        $this->display();
    }
}