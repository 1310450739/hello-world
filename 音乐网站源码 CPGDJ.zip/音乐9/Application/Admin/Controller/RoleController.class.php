<?php
namespace Admin\Controller;
use Think\Controller;
class RoleController extends CommonController{
    public function lst(){
        $role = D('role');
        $count      = $role->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        $list = $role->field('a.*,GROUP_CONCAT(b.pri_name) pri_name')->alias('a')->join('LEFT JOIN bj_privilege b ON FIND_IN_SET(b.id,a.pri_id_list)')->group('a.id')->limit($Page->firstRow.','.$Page->listRows)->select();
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->display();
    }
    public function add(){
        $role = D('role');
        $pri = D('privilege');
        $pris = $pri->pritree(); //无限级分类
        if(IS_POST){
            if($role->create()){
                $role->pri_id_list = implode(',', $role->pri_id_list);  //把传递过来的数组转换成 [10,12,13,14,...]字符串                
                if($role->add()){
                    $this->success('添加角色成功！',U('lst'));
                }else{
                    $this->error('添加角色失败！');
                }
            }else{
                $this->error($role->getError());
            }
            return;
        }
        $this->assign("pris",$pris);    
        $this->display();
    }
    public function edit(){
        $pri = D('privilege');
        $role = D('role');
        if(IS_POST){
            if($role->create()){
                $role->pri_id_list = implode(',', $role->pri_id_list);  //把传递过来的数组转换成 [10,12,13,14,...]字符串                
                if($role->save()){
                    $this->success('修改角色成功！',U('lst'));
                }else{
                    $this->error('修改角色失败！');
                }
            }else{
                $this->error($role->getError());
            }
            return;
        }
        $id = I('id');
        $roleres = $role->find($id);
        $pris = $pri->pritree(); //无限级分类
        $this->assign("pris",$pris);
        $this->assign("roleres",$roleres);
        $this->display();
    }
    public function del(){
        $id = I('id');
        $role = D('role');
        if($id == 1){
            $this->error('超级管理员角色无法删除！');
        }
        if($role->delete($id)){
            $this->success('删除角色成功！',U('lst'));
        }else{
            $this->error("删除角色失败！");
        }
    }
    public function bdel(){
        $ids = I('ids');
        if($ids){
            $key = array_search(1, $ids); //查找传递的数组值中是否有超级管理员id
            if($key !== false){  //超级管理员的id位置不确定，所以不全等于false
                unset($ids[$key]);
            }
            $ids = implode(',', $ids);
            $role = D('role');
            if($role->delete($ids)){
                $this->success('批量删除角色成功',U('lst'));
            }else{
                $this->error('批量删除角色失败！');
            }
            
        }
    }
}