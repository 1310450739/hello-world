<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title></title>
    <script src="/Public/Home/js/jquery-2.1.4.js"></script>
    <script src="/Public/Home/js/ind.js"></script>
    <script src="/Public/Home/js/sy.js"></script>
    <link rel="stylesheet" href="/Public/Home/css/audio.css" />
    <link rel="stylesheet" href="/Public/Home/font/iconfont.css" />
    <link rel="stylesheet" href="/Public/Home/css/sy.css" />

    <!--头像-->
    <link rel="stylesheet" href="/Public/Home/css/style.css" type="text/css" />
    <script src="/Public/Home/js/cropbox.js"></script>

</head>

<body>
    <div class="w100 bgh">
        <a href="" download="" id="xiazaiba"></a>
        <div class="s_nav">
            <a href="/" class="ac">
                <div class="fl logo">
                    <img src="/Public/Home/img/logo.png" style="width: 170px;">
                </div>
            </a>
            <div class="fl nav1">
                <div class="w10px">
                    <a href="/" class="ac">首页</a>
                </div>
                <div class="w10px">
                    <a href="<?php echo U('Home/member/zhuce');?>">注册</a>
                </div>

                <div class="liupai w10px">
                    <a href="">所有流派</a>
                    <div class="hidebox">
                        <?php if(is_array($liupailist)): foreach($liupailist as $key=>$liupai): ?><div class="w25">
                                <a href="<?php echo U('Home/cat/liupailist',array('lpid'=>$liupai['id']));?>">
                                    <div class="t1"><?php echo ($liupai["title"]); ?></div>
                                </a>
                                <!--<div class="t2">
                                    <div>BigRoom</div>
                                    <div>HandsUp</div>
                                    <div>Elctro</div>
                                </div>-->
                            </div><?php endforeach; endif; ?>
                        <div class="w25">
                            <a href="<?php echo U('Home/cat/djs',array('type'=>'taoqu'));?>">
                                <div class="t1">套曲专区</div>
                            </a>
                            <!--<div class="t2">
                                    <div>BigRoom</div>
                                    <div>HandsUp</div>
                                    <div>Elctro</div>
                                </div>-->
                        </div>
                        <div class="w25">
                            <a href="<?php echo U('Home/cat/djs',array('type'=>'djs'));?>">
                                <div class="t1">DJG</div>
                            </a>
                            <!--<div class="t2">
                                    <div>BigRoom</div>
                                    <div>HandsUp</div>
                                    <div>Elctro</div>
                                </div>-->
                        </div>
                        <div class="w25">
                            <a href="<?php echo U('Home/cat/djs',array('type'=>'zip'));?>">
                                <div class="t1">ZIP</div>
                            </a>
                            <!--<div class="t2">
                                    <div>BigRoom</div>
                                    <div>HandsUp</div>
                                    <div>Elctro</div>
                                </div>-->
                        </div>
                        <div class="w25">
                            <a href="<?php echo U('Home/cat/liupailist');?>">
                                <div class="t1">TOP 100</div>
                            </a>
                            <!--<div class="t2">
                                    <div>BigRoom</div>
                                    <div>HandsUp</div>
                                    <div>Elctro</div>
                                </div>-->
                        </div>
                    </div>
                </div>
                <div class="in">
                    <form action="<?php echo U('Home/index/search');?>" method="post" onsubmit="return VerifyData(); ">
                        <input type="" name="search" id="search" value="" class="fl" />
                        <button class="fl s_biso" type="submit"><img src="/Public/Home/img/sousuo.png"></button>
                    </form>
                </div>
            </div>
            <style>
                .s_biso {
                    width: 40px;
                    height: 40px;
                    background: none;
                    border: none
                }
                
                .s_biso img {
                    margin: 0 auto
                }
            </style>
            <div class="fr s_dl s_kil">
                <a href="<?php echo U('Home/member/zifei');?>">
                    <div class="box"><i class="icon Hui-iconfont" style="font-size: 30px;">&#xe673; </i>会员资费</div>
                </a>
            </div>

            <?php if($title != ''): ?><div class="fr s_dl">
                    <a href="<?php echo U('Home/member/index');?>">
                        <div class="box"><i class="icon Hui-iconfont" style="font-size: 30px;">&#xe62c; </i><?php echo ($title); ?></div>
                    </a>
                </div>
                <?php else: ?>
                <div class="fr s_dl">

                    <div class="box addbac"><i class="icon Hui-iconfont" style="font-size: 30px;">&#xe62c; </i>登录</div>
                    <div class="denglu123">
                        <div class="dlss">
                            <div>账号:</div>
                            <input type="text" name="title" />
                        </div>
                        <div class="dlss">
                            <div>密码:</div>
                            <input type="password" name="pwd" />
                        </div>
                        <div class="s_dengl" onclick="denglu()">登录</div>
                    </div>
                </div><?php endif; ?>
            <a href="<?php echo U('Home/member/index');?>">
                <div class="fr s_dl">
                    <div class="boximg fl" style="margin-right:10px;"><img src="/Public/Home/img/logo132.png"></div>
                    <div class="fl" style="line-height: 50px;">VIP DJ</div>
                    <div class="s_xinxi s_nnn">
                        <img src="/Public/Home/img/lomn.png" style="width:180px">
                        <div>©2012-2017 cpgdj.com。版权所有。</div>
                        <div>863472171＃qq.com @ /＃</div>
                    </div>
                </div>
            </a>
        </div>
    </div>
    <script>
        function VerifyData() {
            if ($('#search').val() == '') {
                return false;
            }
        }
    </script>

    <script>
        function denglu() {
            var title = $("input[name='title']").val();
            var pwd = $("input[name='pwd']").val();
            if (!title && !pwd) {
                alert('帐号密码不能为空!')
                return false;
            } else {
                var row = {
                        'title': title,
                        'pwd': pwd,
                    }
                    //获取当前域名
                var http = window.location.host;
                $.ajax({
                    url: "http://" + http + "/index.php/Home/member/denglu",
                    type: "post",
                    data: row,
                    dataType: "json",
                    success: function(data) {
                        // alert(data)
                        if (data.code == 1) {
                            alert(data.msg)
                                // window.location.href = "http://" + http;
                            window.location.reload();
                        } else {
                            alert(data.msg)
                        }
                    },
                    error: function(data) {
                        alert('登陆失败!');
                        // window.location.reload();
                    }
                });
            }

        }
    </script> <div class="w1200">
    <div class="titep">头像上传</div>
</div>

<div class="w1200 w_sin">
    <div class="htmleaf-container">
        <div class="container">
            <div class="imageBox">
                <div class="thumbBox"></div>
                <div class="spinner" style="display: none">Loading...</div>
            </div>
            <div class="action">
                <div class="new-contentarea tc">
                    <a href="javascript:void(0)" class="upload-img">
                        <label for="upload-file">上传图像</label>
                    </a>
                    <input type="file" class="" name="upload-file" id="upload-file" />
                </div>
                <input type="button" id="btnCrop" class="Btnsty_peyton" value="裁切">
                <input type="button" id="btnZoomIn" class="Btnsty_peyton" value="+">
                <input type="button" id="btnZoomOut" class="Btnsty_peyton" value="-">
            </div>
            <div class="cropped"></div>
            <div class="shangchuan"><input type="button" value="保存" onclick="photo()" style="width:100%;height:50px;     font-size: 20px; background: #777;border: none;color: #fff;padding: 10px;border-radius: 5px;"></div>
        </div>
    </div>

</div>



</body>
<script type="text/javascript">
    $(window).load(function() {
        var options = {
            thumbBox: '.thumbBox',
            spinner: '.spinner',
            imgSrc: ''
        }
        var cropper = $('.imageBox').cropbox(options);
        $('#upload-file').on('change', function() {
            var reader = new FileReader();
            reader.onload = function(e) {
                options.imgSrc = e.target.result;
                cropper = $('.imageBox').cropbox(options);
            }
            reader.readAsDataURL(this.files[0]);
            this.files = [];
        })
        $('#btnCrop').on('click', function() {
            var img = cropper.getDataURL();
            $('.cropped').html('');
            // $('.cropped').append('<img src="' + img + '" align="absmiddle" style="width:64px;margin-top:4px;border-radius:64px;box-shadow:0px 0px 12px #7E7E7E;" ><p>64px*64px</p>');
            // $('.cropped').append('<img src="' + img + '" align="absmiddle" style="width:128px;margin-top:4px;border-radius:128px;box-shadow:0px 0px 12px #7E7E7E;"><p>128px*128px</p>');
            $('.cropped').append('<img id="img1" src="' + img + '" align="absmiddle" style="width:180px;margin-top:4px;border-radius:180px;box-shadow:0px 0px 12px #7E7E7E;"><p>180px*180px</p>');
        })
        $('#btnZoomIn').on('click', function() {
            cropper.zoomIn();
        })
        $('#btnZoomOut').on('click', function() {
            cropper.zoomOut();
        })
    });
</script>
<script type="text/javascript">
    function photo() {
        var img1 = $('#img1').attr('src')

        //获取当前域名
        var http = window.location.host;
        $.ajax({
            type: "post",
            url: "http://" + http + "/Home/Member/touxiang",
            async: true,
            data: {
                img: img1
            },
            dataType: "json",
            success: function(data) {
                // alert(data);
                if (data.code == 1) {

                    alert(data.msg);
                    self.location.href = "http://" + http + "/Home/Member/index";
                    // window.location.reload();
                } else {
                    alert(data.msg);
                }

            },
            error: function(data) {

                alert('系统繁忙!');
                // window.location.reload();
            }
        });
    }
</script>

</html>
<!--音乐播放器-->
<div class="min">
    <div class="w1200" style="width:100%">
        <div class="min1">
            <div class="minone fl">
                <img src="/Public/Home/img/m1.png">
            </div>
            <div class="mintwo fl">
                <div></div>
                <div class="ko"></div>
            </div>
        </div>
        <div class="box2">
            <div class="sj"></div>
        </div>
        <div class="box2 chixusj">
            <div class="sj1">sss</div>
        </div>
        <div id="s_bfq"></div>
        <div class="boxxinxi"><img src="/Public/Home/img/jp.png"></div>
        <div class="box2">
            <div class="xiazai">
                <a href="javascrript:void(0);" class="ahre" id="dibuxiazai" mid=""></a>
                <i class="icon Hui-iconfont ani">&#xe674;</i>
            </div>
        </div>
        <div class="box3 xin" id="dianxin" mid=""><i class="icon Hui-iconfont ">&#xe648;</i></div>
        <div class="box4 yinliang">
            <div class="yin1"><img src="/Public/Home/img/yinliang.png"></div>
            <div class="tiaozhang">
                <div class="ziji"></div>
            </div>
        </div>
        <div class="box5 shangxia" id="shangyige" sx='s'><img src="/Public/Home/img/prev.png" /></div>
        <div class="boxbofang"></div>
        <div class="box5 shangxia" id="xiayige" sx='x'><img src="/Public/Home/img/next.png" /></div>

        <div class="boxlist"><img src="/Public/Home/img/dh.png"></div>
    </div>
</div>
<div class="lom">
    <div class="w1200">
        <div class="sk">
            <img src="" alt="" class="imgpath" />
            <div class="olx">
                <div>歌曲：Black Tiger Sex Machine＆Apashe Swing High（AK9 Remix）</div>
                <div>流派：BigRoom / Electro</div>
                <div>速度：BigRoom / Electro</div>
                <div>音调：5A</div>
                <div>时间：2017年6月21日</div>
                <div>试听：1153次</div>
                <div>时下载：027次</div>
            </div>
        </div>
    </div>
</div>
<div class="lom1">
    <div class="w1200" style="float:right;width:1090px;height:240px; overflow-y: scroll; float:left; margin:0;margin-left:245px;">
        <div class="sk1">


        </div>
    </div>
</div>
<!--音乐播放器-->

<div class="footer">
    <div class="w1200m">
        <div class="first">
            <a href="http://www.twitter.com"><img src="/Public/Home/img/1  twitter.com.jpg"></a>
            <a href="http://www.facebook.com"><img src="/Public/Home/img/2  www.facebook.com.jpg"></a>
            <a href="http://www.youtube.com"><img src="/Public/Home/img/3 www.youtube.com.jpg"></a>
            <a href="http://www.open.spotify.com"><img src="/Public/Home/img/3  open.spotify.combrowse.jpg"></a>
        </div>
        <div class="index2">
            <div class="index2a">厂牌同步</div>
            <div class="index2b">
                <a href="http://www.rukes.com"><img src="/Public/Home/img/min4.png"></a>
                <a href="http://www.tomorrowland.com"><img src="/Public/Home/img/min2.png"></a>
                <a href="http://www.spinninrecords.com"><img src="/Public/Home/img/min18.png"></a>
                <a href="http://www.revealedrecordings.com"><img src="/Public/Home/img/min15.png"></a>
                <a href="http://www.armadamusic.com"><img src="/Public/Home/img/min14.png"></a>
                <a href="http://www.monstercat.com"><img src="/Public/Home/img/min11.png"></a>
                <a href="http://www.mixmashrecords.com"><img src="/Public/Home/img/min9.png"></a>
                <a href="http://www.owsla.com"><img src="/Public/Home/img/min8.png"></a>
                <a href="http://www.www.flashoverrecordings.com"><img src="/Public/Home/img/min13.png"></a>
                <a href="http://www.bbc.com"><img src="/Public/Home/img/min5.png"></a>
                <a href="http://www.www.billboard.com"><img src="/Public/Home/img/min7.png"></a>
                <a href="http://www.classic.beatport.com"><img src="/Public/Home/img/min6.png"></a>
                <a href="http://www.yd111.cn"><img src="/Public/Home/img/min10.png"></a>
                <a href="http://www.protocolrecordings.com"><img src="/Public/Home/img/min20.jpg"></a>
                <!--<a href="http://www.bbc.com"><img src="/Public/Home/img/min11.png"></a>-->

            </div>
        </div>
        <div class="index3">
            <div class="index2a">CPGDJ音乐网</div>
            <div><img src="/Public/Home/img/logo.png" style="margin:15px 0"></div>
            <div>©2012-2017 CPGDJ.com。版权所有。</div>
            <div>2755621683@qq.com</div>
            <div><img src="/Public/Home/img/44251435651176.png"></div>
        </div>
    </div>
</div>

</body>
<script>
</script>

</html>