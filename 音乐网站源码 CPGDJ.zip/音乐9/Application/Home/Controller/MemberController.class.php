<?php 
namespace Home\Controller;
use Think\Controller;
class MemberController extends CommonController
{
    public function index(){
        if(!$_SESSION['member']){
             $this->redirect('/');
        }
        //到期时间
        $member = M('member')->field('id,dengji,kaishitime,daoqitime,status')->find($_SESSION['member']['id']);
        if($member['dengji'] == 1){ 
             $member['sheng'] = ceil(($member['daoqitime']-time())/86400).' 天';
        }else{
              $member['sheng']='';
        }
        $this->assign('member',$member);

        //套餐
        $taocanlist = M('taocan')->where('status = 0')->order('id')->select();
        $this->assign('taocanlist',$taocanlist);

        $mid =  $member['id'];
        // 下载记录
         $xzlist = M('music')
                    ->field('m.title,m.id,m.zuozhe,m.pic,m.musicpic,m.dianjishu,m.xiazaishu,m.bmp,m.key,m.addtime,lp.title as lptitle,xz.id as xzid')
                    ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
                    ->join('bj_xiazai as xz on xz.muid = m.id')
                    ->where('xz.mid ='.$mid)
                    ->order('id desc')
                    ->select();
        $this->assign('xzlist',$xzlist);
        //收藏记录
        $sclist = M('music')
                    ->field('m.title,m.id,m.zuozhe,m.pic,m.musicpic,m.dianjishu,m.xiazaishu,m.bmp,m.key,m.addtime,lp.title as lptitle ,sc.id as scid')
                    ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
                    ->join('bj_shoucang as sc on sc.muid = m.id')
                    ->where('sc.mid ='.$mid)
                    ->order('id desc')
                    ->select();
        $this->assign('sclist',$sclist);
        $this->display();
    }


    public function zhuce(){
        if(IS_POST){
            if(I('post.pwd') == I('post.pwd1')){
                $memberobj = M('member'); 
                $title = I('post.title');
                $memberone =  $memberobj->where("title ='$title'") ->find();
                if($memberone){
                    $data['code'] = 0;
                    $data['msg'] = '该帐号已被注册!';
                    exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
                }
                $row['title']  = trim(I('post.title'));
                $row['pwd']  = md5(trim(I('post.pwd')));
                $row['weixin']  = trim(I('post.weixin'));
                $row['sex']  = md5(trim(I('post.sex')));
                $row['xingzuo']  = I('post.xingzuo');
                $row['addtime']  = time();
                if(M('member')->add($row)){
                    $data['code'] = 1;
                    $data['msg'] = '恭喜您'. $row['title'].'注册成功!';
                     exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
                   
                }else{
                    $data['code'] = 0;
                    $data['msg'] = '注册失败!';
                     exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));                
                }
            }else{
                $data['code'] = 0;
                $data['msg'] = '两次密码不一致!';
                 exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            }
               
            
        }
        $this->display();
    }
    
    
    public function uppwd(){
        if(!$_SESSION['member']){
             $this->redirect('/');
        }
        if(IS_POST){
            if(I('post.pwd1') == I('post.pwd2')){
                    $memberobj = M('member'); 
                    $title = $_SESSION['member']['title'];
                    $pwd = md5(I('post.pwd'));
                    $memberone =  $memberobj->where('title ='.$title) ->find();
                    if($memberone['pwd'] != $pwd){
                        $data['code'] = 0;
                        $data['msg'] = '原密码错误!';
                        exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
                    }
                    $row['pwd']  = md5(trim(I('post.pwd1')));
                    if($memberobj->where('id = '.$memberone['id'])->save($row)){
                        $data['code'] = 1;
                        $data['msg'] = '修改成功!';
                        session('member',null);
                        exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
                    }else{
                        $data['code'] = 0;
                        $data['msg'] = '修改失败!';
                        exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));                
                    }
                }else{
                    $data['code'] = 0;
                    $data['msg'] = '两次密码不一致!';
                    exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
                }
        }     
        $this->display();
    }
    
    
    public function upzl(){
        if(!$_SESSION['member']){
             $this->redirect('/');
        }
        $member = session('member');
        $id = $_SESSION['member']['id'];
        if(IS_POST){
            $row['nicheng'] = I('post.nicheng');
            $row['tel'] = I('post.tel');
            $row['weixin'] = I('post.weixin');
            $row['sex'] = I('post.sex');
            $row['xingzuo'] = I('post.xingzuo');
            $member['nicheng'] =  $row['nicheng'];
            $member['tel'] = $row['tel'] ;
            $member['weixin'] =  $row['weixin'];
            $member['sex'] =  $row['sex'];
            $member['xingzuo'] = $row['xingzuo'];
            if(M('member')->where('id = '.$id)->save($row)){
                $data['code'] = 1;
                $data['msg'] = '修改成功!';
                session('member',$member);
                exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            }else{
                $data['code'] = 0;
                $data['msg'] = '修改失败!';
                exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));                
            }
        } 
        $memberone = M('member')->field('title,id,weixin,tel,xingzuo,sex,nicheng')->find($id);
        $this->assign('memberone',$memberone);
        $this->display();
    }


    public function denglu(){
        if(IS_POST){  
            session('member',null);
            $memberobj = M('member'); 
            $title = trim(I('post.title')); 
            $pwd = md5(trim(I('post.pwd')));
            $memberone =  $memberobj->where("title ='$title'and pwd = '$pwd'") ->find();
            if(!$memberone){
                $data['code'] = 0;
                $data['msg'] = '用户名密码错误!';
                exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            }else{
                if($memberone['bug'] == 0){
                    if($memberone['status'] == 1){
                        $data['code'] = 0;
                        $data['msg'] = '该账户已被冻结!';
                        exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
                    }elseif($memberone['dengji'] == 1 && $memberone['daoqitime']<time()){
                        $row['dengji'] = 0;
                        $memberobj->where('id ='. $memberone['id'])->save($row);
                    }
                }
                $data['code'] = 1;
                $data['msg'] = '欢迎回来【'.$memberone['title'].'】!';
                $member['title'] = $memberone['title'];
                $member['id'] = $memberone['id'];
                $member['weixin'] = $memberone['weixin'];
                $member['xingzuo'] = $memberone['xingzuo'];
                $member['nicheng'] = $memberone['nicheng'];
                $member['dengji'] = $memberone['dengji'];
                $member['touxiang'] = $memberone['phone'];
                $member['kaishitime'] = $memberone['kaishitime'];
                $member['daoqitime'] = $memberone['daoqitime'];
                $_SESSION['member'] = $member;
                exit(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            }
        }   
    }


    public function pay(){
        if(!$_SESSION['member']){
             $this->redirect('/');
        }
        $orderobj = M('order');
        $mid = $_SESSION[member][id];
        $orderone = $orderobj->where("mid =  $mid and status = 0")->find();
        if(!$orderone){
            $memberone = M('member')->find($mid);
            if($memberone['bug'] == 0){
                $row['tid'] = I('get.id');
                $row['mid'] = $mid;
                $row['addtime'] = time();
                $orderobj->add($row);
            }
        }
        $this->display();
    }


    public function touxiang(){
        if(!$_SESSION['member']){
             $this->redirect('/');
        }
        $member = session('member');
        if (IS_POST) {
            $img = explode(',', I('post.img'));
            // svar_dump($img);die;
            $img = base64_decode($img[1]);
            $savepath = __ROOT__ . 'public/uploads/userphoto/'.$member['title'];
            if (is_dir($savepath)) {
                $path = __ROOT__ . 'public/uploads/userphoto/'."$member[title]";
            }else{
                mkdir( __ROOT__ . 'public/uploads/userphoto/'.$member['title']);
                $path = __ROOT__ . 'public/uploads/userphoto/'."$member[title]";
            }
            $title = time().mt_rand('111111','999999');
            if (file_put_contents($path.'/'.$title.'.jpg', $img)) {
                $row['phone'] = '/public/uploads/userphoto/'.$member['title'].'/'.$title.'.jpg';

                if (M('member')->where('id ='.$member['id'])->save($row)) {
                    $arr['code'] = 1;
                    $arr['msg'] = '保存成功!';
                    $member['touxiang'] = $row['phone'];
                    session('member',$member);
                    exit(json_encode($arr));
                }else{
                    $arr['code'] = 0;
                    $arr['msg'] = '保存失败!';
                    exit(json_encode($arr));
                }
            }else{
                $arr['code'] = 0;
                $arr['msg'] = '保存失败2!';
                exit(json_encode($arr));
            }
        }
        $this->display();
    }

    public function del(){
        if(!$_SESSION['member']){
             $this->redirect('/');
        }
        if(IS_POST){
            if(I('post.type') == 'sc'){
                $obj = M('shoucang');
            }else if(I('post.type') == 'xz'){
                $obj = M('xiazai');
            }
            if($obj->delete(I('post.id'))){
                $data['code'] = 1;
                $data['msg'] = '删除成功!';
                exit(json_encode($data));
            }else{
                $data['code'] = 0;
                $data['msg'] = '删除失败!';
                exit(json_encode($data));
            }

        }else{
             $this->redirect('/');
        }
    }
    public function zifei(){
       //套餐
        $taocanlist = M('taocan')->where('status = 0')->order('id')->select();
        $this->assign('taocanlist',$taocanlist);

        $this->display();
    }


    public function logout(){
        session('member',null);
        $this->redirect('/');
    }
}