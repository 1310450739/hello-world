<?php
namespace Admin\Controller;
use Think\Controller;
class MvController extends CommonController {
    public function index(){
        $mvobj = M('mv');
        $count      = $mvobj->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        $this->assign('page',$show);// 赋值分页输出
        $mvlist = $mvobj
                    ->field('id,title,pic,addtime,status')
                    ->order('id desc')
                    ->limit($Page->firstRow.','.$Page->listRows)
                    ->select();
        $this->assign('mvlist',$mvlist);
        $this->display();
    }

    public function add(){
        $row = array();
        if (IS_POST) {
            //上传音乐
            // print_r($_FILES);die;
            $upload = new \Think\Upload();//实例化上传类
            // $upload->exts = array('mp4,flv');
            $upload->savePath  =      'Public/Uploads/mv/'; // 设置附件上传（子）目录
            $upload->rootPath  =      './';
            $info = $upload->upload();

            $row['mvpic'] = '/'.$info['musicpic']['savepath'].$info['musicpic']['savename'];

            $row['title'] = I('post.title');
            $row['status'] = I('post.status');
            $row['pic'] = I('post.pic')[0];
            $row['addtime'] = time();
            if (M('mv')->add($row)) {
                $this->success('添加成功!',U('Admin/Mv/index'),1);
                exit;
            }else{
                $this->error('添加失败','',1);
                exit;
            }
        }
        $liupailist = M('liupai')->field('id,title')->select();
        $this->assign('liupailist',$liupailist);
        $this->display();
    }


    public function del(){
        if(I('get.id')){
            $mvobj = M('mv');
            $mvone = $mvobj->field('mvpic,pic')->find(I('get.id'));
            if($mvobj->delete(I('get.id'))){
                $file1 = $mvone['mvpic'];
                $file2 = $mvone['pic'];
                $file1 = substr($file1,1);
                $file2 = substr($file2,1);
                unlink($file1);unlink($file2);

                $this->success('删除成功!',U('Admin/Mv/index'),1);
                exit; 
            }else{
                $this->error('删除失败!','',1);
                exit;
            }
        }else{
           $this->error('无效参数',U('Admin/Index/index'),1);
            exit;  
        }
    }

    public function edit(){
        $mvobj = M('mv');
        $id = I('get.id');
        $mvone = $mvobj
                ->field('id,title,mvpic,pic')
                ->find();

        if (IS_POST) {
            $row = array();
            $row['title'] = I('post.title');
            $row['status'] = I('post.status');
           if($_FILES['musicpic']['tmp_name']){  
                $upload = new \Think\Upload();//实例化上传类
                // $upload->exts = array('mp3');
                $upload->savePath  =      'Public/Uploads/mv/'; // 设置附件上传（子）目录
                $upload->rootPath  =      './';
                $info = $upload->upload();
                $row['mvpic'] = '/'.$info['musicpic']['savepath'].$info['musicpic']['savename'];
                $file1 = $mvone['mvpic'];
                $file1 = substr($file1,1);
                unlink($file1);
            }

            if(I('post.pic')[0]){
                $row['pic'] = I('post.pic')[0];
                $file1 = $mvone['mvpic'];
                $file1 = substr($file1,1);
                unlink($file1);
            }
            if (M('mv')->where('id= '.$id)->save($row)) {
                $this->success('修改成功!',U('Admin/mv/index'),1);
                exit;
            }else{
                $this->error('修改失败','',1);
                exit;
            }
        }
        $this->assign('mvone',$mvone);
        $this->display();
    }

}