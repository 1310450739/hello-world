<?php
namespace Admin\Controller;
use Think\Controller;
class LoginController extends Controller{
    public function index(){
        $admin = D('admin');
        if(IS_POST){
            if($admin->create($_POST,4)){
                if($admin->login()){
                    $this->success('登录中...',U('index/index'));
                }else{
                    $this->error("用户名或密码错误！");
                }
            }else{
                $this->error($admin->getError());
            }
            return;
        }      
        $this->display();
    }
    //后台登录验证码
    public function verify(){
        $Verify = new \Think\Verify();
        $Verify->length   = 4;  //验证码长度4位
        $Verify->entry();
    }
}