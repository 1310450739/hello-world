<?php
namespace Admin\Controller;
use Think\Controller;
class TaocanController extends CommonController{
    public function index(){
        $taocan = M('taocan'); // 实例化视图对象
        $count      = $taocan->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $taocanlist = $taocan->limit($Page->firstRow.','.$Page->listRows)->order('id ')->select();
        $this->assign('taocanlist',$taocanlist);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->display();
    }

    //添加
    public function add(){
        if(IS_POST){
            $row['title'] = I('post.title');
            $row['des1'] = I('post.des1');
            $row['des2'] = I('post.des2');
            $row['des3'] = I('post.des3');
            $row['des4'] = I('post.des4');
            $row['des5'] = I('post.des5');
            $row['price'] = trim(I('post.price'));
            $row['pic'] = I('post.pic')[0];
            $row['status'] = I('status');
            $row['addtime'] = time();
            if (M('taocan')->add($row)) {
                $this->success('添加成功！',U('Admin/Taocan/index'),1);
                exit;
            }else{
                $this->error('添加失败');
                exit;
            }
        }
        $this->display();
    }

      //单个删除
    public function del($id){
        if(I('get.id')){
            if(M('taocan')->delete(I('get.id'))){
                $this->success('删除成功!',U('Admin/Taocan/index'),1);

                exit; 
            }else{
                $this->error('删除失败','',1);
                exit;
            }
        }else{
           $this->error('无效参数',U('Admin/Index/index'),1);
            exit;  
        }
    }

    //修改
    public function edit(){      
        $taocanobj = M('taocan');
        $id = I('get.id');
        if(IS_POST){
            $row = array();
            $row['title'] = I('post.title');
            $row['des1'] = I('post.des1');
            $row['des2'] = I('post.des2');
            $row['des3'] = I('post.des3');
            $row['des4'] = I('post.des4');
            $row['des5'] = I('post.des5');
            $row['price'] = trim(I('post.price'));
            $row['status'] = I('status');
            if(I('post.pic')[0]){
                $row['pic'] = I('post.pic')[0];
            }
            if (M('taocan')->where('id= '.$id)->save($row)) {
                $this->success('修改成功!',U('Admin/Taocan/index'),1);
                exit;
            }else{
                $this->error('修改失败','',1);
                exit;
            }
        }
        $taocanone = $taocanobj->find($id);
        $this->assign('taocanone',$taocanone);
        $this->display();
    }
  
    //批量删除 
    public function bdel(){
        $ids = I('ids');
        $ids = implode(',', $ids); //转换成字符串用逗号隔开
        $vip = D('user_vip');
        if($ids){
            if($vip->delete($ids)){
                $this->success("批量删除成功！",U('lst'));
            }else{
                $this->error("批量删除失败！");
            }
        }else{
            $this->error("您未选中任何数据！");
        }
    }

}