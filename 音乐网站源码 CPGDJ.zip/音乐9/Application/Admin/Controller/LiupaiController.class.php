<?php
namespace Admin\Controller;
use Think\Controller;
class LiupaiController extends CommonController {
    public function index(){
        $liupaiobj = M('liupai');
        $count      = $liupaiobj->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        $this->assign('page',$show);// 赋值分页输出
        $liupailist = $liupaiobj
                    ->field('id,title,des,pic,status,type')
                    ->limit($Page->firstRow.','.$Page->listRows)
                    ->order('id desc')
                    ->select();
        $this->assign('liupailist',$liupailist);
        $this->display();
    }

    public function add(){
       if (IS_POST) {
            $row = array();
            $row['title'] = I('post.title');
            $row['des'] = I('post.des');
            $row['pic'] = I('post.pic')[0];
            $row['status'] = I('post.status');
            $row['type'] = I('post.type');
            $row['addtime'] = time();
            if (M('liupai')->add($row)) {
                $this->success('添加成功!',U('Admin/Liupai/index'),1);
                exit;
            }else{
                $this->error('添加失败','',1);
                exit;
            }
        }
        $this->display();
    }


    public function del(){
        if(I('get.id')){
            if(M('liupai')->delete(I('get.id'))){
                $this->success('删除成功!',U('Admin/Liupai/index'),1);

                exit; 
            }else{
                $this->error('删除失败','',1);
                exit;
            }
        }else{
           $this->error('无效参数',U('Admin/Index/index'),1);
            exit;  
        }
    }

    public function edit(){
        $liupaiobj = M('liupai');
        $id = I('get.id');
        if (IS_POST) {
            $row = array();
            $row['title'] = I('post.title');
            $row['des'] = I('post.des');
            $row['status'] = I('post.status');
            $row['type'] = I('post.type');
            if(I('post.pic')[0]){
                $row['pic'] = I('post.pic')[0];
            }
            if (M('liupai')->where('id= '.$id)->save($row)) {
                $this->success('修改成功!',U('Admin/Liupai/index'),1);
                exit;
            }else{
                $this->error('修改失败','',1);
                exit;
            }
        }
        $liupaione = $liupaiobj->find($id);
        $this->assign('liupaione',$liupaione);
        $this->display();
    }
}