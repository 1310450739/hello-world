<?php 
namespace Home\Controller;
use Think\Controller;
class CommonController extends Controller
{
    public function _initialize(){  
         // 所有流派
        $title = '';
        if($_SESSION['member']['nicheng']){
            $title = $_SESSION['member']['nicheng'];
        }elseif($_SESSION['member']['title']){
             $title = $_SESSION['member']['title'];
        }
        $liupailist = M('liupai')->where('status = 0')->order('id ')->select();
        $this->assign('title',$title);
        $this->assign('liupailist', $liupailist);

        //会员冻结判断
        $member = M('member')->field('status')->find($_SESSION['member']['id']);
        if($member['status'] == 1){
            session('member',null);
        }
    }

    
    public function jcsc($arr1 = array()){
        // 收藏查看
        if($_SESSION['member']){
            $wdsc = M('shoucang')->where('mid ='.$_SESSION['member']['id'])->select();
                foreach($arr1 as $k=>$v){
                foreach($wdsc as $sck=>$scv){
                    if($v['id'] == $scv['muid']){
                        $arr1[$k]['sc'] = 1;
                    }
                }
            }
        }
        return $arr1;
    }
}