<?php
namespace Admin\Controller;
use Think\Controller;
class PrivilegeController extends CommonController{
    public function lst(){
        header('content-type:text/html;charset=utf-8');
    	$pri = D('privilege');
        $pris = $pri->pritree(); //无限级分类       
        $this->assign('pris',$pris);
        $this->display();
    }
    public function add(){
        $pri = D('privilege');
        $pris = $pri->pritree(); //无限级分类
        if(IS_POST){
            if($pri->create()){
                if($pri->add()){
                    $this->success("添加权限成功！",U('lst'));
                }else{
                    $this->error('添加权限失败！');
                }
            }else{
                $this->error($pri->getError());
            }

            return;
        } 
        $this->assign("pris",$pris);
        $this->display();
    }
    public function edit(){
        $id = I('id');
        $pri = D('privilege');
        $prires = $pri->find($id);
        $pris = $pri->pritree(); 
        if(IS_POST){
            if($pri->create()){
                if($pri->save()){
                    $this->success("修改权限成功！",U('lst'));
                }else{
                    $this->error('修改权限失败！');
                }
            }else{
                $this->error($pri->getError());
            }

            return;
        }
        $this->assign("pris",$pris);
        $this->assign("prires",$prires);
        $this->display();
    }
    //单个删除
    public function del(){
        $pri = D('privilege');
        $id = I('id');
        if($pri->delete($id)){
            $this->success('成功删除权限！',U('lst'));

        }else{
            $this->error('删除权限失败！');
        }
    }
    //批量删除
    public function bdel(){
        $ids = I('ids');
        $pri = D('privilege');
        $ids = implode(',', $ids); //1,2,3,4
        // var_dump($ids);
        // die;
        if($ids){
            if($pri->delete($ids)){
                $this->success('批量删除权限成功！',U('lst'));
            }else{
                $this->error('批量删除权限失败！');
            }
        }else{
            $this->error("未选中任何内容！");
        }
    }
}