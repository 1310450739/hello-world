<?php
namespace Admin\Controller;
use Think\Controller;
class UsersController extends CommonController{
    public function lst(){
        $user = D('user'); // 实例化视图对象
        //搜索
        $where = 1;
        if($keywords = I('keywords')){
            $where .= ' AND username LIKE "%'.$keywords.'%" ';
        }
        $count      = $user->where($where)->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = $user->where($where)->limit($Page->firstRow.','.$Page->listRows)->order("addtime desc")->select();
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->display();
    }
    //添加
    public function add(){
        $user = D('user');
        if(IS_POST){
            if ($a = $user->where( array('phone' => trim(I('phone'))))->find()) {
                $this->error('手机号已存在');
            }
            if (trim(I('pwd')) != trim(I('pwd1'))) {
                $this->error('两次密码输入不一致');
            }
            $data['phone'] = trim(I('phone'));
            $data['pwd'] = md5(trim(I('pwd')));
            $data['username'] = trim(I('username'));
            $data['money'] = trim(I('money'));
            $data['addtime'] = time();
            if($user->create($data)){
                if($uid = $user->add()){
                    if (D('user_info')->add(array('uid' => $uid))) {
                        $this->success('新增用户成功！',U('lst'));
                    }else{
                        $user->delete($uid);
                        $this->error('新增用户失败');
                    }
                }else{
                    $this->error('新增用户失败');
                }
            }else{
                $this->error($user->getError());
            }
            return;
        }
        $this->assign('username',$this->getUser());
        $this->display();
    }
    //修改
    public function edit($id){
        $user = D('user');
        $info = $user->field('bjw_user.*,bjw_user_info.*')
                     ->join('bjw_user_info on bjw_user.id=bjw_user_info.uid')
                     ->where(array('bjw_user.id' => $id ))->find();
        if(IS_POST){
           
            if($user->create(I('post.'))){
                if($user->save()){
                    $this->success('修改用户成功！',U('lst'));
                }else{
                    $this->error('修改用户失败');
                }
            }else{
                $this->error($user->getError());
            }
            return;
        }
        $this->assign("userres",$info);
        $this->display();
    }
    //单个删除
    public function del($id){
        $user = D('user');
        if($user->delete($id) && $user->where(array('uid' => $id))->delete()){
            $this->success("删除用户成功！",U('lst'));
        }else{
            $this->error("删除用户失败！");
        }
    }
    //批量删除
    public function bdel(){
        $ids = I('ids');
        $ids = implode(',', $ids); //转换成字符串用逗号隔开
        $user = D('user');
        if($ids){
            if($user->delete($ids) && $user->where(array('uid' => $ids))->delete()){
                $this->success("批量删除用户成功！",U('lst'));
            }else{
                $this->error("批量删除用户失败！");
            }
        }else{
            $this->error("您未选中任何数据！");
        }
    }

    //查看用户详情
    public function userinfo($id){
        $user = D('user');
        $info = $user->field('bjw_user.*,bjw_user_info.*')
                     ->join('bjw_user_info on bjw_user.id=bjw_user_info.uid')
                     ->where(array('bjw_user.id' => $id ))->find();
        // print_r($info);
        $this->assign("userinfo",$info);
        $this->display();
    }

    //搜索用户编号是否存在
    public function getUser(){
        $username = $this->getUserNumber();
        $user = D('user');
        $where = array('username' => $username);
        if ($user->where($where)->find()) {
            return false;
        }else{
            return $username;
        }
    }
}