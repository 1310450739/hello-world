<?php
namespace Admin\Model;
use Think\Model;
class PrivilegeModel extends Model{
    protected $_validate = array(
     	array('pri_name','require','权限名称不能为空！',1), //默认情况下用正则进行验证
     	array('mname','require','模块名称不能为空！',1), //默认情况下用正则进行验证
     	array('cname','require','控制器名称不能为空！',1), //默认情况下用正则进行验证
     	array('aname','require','方法名称不能为空！',1), //默认情况下用正则进行验证
     	array('pri_name','','权限名称不能重复！',1,unique), // 在新增的时候验证name字段是否唯一  
   ); 
   public function pritree(){
    	$data = $this->select();
    	return $this->resort($data);
    }
    public function resort($data,$parentid=0,$level=0){
    	static $ret = array();
    	foreach ($data as $k => $v){
    		if($v['parentid']==$parentid){
    			$v['level'] = $level;
    			$ret[] = $v;
    			$this->resort($data,$v['id'],$level+1);
    		}
    	}
    	return $ret;
    } 
    //以下是删除相关的方法
    public function childid($priid){
    	$data = $this->select();
    	return $this->getchildid($data,$priid);
    }
    public function getchildid($data,$parentid){
    	static $ret = array();
    	foreach ($data as $k => $v){
    		if($v['parentid'] == $parentid){
    			$ret[] = $v['id'];
    			$this->getchildid($data,$v['id']);
    		}
    	}
    	return $ret;
    }   
    /* 钩子函数，例如：删除主栏目之前，先查找删除所有子栏目，之后再删除主栏目
    _before_delete在执行删除栏目之前，先执行此函数*/
    public function _before_delete($options){
    	//单独删除时候id的值，是一个字符串，是一个单独的id
    	//$options['where']['id'];  //int(5)
    	// var_dump($options);
    	// die; 
    	if(is_array($options['where']['id'])){
    		$arr = explode(',', $options['where']['id'][1]);
    		$soncates = array();
    		foreach ($arr as $k => $v) {
    			$soncates2 = $this->childid($v);
    			$soncates = array_merge($soncates,$soncates2); //合并两个数组
    		}
    		$soncates = array_unique($soncates);  //去重复数组
    		$childrenids = implode(',', $soncates);
    	}else{   //单个批量删除
    		$childrenids = $this->childid($options['where']['id']);
			$childrenids = implode(',', $childrenids);

    	}
		if($childrenids){
			$this->execute("delete from cs_privilege where id in($childrenids)");				
		}
    }  
}