<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title></title>
    <script src="/Public/Home/js/jquery-2.1.4.js"></script>
    <script src="/Public/Home/js/ind.js"></script>
    <script src="/Public/Home/js/sy.js"></script>
    <link rel="stylesheet" href="/Public/Home/css/audio.css" />
    <link rel="stylesheet" href="/Public/Home/font/iconfont.css" />
    <link rel="stylesheet" href="/Public/Home/css/sy.css" />

    <!--头像-->
    <link rel="stylesheet" href="/Public/Home/css/style.css" type="text/css" />
    <script src="/Public/Home/js/cropbox.js"></script>

</head>

<body>
    <div class="w100 bgh">
        <a href="" download="" id="xiazaiba"></a>
        <div class="s_nav">
            <a href="/" class="ac">
                <div class="fl logo">
                    <img src="/Public/Home/img/logo.png" style="width: 170px;">
                </div>
            </a>
            <div class="fl nav1">
                <a href="/" class="ac">
                    <div class="w10px">
                        首页
                    </div>
                </a>
                <a href="<?php echo U('Home/member/zhuce');?>">
                    <div class="w10px">
                        注册
                    </div>
                </a>

                <div class="liupai w10px">
                    <a href="">所有流派</a>
                    <div class="hidebox">
                        <?php if(is_array($liupailist)): foreach($liupailist as $key=>$liupai): ?><div class="w25">
                                <a href="<?php echo U('Home/cat/liupailist',array('lpid'=>$liupai['id']));?>">
                                    <div class="t1"><?php echo ($liupai["title"]); ?></div>
                                </a>
                                <!--<div class="t2">
                                    <div>BigRoom</div>
                                    <div>HandsUp</div>
                                    <div>Elctro</div>
                                </div>-->
                            </div><?php endforeach; endif; ?>
                        <div class="w25">
                            <a href="<?php echo U('Home/cat/djs',array('type'=>'taoqu'));?>">
                                <div class="t1">套曲专区</div>
                            </a>
                            <!--<div class="t2">
                                    <div>BigRoom</div>
                                    <div>HandsUp</div>
                                    <div>Elctro</div>
                                </div>-->
                        </div>
                        <div class="w25">
                            <a href="<?php echo U('Home/cat/djs',array('type'=>'djs'));?>">
                                <div class="t1">DJG</div>
                            </a>
                            <!--<div class="t2">
                                    <div>BigRoom</div>
                                    <div>HandsUp</div>
                                    <div>Elctro</div>
                                </div>-->
                        </div>
                        <div class="w25">
                            <a href="<?php echo U('Home/cat/djs',array('type'=>'zip'));?>">
                                <div class="t1">ZIP 压缩包</div>
                            </a>
                            <!--<div class="t2">
                                    <div>BigRoom</div>
                                    <div>HandsUp</div>
                                    <div>Elctro</div>
                                </div>-->
                        </div>
                        <div class="w25">
                            <a href="<?php echo U('Home/cat/liupailist');?>">
                                <div class="t1">TOP 100</div>
                            </a>
                            <!--<div class="t2">
                                    <div>BigRoom</div>
                                    <div>HandsUp</div>
                                    <div>Elctro</div>
                                </div>-->
                        </div>
                    </div>
                </div>
                <div class="in">
                    <form action="<?php echo U('Home/index/search');?>" method="post" onsubmit="return VerifyData(); ">
                        <input type="" name="search" id="search" value="" class="fl" />
                        <button class="fl s_biso" type="submit"><img src="/Public/Home/img/sousuo.png"></button>
                    </form>
                </div>
            </div>
            <style>
                .s_biso {
                    width: 40px;
                    height: 40px;
                    background: none;
                    border: none
                }
                
                .s_biso img {
                    margin: 0 auto
                }
            </style>
            <div class="fr s_dl s_kil">
                <a href="<?php echo U('Home/member/zifei');?>">
                    <div class="box"><i class="icon Hui-iconfont" style="font-size: 30px;">&#xe673; </i>会员资费</div>
                </a>
            </div>

            <?php if($title != ''): ?><div class="fr s_dl">
                    <a href="<?php echo U('Home/member/index');?>">
                        <div class="box"><i class="icon Hui-iconfont" style="font-size: 30px;">&#xe62c; </i><?php echo ($title); ?></div>
                    </a>
                </div>
                <?php else: ?>
                <div class="fr s_dl">

                    <div class="box addbac"><i class="icon Hui-iconfont" style="font-size: 30px;">&#xe62c; </i>登录</div>
                    <div class="denglu123">
                        <div class="dlss">
                            <div>账号:</div>
                            <input type="text" name="title" />
                        </div>
                        <div class="dlss">
                            <div>密码:</div>
                            <input type="password" name="pwd" />
                        </div>
                        <div class="s_dengl" onclick="denglu()">登录</div>
                    </div>
                </div><?php endif; ?>
            <a href="<?php echo U('Home/member/index');?>">
                <div class="fr s_dl">
                    <div class="boximg fl" style="margin-right:10px;"><img src="/Public/Home/img/logo132.png"></div>
                    <div class="fl" style="line-height: 50px;">VIP DJ</div>
                    <div class="s_xinxi s_nnn">
                        <img src="/Public/Home/img/lomn.png" style="width:180px">
                        <div>©2012-2017 cpgdj.com。版权所有。</div>
                        <div>863472171＃qq.com @ /＃</div>
                    </div>
                </div>
            </a>
        </div>
    </div>
    <script>
        function VerifyData() {
            if ($('#search').val() == '') {
                return false;
            }
        }
    </script>

    <script>
        function denglu() {
            var title = $("input[name='title']").val();
            var pwd = $("input[name='pwd']").val();
            if (!title && !pwd) {
                alert('帐号密码不能为空!')
                return false;
            } else {
                var row = {
                        'title': title,
                        'pwd': pwd,
                    }
                    //获取当前域名
                var http = window.location.host;
                $.ajax({
                    url: "http://" + http + "/index.php/Home/member/denglu",
                    type: "post",
                    data: row,
                    dataType: "json",
                    success: function(data) {
                        // alert(data)
                        if (data.code == 1) {
                            alert(data.msg)
                                // window.location.href = "http://" + http;
                            window.location.reload();
                        } else {
                            alert(data.msg)
                        }
                    },
                    error: function(data) {
                        alert('登陆失败!');
                        // window.location.reload();
                    }
                });
            }

        }
    </script> <style type="text/css">
    .w800 {
        width: 800px;
        float: left;
    }
    
    .w400 {
        width: 390px;
        float: right;
    }
</style>

<div class="w1200">
		<div style="text-align: center; font-size: 18px; line-height: 30px; font-weight: bold;">CPGDJ网站简介+会员资费</div>
		<div style="text-align: center; font-size: 16px; line-height: 30px;">CPGDJ 拥有全球，最新，最全，厂牌音乐.</div>
		<div style="text-align: center; font-size: 14px; line-height: 30px;"> 1：CPGDJ 音乐资源来源于全球顶级收费站：
&包括：全球最大DJ社团 各大厂牌网站同步 汇聚了 ：英国，俄罗斯，菲律宾，美国，波兰，荷兰，韩国，以及全球各大收费网站，精选统一整理发布。。同时我们也会定期搜集国外著名DJ音乐制作人的作品和国外UMF派对现场音乐提供给大家.
                                 
</div>
<div style="text-align: center; font-size: 14px; line-height: 30px;"> 2：CPGDJ刚上线会有些歌曲延迟敬请大家谅解：希望您一直关注 CPGDJ它会带给你最快的资源享受，舞曲更新时间为每个月的2号6号10号14号。为四天一更新 本站从不压制音乐，与国外厂牌以及收费站同步更新 首首国外一线资源 【独家】【私货】【百大】【厂牌】首首高品质音乐，让我们告别垃圾低品质音乐 网站有国外厂牌同步参考  
</div>
<div style="text-align: center; font-size: 14px; line-height: 30px;">【【【 本站有专业音乐督察 管制本站所有音乐资源 】】】</div>
<div style="text-align: center; font-size: 14px; line-height: 30px;">本站除试听音乐外，所有音乐音质为320Kbps国外高音质无损原封音乐                           
</div>
<div style="text-align: center; font-size: 18px; line-height: 35px; color: red; font-weight: bold;">
 CPGDJ资费详情：</div>
	<div style="text-align: center; font-size: 14px; line-height: 30px; color: red;">本站上线期间优惠：【办理会员者可享受,赠送本站【ZIP压缩包和国内外套曲板块,可任意下载】</div>
			<div style="text-align: center; font-size: 14px; line-height: 30px; color: red;">特  大  优  惠：充值【VIP半年】者【免费送两个月】，【VIP一年】者【免费送半年】</div>
			<div style="text-align: center; font-size: 14px; line-height: 30px; color: red;">【在您充值有效日期内可以下载本站音乐】</div>
			<div style="text-align: center; font-size: 14px; line-height: 30px; color: red;">客服：1号  微信：15184157722    QQ：2755621683  电话：15184157722
客服: 2号  微信：15104512610    QQ：2863472171  电话：15104512610 
【使用微信支付宝扫描付款.微信支付宝扫描不能自动入帐，请扫描付款后与本站客服联系】
</div>
</div>

<div class="w1200">
    <div class="wym">
        <?php if(is_array($taocanlist)): foreach($taocanlist as $key=>$taocan): ?><div class="wym1">
                <div class="wm"><img src="/Public/Home/img/links.png"></div>
                <div class="wym2">
                    <div><?php echo ($taocan["title"]); ?></div>
                    <div>￥<span><?php echo ($taocan["price"]); ?></span>/RMB</div>
                </div>
                <div class="wym4">
                    <div><?php echo ($taocan["des1"]); ?></div>
                    <div><?php echo ($taocan["des2"]); ?></div>
                    <div><?php echo ($taocan["des3"]); ?></div>
                    <div><?php echo ($taocan["des4"]); ?></div>
                    <div><?php echo ($taocan["des5"]); ?></div>
                </div>
                <div class="gm">
                    <a href="<?php echo U('Home/member/pay',array('id'=>$taocan['id']));?>">
                        <div>购买</div>
                    </a>
                </div>
            </div><?php endforeach; endif; ?>
    </div>

</div>


<!--音乐播放器-->
<!--音乐播放器-->
<div class="min">
    <div class="w1200" style="width:100%">
        <div class="min1">
            <div class="minone fl">
                <img src="/Public/Home/img/m1.png">
            </div>
            <div class="mintwo fl">
                <div></div>
                <div class="ko"></div>
            </div>
        </div>
        <div class="box2">
            <div class="sj"></div>
        </div>
        <div class="box2 chixusj">
            <div class="sj1">sss</div>
        </div>
        <div id="s_bfq"></div>
        <div class="boxxinxi"><img src="/Public/Home/img/jp.png"></div>
        <div class="box2">
            <div class="xiazai">
                <a href="javascript:void(0);" class="ahre" id="dibuxiazai" mid=""></a>
                <i class="icon Hui-iconfont ani">&#xe674;</i>
            </div>
        </div>
        <div class="box3 xin" id="dianxin" mid=""><i class="icon Hui-iconfont ">&#xe648;</i></div>
        <div class="box4 yinliang">
            <div class="yin1"><img src="/Public/Home/img/yinliang.png"></div>
            <div class="tiaozhang">
                <div class="ziji"></div>
            </div>
        </div>
        <div class="box5 shangxia" id="shangyige" sx='s'><img src="/Public/Home/img/prev.png" /></div>
        <div class="boxbofang"></div>
        <div class="box5 shangxia" id="xiayige" sx='x'><img src="/Public/Home/img/next.png" /></div>

        <div class="boxlist"><img src="/Public/Home/img/dh.png"></div>
    </div>
</div>
<div class="lom">
    <div class="w1200">
        <div class="sk">
            <img src="" alt="" class="imgpath" />
            <div class="olx">
                <div>歌曲：Black Tiger Sex Machine＆Apashe Swing High（AK9 Remix）</div>
                <div>流派：BigRoom / Electro</div>
                <div>速度：BigRoom / Electro</div>
                <div>音调：5A</div>
                <div>时间：2017年6月21日</div>
                <div>试听：1153次</div>
                <div>时下载：027次</div>
            </div>
        </div>
    </div>
</div>
<div class="lom1">
    <div class="w1200" style="float:right;width:1090px;height:240px; overflow-y: scroll; float:left; margin:0;margin-left:245px;">
        <div class="sk1">


        </div>
    </div>
</div>
<!--音乐播放器-->

<div class="footer">
    <div class="w1200m">
        <div class="first">
            <a href="http://www.twitter.com"><img src="/Public/Home/img/1  twitter.com.jpg"></a>
            <a href="http://www.facebook.com"><img src="/Public/Home/img/2  www.facebook.com.jpg"></a>
            <a href="http://www.youtube.com"><img src="/Public/Home/img/3 www.youtube.com.jpg"></a>
            <a href="http://www.open.spotify.com"><img src="/Public/Home/img/3  open.spotify.combrowse.jpg"></a>
        </div>
        <div class="index2">
            <div class="index2a">厂牌同步</div>
            <div class="index2b">
                <a href="http://www.rukes.com"><img src="/Public/Home/img/min4.png"></a>
                <a href="http://www.tomorrowland.com"><img src="/Public/Home/img/min2.png"></a>
                <a href="http://www.spinninrecords.com"><img src="/Public/Home/img/min18.png"></a>
                <a href="http://www.revealedrecordings.com"><img src="/Public/Home/img/min15.png"></a>
                <a href="http://www.armadamusic.com"><img src="/Public/Home/img/min14.png"></a>
                <a href="http://www.monstercat.com"><img src="/Public/Home/img/min11.png"></a>
                <a href="http://www.mixmashrecords.com"><img src="/Public/Home/img/min9.png"></a>
                <a href="http://www.owsla.com"><img src="/Public/Home/img/min8.png"></a>
                <a href="http://www.www.flashoverrecordings.com"><img src="/Public/Home/img/min13.png"></a>
                <a href="http://www.bbc.com"><img src="/Public/Home/img/min5.png"></a>
                <a href="http://www.www.billboard.com"><img src="/Public/Home/img/min7.png"></a>
                <a href="http://www.classic.beatport.com"><img src="/Public/Home/img/min6.png"></a>
                <a href="http://www.yd111.cn"><img src="/Public/Home/img/min10.png"></a>
                <a href="http://www.protocolrecordings.com"><img src="/Public/Home/img/min20.jpg"></a>
                <!--<a href="http://www.bbc.com"><img src="/Public/Home/img/min11.png"></a>-->

            </div>
        </div>
        <div class="index3">
            <div class="index2a">CPGDJ音乐网</div>
            <div><img src="/Public/Home/img/logo.png" style="margin:15px 0"></div>
            <div>©2012-2017 CPGDJ.com。版权所有。</div>
            <div>2755621683@qq.com</div>
            <div><img src="/Public/Home/img/44251435651176.png"></div>
        </div>
    </div>
</div>

</body>
<script>
</script>

</html>