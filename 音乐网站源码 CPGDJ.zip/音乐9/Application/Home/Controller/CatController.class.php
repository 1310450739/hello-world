<?php 
namespace Home\Controller;
use Think\Controller;
class CatController extends CommonController
{
    public function liupailist(){
        if(I('get.lpid')){
            $musicobj = M('music');
            $count      = $musicobj->where('status = 0 and liupaiid='.I('get.lpid'))->count();// 查询满足要求的总记录数
            $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
            $show       = $Page->show();// 分页显示输出
            $this->assign('page',$show);// 赋值分页输出
            $musiclist = $musicobj
                    ->field('m.id,m.title,m.pic,m.bmp,m.key,m.dianjishu,m.addtime,m.status,m.fenleititle,lp.title as lp_title')
                    ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
                    ->where('m.status = 0 and m.liupaiid='.I('get.lpid'))
                    ->order('m.id desc , m.id desc')
                    ->limit($Page->firstRow.','.$Page->listRows)
                    ->select();
            $biaoti = $musiclist[0]['lp_title'];
            $musiclist = $this->jcsc($musiclist);
            $this->assign('biaoti',$biaoti);
            $this->assign('musiclist',$musiclist);
            $this->display();
        }else{
            $musicobj = M('music');
            $count      = $musicobj->count();// 查询满足要求的总记录数
            $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
            $show       = $Page->show();// 分页显示输出
            $this->assign('page',$show);// 赋值分页输出
            $musiclist = $musicobj
                    ->field('m.id,m.title,m.pic,m.bmp,m.key,m.dianjishu,m.addtime,m.status,m.fenleititle,lp.title as lp_title')
                    ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
                    ->where('m.status = 0')
                    ->order('m.id desc')
                    ->limit($Page->firstRow.','.$Page->listRows)
                    ->select();
            $this->assign('biaoti','top排行前100');
            $musiclist = $this->jcsc($musiclist);
            $this->assign('musiclist',$musiclist);
            $this->display();
        }
    }

    public function leibie(){
         if(I('get.type') == 'zip'){
            $musicobj = M('music');
            $count      = $musicobj ->where('status = 0 and zipid='.I('get.id'))->count();// 查询满足要求的总记录数
            $Page       = new \Think\Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数(25)
            $show       = $Page->show();// 分页显示输出
            $this->assign('page',$show);// 赋值分页输出
            $musiclist = $musicobj
                    ->field('m.id,m.title,m.pic,m.bmp,m.key,m.dianjishu,m.addtime,m.status,m.fenleititle,lp.title as lp_title')
                    ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
                    ->where('m.status = 0 and m.zipid='.I('get.id'))
                    ->limit($Page->firstRow.','.$Page->listRows)
                    ->order('m.id desc')
                    ->select();
            $this->assign('biaoti',"ZIP压缩包专区");
            $this->assign('wangpan','zip');
            $this->assign('musiclist',$musiclist);
            $zipone = M('zip')->field('id,title,des,pic,addtime,daxiao,xiazaishu')->where('status = 0 and id='.I('get.id'))->find();
            $this->assign('one',$zipone);
            
        }else if(I('get.type') == 'djs'){
            $musicobj = M('music');
            $count      = $musicobj ->where('status = 0 and zjid='.I('get.id'))->count();// 查询满足要求的总记录数
            $Page       = new \Think\Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数(25)
            $show       = $Page->show();// 分页显示输出
            $this->assign('page',$show);// 赋值分页输出
            $musiclist = $musicobj
                    ->field('m.id,m.title,m.pic,m.bmp,m.key,m.dianjishu,m.addtime,m.status,m.fenleititle,lp.title as lp_title')
                    ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
                    ->where('m.status = 0 and m.zjid='.I('get.id'))
                    ->limit($Page->firstRow.','.$Page->listRows)
                    ->order('m.id desc')
                    ->select();
            $this->assign('biaoti',"DJG 音乐制作人+独家思路");
            $this->assign('musiclist',$musiclist);
            $djsone = M('zhuanji')->field('id,title,zuozhe,des,pic,addtime')->where('status = 0  and id='.I('get.id'))->find();
            $this->assign('one',$djsone);
        }else if(I('get.type') == 'taoqu'){
            $musicobj = M('music');
            $count      = $musicobj ->where('status = 0 and tqid='.I('get.id'))->count();// 查询满足要求的总记录数
            $Page       = new \Think\Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数(25)
            $show       = $Page->show();// 分页显示输出
            $this->assign('page',$show);// 赋值分页输出
            $musiclist = $musicobj
                    ->field('m.id,m.title,m.pic,m.bmp,m.key,m.dianjishu,m.addtime,m.status,m.fenleititle,lp.title as lp_title')
                    ->join('as m join bj_liupai as lp on m.liupaiid = lp.id')
                    ->where('m.status = 0 and m.tqid='.I('get.id'))
                    ->limit($Page->firstRow.','.$Page->listRows)
                    ->order('m.id desc')
                    ->select();
            $this->assign('biaoti',"套曲专区");
            $this->assign('wangpan','taoqu');
            $this->assign('musiclist',$musiclist);
            $tqone = M('taoqu')->field('id,title,des,pic,addtime,daxiao,xiazaishu')->where('status = 0 and id='.I('get.id'))->find();
            $this->assign('one',$tqone);
        }else{
            $this->redirect('/');
        }

        $this->display();
    }
    public function djs(){
         if(I('get.type') == 'djs'){
            $zhuanjiobj = M('zhuanji');
            $count      = $zhuanjiobj->where('status = 0')->count();// 查询满足要求的总记录数
            $Page       = new \Think\Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数(25)
            $show       = $Page->show();// 分页显示输出
            $this->assign('page',$show);// 赋值分页输出
            $zhuanjilist = $zhuanjiobj
                        ->field('id,title,zuozhe,pic')
                        ->where('status = 0')
                        ->limit($Page->firstRow.','.$Page->listRows)                      
                        ->select();
            $this->assign('biaoti','DJG 音乐制作人+独家思路');
            $this->assign('type','djs');
            $this->assign('zhuanjilist',$zhuanjilist);

          
            $this->display();
        }else if(I('get.type') == 'taoqu'){
            if( $pid = (I('get.pid'))){
                $where = "status = 0 and pid = $pid";
            }else{
                 $where = "status = 0 and pid != 0";
            }
    
            $zhuanjiobj = M('taoqu');
            $count      = $zhuanjiobj->where($where)->count();// 查询满足要求的总记录数
            $Page       = new \Think\Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数(25)
            $show       = $Page->show();// 分页显示输出
            $this->assign('page',$show);// 赋值分页输出
            $zhuanjilist = $zhuanjiobj
                        ->field('id,title,pic')
                        ->where($where)
                        ->limit($Page->firstRow.','.$Page->listRows)
                        ->order('id desc')               
                        ->select();
            $this->assign('biaoti','套曲专区');
            $this->assign('type','taoqu');
            $this->assign('zhuanjilist',$zhuanjilist);
            $this->display();
        }else if(I('get.type') == 'zip'){
            $zhuanjiobj = M('zip');
            $count      = $zhuanjiobj->where('status = 0')->count();// 查询满足要求的总记录数
            $Page       = new \Think\Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数(25)
            $show       = $Page->show();// 分页显示输出
            $this->assign('page',$show);// 赋值分页输出
            $zhuanjilist = $zhuanjiobj
                        ->field('id,title,pic')
                        ->where('status = 0')
                        ->limit($Page->firstRow.','.$Page->listRows)  
                        ->order('id desc')                       
                        ->select();
            $this->assign('biaoti','ZIP 压缩包');
            $this->assign('type','zip');
            $this->assign('zhuanjilist',$zhuanjilist);

          
            $this->display();
        }else{
            $this->redirect('/');
        }
    }

}