<?php
namespace Admin\Controller;
use Think\Controller;
class CommonController extends Controller{
    //构造方法，继承父类
    public function __construct(){  
        header('content-type:text/html;charset=utf-8');
        parent::__construct();
        if(!session('id')){
            $this->error('请先登录！',U('Login/index'));
        }
        /*后台首页只要登录进来都能看到*/
        if(MODULE_NAME == 'Loler' && CONTROLLER_NAME == 'Index'){
        	return true;
        }
        /*后台退出功能*/
        if(MODULE_NAME == 'Loler' && CONTROLLER_NAME == 'Admin' && ACTION_NAME == 'logout'){

        	return true;
        }
        /*判断当前管理员正在访问的具体控制器的方法
        MODULE_NAEM.'/'.CONTROLLER_NAME.'/'.ACTION_NAME*/
        if(session('privilege') != '*' && !in_array(MODULE_NAME.'/'.CONTROLLER_NAME.'/'.ACTION_NAME,session('privilege'))){
        	$this->error('没有权限访问该功能！');
        }
    } 
    public function _empty($method){
        echo "你请求的【{$method}】不存在,请检查后重试";
    }

    //多图片上传
    public function upLoads(){
        $typeArr = array("jpg", "png", "gif");//允许上传文件格式
        if (isset($_POST)) {
            $name = $_FILES['file']['name'];
            $size = $_FILES['file']['size'];
            $name_tmp = $_FILES['file']['tmp_name'];
            if (empty($name)) {
                return false;
            }
            $type = strtolower(substr(strrchr($name, '.'), 1)); //获取文件类型

            if (!in_array($type, $typeArr)) {
                echo json_encode(array("error"=>"请上传jpg,png或gif类型的图片！"));
                exit;
            }
            $pic_name = time() . rand(10000, 99999) . "." . $type;//图片名称
            $upload = new \Think\Upload();
            $upload->savePath  =      '/Public/Uploads/phone/'; // 设置附件上传（子）目录
            $upload->rootPath  =      './';
            // 上传文件 
            $info = $upload->uploadOne($_FILES['file']);
            if(!$info) {// 上传错误提示错误信息
                echo json_encode(array("error"=>"上传有误，清检查服务器配置！"));
            }else{// 上传成功 获取上传文件信息     
                $path = $info['savepath'].$info['savename'];
                $picUrl = __ROOT__.$info['savepath'].$info['savename'];
                echo json_encode(array("error"=>"0","pic"=>$picUrl,"name"=>$pic_name,
                    'path'=>$path));
            }
        }
    }
    //随机生成的用户名
    public function getUserNumber($len='6')
    {
        $chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $username = "";
        for ( $i = 0; $i < $len; $i++ ){
            $username .= $chars[mt_rand(0, strlen($chars)-1)];
        }
        return "BJW".$username;
    }
}