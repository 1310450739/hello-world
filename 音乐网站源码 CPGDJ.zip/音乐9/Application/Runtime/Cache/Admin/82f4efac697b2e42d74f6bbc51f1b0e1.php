<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
    <title>添加管理员-后台管理</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="icon" type="image/x-icon" href="/Public/themes/ThirdParty/AmazeUI/i/favicon.ico">
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="/Public/themes/ThirdParty/AmazeUI/i/app-icon72x72@2x.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Amaze UI" />
    <link rel="apple-touch-icon-precomposed" href="/Public/themes/ThirdParty/AmazeUI/i/app-icon72x72@2x.png">
    <meta name="msapplication-TileImage" content="i/app-icon72x72@2x.png">
    <meta name="msapplication-TileColor" content="#0e90d2">
    <link rel="stylesheet" href="/Public/themes/ThirdParty/AmazeUI/css/amazeui.min.css">
    <script src="/Public/themes/ThirdParty/AmazeUI/js/jquery.min.js"></script>
    <script src="/Public/themes/ThirdParty/AmazeUI/js/amazeui.min.js"></script>
    <script src="/Public/themes/ThirdParty/AmazeUI/js/app.js"></script>

    <!--本地样式↓-->
    <link rel="stylesheet" href="/Public/themes/WxFile/css/public.css">
    <link rel="stylesheet" href="/Public/themes/WxFile/css/style.css">
    <script src="/Public/themes/WxFile/js/xcConfirm.js"></script>
    
    <script type="text/javascript" charset="utf-8" src="/Public/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="/Public/ueditor/ueditor.all.min.js"> </script>
    <script type="text/javascript" charset="utf-8" src="/Public/ueditor/lang/zh-cn/zh-cn.js"></script>

</head>

<body>
    <!-- 头部导航 -->
    <header class="am-topbar am-topbar-fixed-top" style="border: 0;">
        <div class="am-container nav_box">
            <h1 class="am-topbar-brand" style="border-right: 1px solid #3299de; padding-left: 10px;">
                <a href="/index.php/admin"><img src="/Public/themes/WxFile/img/logo.png"></a>
            </h1>
            <div class="am-icon-list tpl-header-nav-hover-ico am-fl am-margin-right" id="ssicon"></div>
            <a href="/" target="_blank">
                <div class="am-icon-home tpl-header-nav-hover-ico am-fl am-margin-right"></div>
            </a>
            <div class="nav_right">
                <ul class="top_nav">
                    <!--<li><a href="#"><i class="iconfont">&#xe672;</i> 帮助</a></li>-->
                    <!--<li><a href="#"><i class="iconfont">&#xe600;</i> 设置</a></li>-->
                    <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen" class="tpl-header-list-link"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>
                    <li class="am-dropdown" data-am-dropdown>
                        <a class="am-dropdown-toggle" data-am-dropdown-toggle href="javascript:;" style="padding-right: 12px;">
                            <div class="photo_img"><img src="/Public/themes/WxFile/img/timg.jpg"></div>
                            <?php echo session('username'); ?> <i class="iconfont" style="font-size: 12px;">&#xe60b;</i></a>
                        <ul class="am-dropdown-content" style="min-width: 110px;">
                            <li><a href="/index.php/Admin/Admin/edit/id/<?php echo session('id'); ?>"><i class="iconfont">&#xe63a;</i> 修改密码</a></li>
                            <li class="am-divider"></li>
                            <li class="am-divider"></li>
                            <li><a href="/index.php/Admin/Admin/logout"><span class="am-icon-sign-out"> 安全退出</span></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </header>
    <!-- 主体 -->
    <div class="main_box">
        <!-- 左侧 -->
        <div class="menu_left">
            <ul class="menu_nav mar0" id="accordion">
                <li><a class="m_cycaozuo yes_nodes" data-am-collapse="{parent: '#accordion'}" href="#do-not-say-1"><i class="icon iconfont"></i> 内容管理</a>
                    <ul class="childmenu mar0 am-panel-collapse am-collapse am-in" id="do-not-say-1">
                        <li><a href="/index.php/Admin/Liupai/index" id="a1"><i class="iconfont">&#xe6a4;</i> 流派管理</a></li>
                        <li><a href="/index.php/Admin/Zhuanji/index" id="a2"><i class="iconfont">&#xe6a4;</i> 专辑管理</a></li>
                        <li><a href="/index.php/Admin/Zip/index" id="a2"><i class="iconfont">&#xe6a4;</i> ZIP管理</a></li>
                        <li><a href="/index.php/Admin/Taoqu/index" id="a2"><i class="iconfont">&#xe6a4;</i> 套曲管理</a></li>
                        <li><a href="/index.php/Admin/Music/index" id="a2"><i class="iconfont">&#xe6a4;</i> 音乐管理</a></li>
                        <li><a href="/index.php/Admin/Mv/index" id="a2"><i class="iconfont">&#xe6a4;</i> MV管理</a></li>
                        <!--<li><a href="#" id="a4"><i class="iconfont">&#xe648;</i> 广告管理</a></li>
                        <li><a href="#" id="a7"><i class="iconfont">&#xe613;</i> 友情链接</a></li>
                        <li><a href="#" id="a8"><i class="iconfont">&#xe62e;</i> 用户管理</a></li>
                        <!--<li><a href="#"><i class="iconfont">&#xe62e;</i> 商品管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> 动态管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> VIP管理</a></li>-->
                    </ul>
                </li>
                <li><a class="m_cycaozuo yes_nodes" data-am-collapse="{parent: '#accordion'}" href="#do-not-say-3"><i class="icon iconfont"></i> 业务管理</a>
                    <ul class="childmenu mar0 am-panel-collapse am-collapse am-in" id="do-not-say-3">
                        <li><a href="/index.php/Admin/Taocan/index" id="a1"><i class="iconfont">&#xe601;</i> 套餐管理</a></li>
                        <li><a href="/index.php/Admin/Order/index" id="a2"><i class="iconfont">&#xe6a4;</i> 订单管理</a></li>
                        <!--<li><a href="#" id="a2"><i class="iconfont">&#xe6a4;</i> 音乐管理</a></li>-->
                        <!--<li><a href="#" id="a4"><i class="iconfont">&#xe648;</i> 广告管理</a></li>
                        <li><a href="#" id="a7"><i class="iconfont">&#xe613;</i> 友情链接</a></li>
                        <li><a href="#" id="a8"><i class="iconfont">&#xe62e;</i> 用户管理</a></li>-->
                        <!--<li><a href="#"><i class="iconfont">&#xe62e;</i> 商品管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> 动态管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> VIP管理</a></li>-->
                    </ul>
                </li>
                <li>
                    <a class="m_xitonggl yes_nodes" data-am-collapse="{parent: '#accordion'}" href="#do-not-say-2"><i class="icon iconfont"></i> 用户管理</a>
                    <ul class="childmenu mar0 am-panel-collapse am-collapse am-in" id="do-not-say-2">
                        <!--<li><a href="#" id="a9"><i class="iconfont">&#xe64e;</i> 系统设置</a></li>-->
                        <li><a href="/index.php/Admin/Admin/lst" id="a10"><i class="iconfont">&#xe6c3;</i> 管理员管理</a></li>
                        <!--<li><a href="/index.php/Admin/Privilege/lst" id="a8"><i class="iconfont">&#xe623;</i> 权限管理</a></li>-->
                        <!--<li><a href="/index.php/Admin/Role/lst" id="a11"><i class="iconfont">&#xe602;</i> 角色管理</a></li>-->
                        <li><a href="/index.php/Admin/Member/index" id="a11"><i class="iconfont">&#xe602;</i>会员管理</a></li>
                    </ul>
                </li>
            </ul>
        </div>
        <script type="text/javascript">
            $("#ssicon").click(function() {
                $(".menu_left").toggleClass("active");
            });
        </script>
        <script type="text/javascript">
            var myNav = document.getElementById("accordion").getElementsByTagName("a");
            for (var i = 0; i < myNav.length; i++) {
                var links = myNav[i].getAttribute("href");
                var myURL = document.location.href;
                if (myURL.indexOf(links) != -1) {
                    myNav[i].className = "cur";
                }
            }
        </script>
        <!-- 右侧 -->
        <div class="menu_right">
            
    <div class="seat">
        <ul>
            <li><i class="iconfont">&#xe603;</i> <a href=""> 首页</a></li>
            <li><a href="/index.php/Admin/admin/lst">管理员管理</a></li>
            <li>新增管理员</li>
        </ul>
    </div>

            
    <div class="palr15">
    <!-- 发布 -->
    <div class="publish">
    <form action="" method="post" id="myform" name="myform" enctype="multipart/form-data">
        <table class="am-table am-table-bordered">                 
        <tbody>       
            <tr>
                <td class="am-text-middle text_ri" style="width: 120px;"><span class="red">*</span> 管理员名称：</td>
                <td><input type="text" name="username" value="" class="input_texk"></td>
            </tr> 
            <tr>
                <td class="am-text-middle text_ri" style="width: 120px;"><span class="red">*</span> 管理员密码：</td>
                <td><input type="text" name="password" value="" class="input_texk"></td>
            </tr> 
            <tr>
                <td class="am-text-middle text_ri" style="width: 120px;"><span class="red">*</span> 所属角色：</td>
                <td>
                <div class="input-group" style="position: relative;">
                <div class="sanjiao"></div>
                <select name="roleid" class="select-group sel_inp">
                <?php if(is_array($roles)): $i = 0; $__LIST__ = $roles;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>"><?php echo ($vo["rolename"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
              </div>
              </td>
            </tr> 
            <tr>
                <td>&nbsp;</td>
                <td>
                  <input class="am-btn sea_btn am-btn-secondary font14" value="提交" type="submit">
                  <input class="am-btn am-btn-default sea_btn gray font14" onclick="history.go(-1)" value="返回" type="button">
                </td>
            </tr>
        </tbody>
        </table>
    </form>
    </div>
    </div>

            <!--palr15-->
        </div>
        <script type="text/javascript">
            $("#ssicon").click(function() {
                $(".menu_right").toggleClass("active");
            });
        </script>
    </div>
    <!-- 底部 -->
    <div class="footer">
        技术支持: <a href="http://www.bojuwang.net/"> www.bojuwang.net</a>
    </div>
</body>

</html>



<!--百度编辑器-->