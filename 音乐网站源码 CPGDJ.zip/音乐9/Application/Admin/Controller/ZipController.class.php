<?php
namespace Admin\Controller;
use Think\Controller;
class ZipController extends CommonController {
    public function index(){
        $zipobj = M('zip');
        $count      = $zipobj->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        $this->assign('page',$show);// 赋值分页输出
        $ziplist = $zipobj
                    ->field('id,title,des,pic,pic,link,pwd,status,daxiao,xiazaishu')
                    ->limit($Page->firstRow.','.$Page->listRows)
                    ->select();
        $this->assign('ziplist',$ziplist);
        $this->display();
    }


    public function add(){
        if (IS_POST) {
            $row = array();
            $row['title'] = I('post.title');
            $row['des'] = I('post.des');
            $row['link'] = I('post.link');
            $row['pwd'] = I('post.pwd');
            $row['daxiao'] = I('post.daxiao');
            $row['pic'] = I('post.pic')[0];
            $row['status'] = I('post.status');
            $row['addtime'] = time();
            if (M('zip')->add($row)) {
                $this->success('添加成功!',U('Admin/Zip/index'),1);
                exit;
            }else{
                $this->error('添加失败','',1);
                exit;
            }
        }
        $this->display();
    }

     public function del(){
        if(I('get.id')){
            if(M('zip')->delete(I('get.id'))){
                $this->success('删除成功!',U('Admin/Zip/index'),1);

                exit; 
            }else{
                $this->error('删除失败','',1);
                exit;
            }
        }else{
           $this->error('无效参数',U('Admin/Zip/index'),1);
            exit;  
        }
    }

    public function edit(){
        $zipobj = M('zip');
        $id = I('get.id');
        if (IS_POST) {
            $row = array();
            $row['title'] = I('post.title');
            $row['des'] = I('post.des');
            $row['link'] = I('post.link');
            $row['pwd'] = I('post.pwd');
            $row['daxiao'] = I('post.daxiao');
            $row['status'] = I('post.status');
            if(I('post.pic')[0]){
                $row['pic'] = I('post.pic')[0];
            }
            if (M('zip')->where('id= '.$id)->save($row)) {
                $this->success('修改成功!',U('Admin/Zip/index'),1);
                exit;
            }else{
                $this->error('修改失败','',1);
                exit;
            }
        }
        $zipone = $zipobj->find($id);
        $this->assign('zipone',$zipone);
        $this->display();
    }

     public function shuxingedit(){
        if(IS_POST){
            $row['xiazaishu'] = I('post.val');
            if(M('zip')->where('id ='.I('post.mid'))->save($row)){
                $data['code'] = 1;
                $data['msg'] = '修改成功!';
                exit(json_encode($data)); 
            }else{
                $data['code'] = 0;
                $data['msg'] = '修改失败!';
                exit(json_encode($data)); 
                
            }
        }else{
           $this->error('无效参数',U('Admin/Index/index'),1);
            exit;  
        }
    }
}
