<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
    
    <title>专辑列表-后台管理</title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="icon" type="image/x-icon" href="/Public/themes/ThirdParty/AmazeUI/i/favicon.ico">
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="/Public/themes/ThirdParty/AmazeUI/i/app-icon72x72@2x.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Amaze UI" />
    <link rel="apple-touch-icon-precomposed" href="/Public/themes/ThirdParty/AmazeUI/i/app-icon72x72@2x.png">
    <meta name="msapplication-TileImage" content="i/app-icon72x72@2x.png">
    <meta name="msapplication-TileColor" content="#0e90d2">
    <link rel="stylesheet" href="/Public/themes/ThirdParty/AmazeUI/css/amazeui.min.css">
    <script src="/Public/themes/ThirdParty/AmazeUI/js/jquery.min.js"></script>
    <script src="/Public/themes/ThirdParty/AmazeUI/js/amazeui.min.js"></script>
    <script src="/Public/themes/ThirdParty/AmazeUI/js/app.js"></script>

    <!--本地样式↓-->
    <link rel="stylesheet" href="/Public/themes/WxFile/css/public.css">
    <link rel="stylesheet" href="/Public/themes/WxFile/css/style.css">
    <script src="/Public/themes/WxFile/js/xcConfirm.js"></script>
    <!--日期插件-->
    <script language="javascript" type="text/javascript" src="/Public/admin/time/WdatePicker.js"></script>
    


</head>

<body>
    <!-- 头部导航 -->
    <header class="am-topbar am-topbar-fixed-top" style="border: 0;">
        <div class="am-container nav_box">
            <h1 class="am-topbar-brand" style="border-right: 1px solid #3299de; padding-left: 10px;">
                <a href="/index.php/admin"><img src="/Public/themes/WxFile/img/logo.png"></a>
            </h1>
            <div class="am-icon-list tpl-header-nav-hover-ico am-fl am-margin-right" id="ssicon"></div>
            <a href="/" target="_blank">
                <div class="am-icon-home tpl-header-nav-hover-ico am-fl am-margin-right"></div>
            </a>
            <div class="nav_right">
                <ul class="top_nav">
                    <!--<li><a href="#"><i class="iconfont">&#xe672;</i> 帮助</a></li>-->
                    <!--<li><a href="#"><i class="iconfont">&#xe600;</i> 设置</a></li>-->
                    <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen" class="tpl-header-list-link"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>
                    <li class="am-dropdown" data-am-dropdown>
                        <a class="am-dropdown-toggle" data-am-dropdown-toggle href="javascript:;" style="padding-right: 12px;">
                            <div class="photo_img"><img src="/Public/themes/WxFile/img/timg.jpg"></div>
                            <?php echo session('username'); ?> <i class="iconfont" style="font-size: 12px;">&#xe60b;</i></a>
                        <ul class="am-dropdown-content" style="min-width: 110px;">
                            <li><a href="/index.php/Admin/Admin/edit/id/<?php echo session('id'); ?>"><i class="iconfont">&#xe63a;</i> 修改密码</a></li>
                            <li class="am-divider"></li>
                            <li class="am-divider"></li>
                            <li><a href="/index.php/Admin/Admin/logout"><span class="am-icon-sign-out"> 安全退出</span></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </header>
    <!-- 主体 -->
    <div class="main_box">
        <!-- 左侧 -->
        <div class="menu_left">
            <ul class="menu_nav mar0" id="accordion">
                <li><a class="m_cycaozuo yes_nodes" data-am-collapse="{parent: '#accordion'}" href="#do-not-say-1"><i class="icon iconfont"></i> 内容管理</a>
                    <ul class="childmenu mar0 am-panel-collapse am-collapse am-in" id="do-not-say-1">
                        <li><a href="/index.php/Admin/Liupai/index" id="a1"><i class="iconfont">&#xe6a4;</i> 流派管理</a></li>
                        <li><a href="/index.php/Admin/Zhuanji/index" id="a2"><i class="iconfont">&#xe6a4;</i> 专辑管理</a></li>
                        <li><a href="/index.php/Admin/Zip/index" id="a2"><i class="iconfont">&#xe6a4;</i> ZIP管理</a></li>
                        <li><a href="/index.php/Admin/Taoqu/index" id="a2"><i class="iconfont">&#xe6a4;</i> 套曲管理</a></li>
                        <li><a href="/index.php/Admin/Music/index" id="a2"><i class="iconfont">&#xe6a4;</i> 音乐管理</a></li>
                        <li><a href="/index.php/Admin/Mv/index" id="a2"><i class="iconfont">&#xe6a4;</i> MV管理</a></li>
                        <!--<li><a href="#" id="a4"><i class="iconfont">&#xe648;</i> 广告管理</a></li>
                        <li><a href="#" id="a7"><i class="iconfont">&#xe613;</i> 友情链接</a></li>
                        <li><a href="#" id="a8"><i class="iconfont">&#xe62e;</i> 用户管理</a></li>
                        <!--<li><a href="#"><i class="iconfont">&#xe62e;</i> 商品管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> 动态管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> VIP管理</a></li>-->
                    </ul>
                </li>
                <li><a class="m_cycaozuo yes_nodes" data-am-collapse="{parent: '#accordion'}" href="#do-not-say-3"><i class="icon iconfont"></i> 业务管理</a>
                    <ul class="childmenu mar0 am-panel-collapse am-collapse am-in" id="do-not-say-3">
                        <li><a href="/index.php/Admin/Taocan/index" id="a1"><i class="iconfont">&#xe601;</i> 套餐管理</a></li>
                        <li><a href="/index.php/Admin/Order/index" id="a2"><i class="iconfont">&#xe6a4;</i> 订单管理</a></li>
                        <!--<li><a href="#" id="a2"><i class="iconfont">&#xe6a4;</i> 音乐管理</a></li>-->
                        <!--<li><a href="#" id="a4"><i class="iconfont">&#xe648;</i> 广告管理</a></li>
                        <li><a href="#" id="a7"><i class="iconfont">&#xe613;</i> 友情链接</a></li>
                        <li><a href="#" id="a8"><i class="iconfont">&#xe62e;</i> 用户管理</a></li>-->
                        <!--<li><a href="#"><i class="iconfont">&#xe62e;</i> 商品管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> 动态管理</a></li>
                        <li><a href="#"><i class="iconfont">&#xe62e;</i> VIP管理</a></li>-->
                    </ul>
                </li>
                <li>
                    <a class="m_xitonggl yes_nodes" data-am-collapse="{parent: '#accordion'}" href="#do-not-say-2"><i class="icon iconfont"></i> 用户管理</a>
                    <ul class="childmenu mar0 am-panel-collapse am-collapse am-in" id="do-not-say-2">
                        <!--<li><a href="#" id="a9"><i class="iconfont">&#xe64e;</i> 系统设置</a></li>-->
                        <li><a href="/index.php/Admin/Admin/lst" id="a10"><i class="iconfont">&#xe6c3;</i> 管理员管理</a></li>
                        <!--<li><a href="/index.php/Admin/Privilege/lst" id="a8"><i class="iconfont">&#xe623;</i> 权限管理</a></li>-->
                        <!--<li><a href="/index.php/Admin/Role/lst" id="a11"><i class="iconfont">&#xe602;</i> 角色管理</a></li>-->
                        <li><a href="/index.php/Admin/Member/index" id="a11"><i class="iconfont">&#xe602;</i>会员管理</a></li>
                    </ul>
                </li>
            </ul>
        </div>
        <script type="text/javascript">
            $("#ssicon").click(function() {
                $(".menu_left").toggleClass("active");
            });
        </script>
        <script type="text/javascript">
            var myNav = document.getElementById("accordion").getElementsByTagName("a");
            for (var i = 0; i < myNav.length; i++) {
                var links = myNav[i].getAttribute("href");
                var myURL = document.location.href;
                if (myURL.indexOf(links) != -1) {
                    myNav[i].className = "cur";
                }
            }
        </script>
        <!-- 右侧 -->
        <div class="menu_right">
            
    <div class="seat">
        <ul>
            <li><i class="iconfont">&#xe603;</i> <a href="/index.php/Admin/index/index"> 首页</a></li>
            <li>专辑列表</li>
        </ul>
    </div>

            
    <!-- 灰色框 -->
    <div class="gray_kbor mart10">
        <span class="fl"><a href="/index.php/Admin/Zhuanji/add" class="am-btn sea_btn2 am-btn-secondary"><i class="iconfont">&#xe6dc;</i> 新增专辑</a></span>
        <form name="myform" id="myform" method="post">
            <span class="fr">
            <!--<a class="am-btn sea_btn2 am-btn-secondary" href="javascript:void(0)" ><i class="iconfont">&#xe64a;</i> <input form="myform" formaction="/index.php/Admin/Zhuanji/bdel" formaction="post"  type="submit" value="批量删除" style="background: none;  border: 0; margin-left: 2px;" /></a>-->
            <!--<a class="am-btn sea_btn2 am-btn-secondary" href="javascript:void(0)"><i class="iconfont">&#xe607;</i><input form="myform" formaction="/index.php/Admin/Zhuanji/sortcate" formmethod ="post"  type="submit" value="更新排序" style="background: none;  border: 0; margin-left: 2px;"/></a></span>-->
    </div>
    <div class="tablelist">
        <table class="am-table am-table-bordered am-table-striped am-table-hover">
            <thead>
                <tr>
                    <!--<th><input name="" id="check" type="checkbox"> 全选</th>-->
                    <!--<th>排序</th>-->
                    <th>ID</th>
                    <th>专辑名称</th>
                    <th>演唱歌手</th>
                    <th>专辑描述</th>
                    <th>封面图片</th>
                    <!--<th>网盘连接 密码</th>-->
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if(is_array($zhuanjilist )): $i = 0; $__LIST__ = $zhuanjilist ;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$zhuanji ): $mod = ($i % 2 );++$i;?><tr>
                        <!--<td><input name="ids[] " value="<?php echo ($vo["id"]); ?> " class="check " type="checkbox "></td>-->
                        <!--<td><input name="<?php echo ($vo["id"]); ?> " value="<?php echo ($vo["sort"]); ?> " type="text " class="input_srk "></td>-->
                        <td><?php echo ($zhuanji["id"]); ?></td>
                        <td><?php echo ($zhuanji["title"]); ?></td>
                        <td><?php echo ($zhuanji["zuozhe"]); ?></td>
                        <td><?php echo ($zhuanji["des"]); ?></td>
                        <td><img src="<?php echo ($zhuanji["pic"]); ?> " height="50 " width="50 " /></td>
                        <!--<td>连接: <a href="<?php echo ($zhuanji["link"]); ?>" target="_tank"><?php echo ($zhuanji["link"]); ?></a> | 密码:<?php echo ($zhuanji["pwd"]); ?></td>-->
                        <td><?php echo ($zhuanji['status']==1?'关闭':'开启'); ?></td>
                        <td>
                            <div class="btn_two ">
                                <a class="am-btn sea_btn2 am-btn-secondary " href="<?php echo U( 'edit');?>?id=<?php echo ($zhuanji["id"]); ?> " style="padding: 6px 10px; ">修改</a>
                                <a class="am-btn sea_btn2 am-btn-danger " onclick="return confirm( '确定删除？') " href="<?php echo U( 'del');?>?id=<?php echo ($zhuanji["id"]); ?> " style="padding: 6px 10px; ">删除</a> <a class="am-btn sea_btn2 am-btn-secondary " href="<?php echo U( 'Music/add');?>?zjid=<?php echo ($zhuanji["id"]); ?>&title=<?php echo ($zhuanji["title"]); ?>"
                                    style="padding: 6px 10px; "><i class="iconfont">&#xe6dc;</i>添加音乐</a>
                            </div>
                        </td>
                    </tr><?php endforeach; endif; else: echo "" ;endif; ?>
            </tbody>
        </table>
    </div>
    </form>
    <div class="page" style="float:right; margin-right:30px;">
        <?php echo ($page); ?>
    </div>
    </div>

            <!--palr15-->
        </div>
        <script type="text/javascript">
            $("#ssicon").click(function() {
                $(".menu_right").toggleClass("active");
            });
        </script>
    </div>
    <!-- 底部 -->
    <div class="footer">
        技术支持: <a href="http://www.bojuwang.net/"> www.bojuwang.net</a>
    </div>
</body>

</html>



<!--百度编辑器-->